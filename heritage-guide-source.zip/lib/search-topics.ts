import { exploreItems } from './explore-items';
export type SearchTopic = {label:string;query:string;title:string;image:string;institution:string;source:string;credit:string};
// Topic illustrations are not search results or permission decisions.
const existing = exploreItems.filter(item=>item.image!==null).map(item=>({label:item.query,query:item.query,title:item.title,image:item.image!,institution:item.institution,source:item.source,credit:item.credit}));
export const searchTopics: SearchTopic[] = [
 existing[0],
 {label:'고양이',query:'고양이',title:'참새와 고양이 (변상벽)',image:'/artworks/placeholder.svg',institution:'국립중앙박물관',source:'https://www.museum.go.kr/MUSEUM/contents/M0502000000.do?relicId=1013&schM=view&searchId=search',credit:'공공누리 제1유형'},
 existing[1],
 {label:'연꽃무늬',query:'연꽃',title:'연꽃무늬 수막새',image:'/artworks/placeholder.svg',institution:'국립중앙박물관',source:'https://www.museum.go.kr/MUSEUM/contents/M0502000000.do?relicId=1897&schM=view&searchId=search',credit:'공공누리 제1유형'},
];
