import type { Candidate, Choice, Decision, RawField, ResearchSession, Rights, Usage } from './model';
import { CONDITIONS, OFFICIAL_CONDITION_SOURCE, resolveRights, supportedType } from './rights.ts';

export const VERSION = 'eval-v2-phase3a-20260914.13';
export const SESSION_SCHEMA = 'heritage-research-session-v2';
export const SCOPE_UNKNOWN = '권리정보의 이미지 적용범위가 확인되지 않아 현재 판단할 수 없습니다';
export const fieldValue = (fields: RawField[], key: string) => fields.find(f => f.key.toLowerCase() === key.toLowerCase())?.value ?? null;
export function unknownRights(fields: RawField[], location: 'record' | 'image', path: string): Rights {
  const values = fields.filter(f => f.key.toLowerCase() === 'glsv').map(f => f.value);
  const raw = values[0] ?? null;
  return {
    glsv_raw: raw, glsv_presence: raw === null ? 'missing' : raw.trim() === '' ? 'empty' : 'present',
    license_type_verified: null, license_code_source: null, applies_to: 'unknown', scope_evidence: null,
    verified_at: null, verification_status: new Set(values).size > 1 ? 'conflict' : 'unknown',
    observed_location: location, observed_path: path,
  };
}
// Keep the observed API value separate from effective, evidence-backed rights.
export function observedRights(candidate: Candidate): Rights {
  return candidate.image.rights.glsv_presence === 'missing' ? candidate.record.rights : candidate.image.rights;
}
export const effectiveRights = (candidate: Candidate): Rights => candidate.effective_rights ?? resolveRights(candidate);
export const rawLabel = (r: Rights) => r.glsv_presence === 'missing' ? '누락' : r.glsv_presence === 'empty' ? '빈 값' : r.glsv_raw;
export function explicitUsage(commercial: unknown, modification: unknown, at: string | null = null): Usage {
  const choice = (v: unknown): Choice => v === 'yes' || v === 'no' ? v : 'unknown';
  return { commercial: choice(commercial), modification: choice(modification), input_source: 'user_explicit', confirmed_at: at };
}
export function evaluateCandidate(candidate: Candidate, usage: Usage): Decision {
  const r = effectiveRights(candidate);
  const result = (status: Decision['status'], message: string, reason: string): Decision => ({ status, message, reason, version: VERSION,
    source_conflict: r.source_conflict ?? false, effective_source: r.effective_source ?? 'none', official_condition_source: OFFICIAL_CONDITION_SOURCE,
    attribution_required: Boolean(r.license_type_verified?.some(supportedType)) });
  if (r.applies_to === 'unknown' || r.applies_to === 'record') return result('rights_unconfirmed', SCOPE_UNKNOWN, 'image_scope_unverified');
  if (r.verification_status === 'conflict') return result('rights_conflict', '권리정보에 충돌이 있어 현재 판단할 수 없습니다.', 'conflicting_evidence');
  const type = r.license_type_verified?.[0];
  if (r.verification_status !== 'verified' || !supportedType(type) || !r.scope_evidence || !r.verified_at)
    return result('rights_unconfirmed', '이번 연구범위의 공공누리 제1~4유형으로 확인되지 않아 현재 판단할 수 없습니다.', 'licence_unverified_or_outside_scope');
  if (usage.commercial === 'unknown' || usage.modification === 'unknown') return result('actions_needed', '상업적 이용과 변경·편집 여부를 직접 선택해 주세요.', 'explicit_actions_required');
  const conditions = CONDITIONS[type], restricted: string[] = [];
  if (usage.commercial === 'yes' && !conditions.commercial) restricted.push('상업적 이용');
  if (usage.modification === 'yes' && !conditions.modification) restricted.push('변경·편집');
  if (restricted.length) return result('conditions_restricted', `확인된 공공누리 제${type}유형 조건상 ${restricted.join(' 및 ')}이 제한됩니다. 별도 허락 여부는 제공기관에서 확인해 주세요.`, 'official_conditions_mismatch');
  return result('conditions_satisfied', `출처표시 등 공식 이용조건을 준수하는 전제로, 입력한 행위는 확인된 공공누리 조건상 이용 가능합니다.`, 'official_conditions_match');
}
export const decisionLabels: Record<Decision['status'], string> = {
  rights_unconfirmed: '권리정보 미확인', rights_conflict: '권리정보 충돌', actions_needed: '이용행위 확인 필요',
  conditions_restricted: '확인된 조건상 제한', conditions_satisfied: '확인된 공공누리 조건상 이용 가능',
};
export function attributionDraft(c: Candidate): string {
  const r = effectiveRights(c), type = r.license_type_verified?.join(' / ');
  const number = [c.record.collection_number,c.record.collection_subnumber].filter(Boolean).join('-');
  const parts = [c.record.institution && `제공기관: ${c.record.institution}`, c.record.title && `자료명: ${c.record.title}`,
    number && `소장품 번호(원시값): ${number}`, c.record.id && `기록 ID: ${c.record.id}`,
    type && `공공누리 제${type}유형`,
    c.image.img_order_raw && `이미지 순서(원시값): ${c.image.img_order_raw}`,
    r.effective_source === 'emuseum_detail_page' ? `원문 주소(연구자 검토): ${c.page_review?.source_url}` : c.record.source_url && `원문 주소${c.record.source_url_origin === 'generated' ? ' 후보(시스템 생성·미검토)' : '(API 제공·미검토)'}: ${c.record.source_url}`,
    `API 확인일: ${c.capture.captured_at.slice(0, 10)}`].filter(Boolean);
  return parts.join(' / ') + '\n출처 문구 초안입니다. 이미지 작성자·작성연도 등 확인되지 않은 정보는 채우지 않았습니다. 제공기관의 필수 표시사항을 확인해 완성해 주세요.';
}
export function toCSV(session: ResearchSession): string {
  const rows: unknown[][] = [[
    'session_id','saved_at','question','search_query','search_page','candidate_id','institution','record_id','title',
    'image_observation_id','imgId_raw','imgOrder_raw','image_ordinal','commercial','modification','input_source',
    'glsv_raw','glsv_presence','glsv_observed_location','image_glsv_raw','image_glsv_presence',
    'license_type_verified','license_code_source','applies_to','scope_evidence','verification_status','verified_at',
    'system_status','system_message','system_reason','capture_id','api_endpoint','api_parameters','captured_at',
    'redacted_xml_sha256','source_url','source_url_origin','source_url_status','manual_groups_json','attribution_draft','version',
    'research_image_key','research_image_fingerprint','img_uri_sha256','identity_status','relicNo_raw','relicSubNo_raw',
    'verification_basis','verified_by_role','official_condition_source','public_api_documentation_status',
    'effective_source','source_conflict','conflict_resolution','page_review_json','rule_context_json','image_delivery_json',
    'image_display_status','image_display_observed_at','image_display_width','image_display_height','image_display_basis','image_display_json',
  ]];
  for (const c of session.candidates) {
    // Historic exports use saved interpretations and results, never today's rules.
    const r = c.effective_rights ?? observedRights(c), saved = session.decisions.find(d => d.candidate_id === c.candidate_id);
    rows.push([session.id,session.saved_at,session.question,c.search_context.query,c.search_context.page,c.candidate_id,c.record.institution,c.record.id,c.record.title,
      c.image.observation_id,c.image.img_id_raw,c.image.img_order_raw,c.image.ordinal,session.usage.commercial,session.usage.modification,session.usage.input_source,
      r.glsv_raw,r.glsv_presence,r.observed_location,c.image.rights.glsv_raw,c.image.rights.glsv_presence,
      JSON.stringify(r.license_type_verified),r.license_code_source,r.applies_to,r.scope_evidence,r.verification_status,r.verified_at,
      saved?.result.status,saved?.result.message,saved?.result.reason,c.capture.capture_id,c.capture.endpoint,JSON.stringify(c.capture.request_parameters),c.capture.captured_at,
      c.capture.raw_sha256,c.record.source_url,c.record.source_url_origin,c.record.source_url_status,
      JSON.stringify(session.groups.filter(g => g.member_ids.includes(c.candidate_id))),saved?.attribution_draft,session.version,
      c.image.research_image_key,c.image.research_image_fingerprint,c.image.img_uri_sha256,c.image.identity_status,c.record.collection_number,c.record.collection_subnumber,
      r.verification_basis,r.verified_by_role,r.official_condition_source,r.public_api_documentation_status,
      r.effective_source,r.source_conflict,r.conflict_resolution,JSON.stringify(c.page_review ?? null),JSON.stringify(session.rule_context ?? null),JSON.stringify(c.image_delivery ?? null),
      c.image_display?.status,c.image_display?.observed_at,c.image_display?.width,c.image_display?.height,c.image_display?.basis,JSON.stringify(c.image_display ?? null)]);
  }
  const cell = (v: unknown) => { let s = v === null || v === undefined ? '' : String(v); if (/^[\s]*[=+\-@]|^[\t\r\n]/.test(s)) s = "'" + s; return '"' + s.replace(/"/g, '""') + '"'; };
  return '\uFEFF' + rows.map(row => row.map(cell).join(',')).join('\r\n');
}
