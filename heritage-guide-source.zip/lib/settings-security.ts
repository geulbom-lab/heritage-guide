const context = (purpose: 'emuseum' | 'gemini') => new TextEncoder().encode(`heritage-guide:${purpose}-settings:v1`);
const encode = (value: Uint8Array) => btoa(String.fromCharCode(...value));
const decode = (value: string) => Uint8Array.from(atob(value), c => c.charCodeAt(0));

export function isSettingsOwner(user: {userId:string;email:string}|null, email: string): boolean {
  return !!user?.userId && !!email.trim() && user.email.trim().toLowerCase() === email.trim().toLowerCase();
}
export function normalizeServiceKey(value: unknown): string {
  if(typeof value !== 'string') throw Error('invalid_key');
  let key=value.trim();
  if(/%[0-9a-f]{2}/i.test(key)) { try { key=decodeURIComponent(key); } catch { throw Error('invalid_key'); } }
  if(!key || key.length>2048 || /\s|[<>]/.test(key)) throw Error('invalid_key');
  return key;
}
async function encryptionKey(secret:string) {
  const bytes=decode(secret);
  if(bytes.length!==32)throw Error('settings_storage_unavailable');
  return crypto.subtle.importKey('raw',bytes,'AES-GCM',false,['encrypt','decrypt']);
}
export async function sealServiceKey(key:string,secret:string,purpose:'emuseum'|'gemini'='emuseum'):Promise<string> {
  const iv=crypto.getRandomValues(new Uint8Array(12));
  const encrypted=await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:context(purpose)},await encryptionKey(secret),new TextEncoder().encode(key));
  return encode(iv)+'.'+encode(new Uint8Array(encrypted));
}
export async function openServiceKey(sealed:string,secret:string,purpose:'emuseum'|'gemini'='emuseum'):Promise<string> {
  const parts=sealed.split('.');
  if(parts.length!==2)throw Error('invalid_sealed_key');
  const plain=await crypto.subtle.decrypt({name:'AES-GCM',iv:decode(parts[0]),additionalData:context(purpose)},await encryptionKey(secret),decode(parts[1]));
  return new TextDecoder().decode(plain);
}
