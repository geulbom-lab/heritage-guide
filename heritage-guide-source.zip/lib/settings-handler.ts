import { isSettingsOwner, normalizeServiceKey } from './settings-security.ts';
type User={userId:string;email:string};
type Dependencies={user:()=>Promise<User|null>;ownerEmail:()=>string;validate:(key:string)=>Promise<boolean>;save:(key:string,userId:string)=>Promise<string>;clearCache:()=>void};
const reply=(message:string,status:number,extra:object={})=>Response.json({message,...extra},{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
export function makeSaveSettings(deps:Dependencies) {
  return async(request:Request):Promise<Response>=>{
    const user=await deps.user();
    if(!isSettingsOwner(user,deps.ownerEmail()))return reply('운영자 계정으로 로그인해 주세요.',403);
    if(request.headers.get('origin')!==new URL(request.url).origin)return reply('이 설정 화면에서 다시 시도해 주세요.',403);
    if(!request.headers.get('content-type')?.startsWith('application/json'))return reply('입력 내용을 확인해 주세요.',415);
    let key:string;
    try {
      const reader=request.body?.getReader();if(!reader)return reply('인증키를 입력해 주세요.',400);
      const decoder=new TextDecoder();let text='',size=0;
      while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>4096){await reader.cancel();return reply('입력한 인증키가 너무 길어요.',413);}text+=decoder.decode(value,{stream:true});}
      text+=decoder.decode();const data=JSON.parse(text);
      if(!data||Object.keys(data).some(k=>k!=='serviceKey'))return reply('입력 내용을 확인해 주세요.',400);
      key=normalizeServiceKey(data.serviceKey);
    }catch{return reply('인증키를 확인해 주세요.',400);}
    try {
      if(!await deps.validate(key))return reply('연결을 확인하지 못했어요. 인증키와 API 활용 승인을 확인하거나 잠시 후 다시 시도해 주세요. 기존 설정은 유지했어요.',422);
      const updatedAt=await deps.save(key,user!.userId);deps.clearCache();
      return reply('연결을 확인하고 저장했어요. 이제 사이트에서 이미지를 검색할 수 있어요.',200,{configured:true,updatedAt});
    }catch{return reply('설정을 저장하지 못했어요. 잠시 후 다시 시도해 주세요.',503);}
  };
}
