import { env } from 'cloudflare:workers';
import { readServiceKey } from './service-settings';
import { readGeminiKey } from './gemini-settings';

// Dedicated public Site configuration; no research storage or owner session.
export const keyConfigured = async () => { try { return Boolean(await readServiceKey()); } catch { return false; } };
export const serverKey = readServiceKey;
export const imageProtectionKey = () => env.EMUSEUM_IMAGE_ENCRYPTION_KEY || process.env.EMUSEUM_IMAGE_ENCRYPTION_KEY || '';
export const languageModelKey = readGeminiKey;
export const languageModelConfigured = async () => { try { return Boolean(await readGeminiKey()); } catch { return false; } };
