export type Feedback={message:string;recordId:string;title:string;imageOrdinal:string;licence:string;commercial:string;modification:string;verdict:string};
export function parseFeedback(value:unknown):Feedback{
  if(!value||typeof value!=='object'||Array.isArray(value))throw Error('invalid');
  const limits:Record<keyof Feedback,number>={message:1000,recordId:100,title:300,imageOrdinal:4,licence:20,commercial:10,modification:10,verdict:160};
  if(Object.keys(value).some(key=>!Object.hasOwn(limits,key)))throw Error('invalid');
  const result={} as Feedback;
  for(const key of Object.keys(limits) as (keyof Feedback)[]){
    const item=(value as Record<string,unknown>)[key]??'';
    if(typeof item!=='string'||item.length>limits[key])throw Error('invalid');
    result[key]=item.trim();
  }
  if(result.message.length<5||result.recordId&&!/^[A-Za-z0-9_-]+$/.test(result.recordId))throw Error('invalid');
  return result;
}
export function makeFeedbackHandler(save:(data:Feedback)=>Promise<string>,allow:(request:Request)=>boolean){
  return async(request:Request)=>{
    const reply=(message:string,status:number,extra:object={})=>Response.json({message,...extra},{status,headers:{'Cache-Control':'no-store'}});
    if(request.headers.get('origin')!==new URL(request.url).origin)return reply('이 사이트에서 신고해 주세요.',403);
    if(!request.headers.get('content-type')?.startsWith('application/json'))return reply('입력 형식을 확인해 주세요.',415);
    if(!allow(request))return reply('신고가 많아요. 잠시 후 다시 시도해 주세요.',429);
    let data:Feedback;
    try{
      const reader=request.body?.getReader();if(!reader)throw Error('empty');
      let count=0,text='';const decoder=new TextDecoder();
      while(true){const {done,value}=await reader.read();if(done)break;count+=value.byteLength;if(count>8192){await reader.cancel();return reply('내용이 너무 길어요.',413);}text+=decoder.decode(value,{stream:true});}
      data=parseFeedback(JSON.parse(text+decoder.decode()));
    }catch{return reply('오류 내용을 5~1,000자로 적어 주세요.',400);}
    try{const id=await save(data);return reply('신고를 접수했어요. 운영자가 확인할 수 있도록 저장했어요.',201,{id});}
    catch{return reply('신고를 저장하지 못했어요. 입력 내용은 유지되니 잠시 후 다시 시도해 주세요.',503);}
  };
}
