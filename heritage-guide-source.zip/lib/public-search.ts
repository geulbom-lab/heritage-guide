// Small, reviewed topic links; exact artwork titles are never broadly expanded.
// 호작도: https://www.museum.go.kr/MUSEUM/contents/M0502000000.do?relicId=8450&schM=view
// 묘작도: https://encykorea.aks.ac.kr/Article/E0018880
const TOPICS:Record<string,string[]>={호랑이:['호랑이','호작도'],고양이:['고양이','묘작도']};
export function searchTerms(query:string):string[]{return TOPICS[query.trim()]??[query.trim()];}
const compact=(text:string)=>text.normalize('NFKC').replace(/\s+/gu,'').toLowerCase();
export function relevantTitle(title:string,terms:string[]):boolean {
  const value=compact(title);
  return terms.some(term=>value.includes(compact(term)));
}
export function uniqueRecords<T extends {id:string;title:string}>(records:T[],terms:string[]):T[]{
  const seen=new Set<string>();
  return records.filter(record=>{
    if(seen.has(record.id)||!relevantTitle(record.title,terms))return false;
    seen.add(record.id);return true;
  });
}

// Each displayed page combines the same upstream page for all linked terms.
// Thus page count is the maximum, not the sum or filtered record count.
export function searchPagination(groups:{total:number|null;count:number}[],page:number,complete:boolean){
  const known=complete&&groups.length>0&&groups.every(g=>g.total!==null&&Number.isFinite(g.total)&&g.total>=0);
  const totalPages=known?Math.min(100,Math.max(1,page,...groups.map(g=>Math.ceil(g.total!/12)))):null;
  const hasNext=page<100&&groups.some(g=>g.total===null?g.count>=12:page*12<g.total);
  return {totalPages,hasNext};
}

export function refineRecords<T extends {record:{title:string;institution:string}}>(entries:T[],within:string,institution:string):T[]{
  const words=within.normalize('NFKC').trim().split(/\s+/u).filter(Boolean);
  return entries.filter(v=>(!institution||v.record.institution===institution)&&words.every(word=>compact(v.record.title).includes(compact(word))));
}
