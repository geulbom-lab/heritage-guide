import { CONDITIONS } from './rights.ts';
import type { Choice } from './model';

export type PublicRights = { type: keyof typeof CONDITIONS | null; confirmed: boolean; conflict: boolean };
export type PublicRecord = { id: string; title: string; institution: string; number: string; author: string; description: string; source: string; image: string | null; rights: PublicRights; checkedAt: string };
export type PublicImage = { id: string; ordinal: number; image: string | null; rights: PublicRights };
export type PublicDetail = { record: PublicRecord; images: PublicImage[] };
export type Selection = { record: PublicRecord; image: PublicImage };
export type Purpose = { commercial: Choice; modification: Choice };
export type Verdict = { status: 'match' | 'restricted' | 'conditional' | 'unknown'; title: string; description: string };

export function guidance(rights: PublicRights, purpose: Purpose): Verdict {
  if (!rights.confirmed || !rights.type || rights.conflict) return {status:'unknown',title:'원문 확인 필요',description:'이 이미지에 적용되는 이용조건을 충분히 확인하지 못했어요. 원문의 표시를 확인하거나 제공기관에 문의해 주세요.'};
  const condition = CONDITIONS[rights.type];
  const conflicts = [purpose.commercial==='yes' && !condition.commercial ? '상업적 이용' : '',purpose.modification==='yes' && !condition.modification ? '변경·편집' : ''].filter(Boolean);
  if (conflicts.length) return {status:'restricted',title:'별도 허락 필요',description:`공공누리 제${rights.type}유형은 ${conflicts.join('과 ')}을 허용하지 않아요. 다른 이미지를 고르거나 제공기관의 별도 허락을 받아 주세요.`};
  const remaining=[!condition.commercial && purpose.commercial==='unknown'?'판매·홍보 없이':'',!condition.modification && purpose.modification==='unknown'?'이미지를 변경하지 않고':''].filter(Boolean);
  if(remaining.length)return {status:'conditional',title:`${remaining.join(', ')} 쓰는 경우에 맞아요`,description:'질문에 언급되지 않은 부분은 조건을 붙여 안내해요. 출처를 표시하고 원문의 이미지별 조건을 확인해 주세요. 사용 계획이 다르면 결과에서 수정할 수 있어요.'};
  return {status:'match',title:'입력한 목적에 조건이 맞아요',description:'확인된 공공누리 조건에 따른 안내예요. 출처를 표시하고, 이용 전에 원문의 이미지별 표시와 추가 조건을 확인해 주세요.'};
}

const usageLanguage=/(?:판매|편집|변경|합성|넣|인쇄|복제|복사|제작|출판|발행|배포|쓰고|쓰려|쓰는데|쓸|써도|사용|활용|만들|만드|올리|찾|검색|비영리|상업|수업|필요)/u;
const saleLanguage=/(?:판매(?:하|할|해|용)|팔(?:자|래|게|까|고|아|려|기|\s*(?:거|생각|계획|예정))|파는|팝니다|상품|광고용|홍보(?:용|에|하|할)|유료|수익화)/u;
export function hasUsageIntent(question:string):boolean {
  return usageLanguage.test(question)||saleLanguage.test(question)||/그대로|디자인|붙여|새겨/u.test(question);
}

// Remove a preceding plan or destination by its grammatical role, not a list
// of merchandise nouns. A cup can itself be a legitimate collection object.
function sourcePhrase(prefix:string):string {
  let value=prefix.split(/[,，;；.!?。！？\n]+/u).at(-1)!.trim();
  value=value.split(/(?:만들\s*(?:려고|어서|고|건데|껀데|건대)|만드(?:려고|는데)|(?:제작|인쇄|출판)(?:하려고|하는데|하고|해서))(?:\s*(?:하는데요?|해요?|싶은데))?\s*/u).at(-1)!.trim();
  value=value.replace(/^(?:(?:저는|제가|나는|내가|혹시|근데|그런데|그리고|거기에|여기에)\s+)+/u,'');
  // A writing/presentation context is not part of the collection title.
  value=value.replace(/^(?:논문|보고서|과제|발표\s*자료)(?:을|를)?\s*(?:쓰|작성하|준비하)(?:는데요?|고\s*있는데요?|는\s*중인데요?)\s*/u,'');
  value=value.replace(/^.+?(?:에다가|에는|에도|에|용으로)\s+/u,'');
  value=value.replace(/^(?:있는|소장된|전시된)\s+/u,'');
  value=value.replace(/의$/u,'').trim().replace(/^[“「『"‘']|[”」』"’']$/gu,'');
  // Residual verbs mean the title boundary is uncertain. Ask for the title.
  if(/(?:만들|만드|쓰려|쓰는데|쓸|싶어|싶은|하려|판매하|제작하|사용하|넣어)/u.test(value))return '';
  return value;
}

// Prefer the named source image anywhere in the sentence before considering
// its first grammatical object. This works for destination-first questions.
function explicitSource(text:string):{found:boolean;query:string} {
  const marker=/(?<![\p{L}\p{N}])(?:이미지|사진|그림|문양|무늬|원문|원본|본문|전문)(?:으로|로|을|를|이|가|는|은|의|과|와)?(?=\s|$)/gu;
  const names:string[]=[];let found=false,from=0;
  for(const match of text.matchAll(marker)){
    const prefix=text.slice(from,match.index).trim();
    // Adjacent descriptions ("사진 이미지", "원문 전체") belong to one source.
    if(found&&(!prefix||/^(?:의|전체|전부|일부)$/u.test(prefix))){from=match.index+match[0].length;continue;}
    // A later sentence can restate the use of the same image without naming it.
    const clause=prefix.split(/[,，;；.!?。！？\n]+/u).at(-1)!.trim();
    if(found&&/^(?:(?:이|그)\s*)?(?:(?:논문|보고서|과제|발표\s*자료|수업)(?:에|에서)\s*(?:쓸|사용할|넣을)|(?:이|그))\s*$/u.test(clause)){from=match.index+match[0].length;continue;}
    const name=sourcePhrase(prefix);found=true;
    if(!name)return {found:true,query:''};
    names.push(name);from=match.index+match[0].length;
  }
  const unique=[...new Set(names)];
  return {found,query:unique.length===1?unique[0]:''};
}

// Bare titles are kept intact; uncertain sentences return an editable prompt.
export function suggestSearchTerm(question:string):string {
  const text=question.normalize('NFKC').trim().replace(/[.!?。！？]+$/u,'').trim();
  const quoted=[...text.matchAll(/[“「『"‘']([^”」』"’'\n]{1,150})[”」』"’']/gu)].filter(match=>{
    const after=text.slice(match.index+match[0].length);
    return !/(?:싶어|쓰려|만들|만드|제작하)/u.test(match[1])&&!/^(?:을|를)?\s*(?:만들|만드|제작)|^(?:에|에는|용으로)\s/u.test(after);
  });
  if(quoted.length>1)return '';
  if(quoted.length===1)return quoted[0][1].trim();
  let candidate=text.replace(/^(?:(?:저는|제가|혹시)\s+)+/u,'');
  candidate=candidate.replace(/^(?:티셔츠|엽서|굿즈|블로그|유튜브|수업\s*자료|발표\s*자료)(?:에|에는|용으로)\s+/u,'');
  const hasUsage=hasUsageIntent(candidate);
  if(hasUsage){
    const source=explicitSource(candidate);
    if(source.found)return source.query.length<=150?source.query:'';
    // No image marker: look for an object directly tied to a use verb.
    const used=candidate.match(/^(.+?)(?:을|를)\s*(?=쓰|써|사용|활용|넣)/u);
    if(used)candidate=sourcePhrase(used[1]);
    else {
      // Everyday questions often omit 을/를: "텀블러에 호작도 넣어서 팔자".
      // Isolate the phrase before the use verb, then remove its destination.
      const informal=candidate.match(/^(.+?)\s+(?=넣|쓰|써|사용|활용|붙여|붙이|새겨|새기|팔(?:자|고|아|래|게|까|려))/u);
      if(informal){
        let phrase=sourcePhrase(informal[1]);
        const destination=phrase.match(/^(.+?)\s+(?:(?:수업|발표)\s*자료|[^\s,;]+?)(?:에다가|에는|에도|에|용으로|자료로)$/u);
        if(destination)phrase=destination[1].replace(/(?:을|를)$/u,'').trim();
        candidate=phrase;
      }
    }
    // A production-only request has not identified a source image.
    const firstObject=candidate.match(/^(.+?)(으로|로|을|를)\s+(.+)/u);
    if(firstObject&&['을','를'].includes(firstObject[2])&&/^(?:만들|만드|제작)/u.test(firstObject[3]))return '';
    const object=candidate.match(/^(.+?)(?:으로|로|을|를)(?=\s)/u);
    if(object)candidate=object[1];
    // Extent and reproduction instructions describe the use, not the title.
    // Keep identifying words such as 원고/해례본/영인본 and multiword names.
    const content=candidate.match(/^(.+?)\s+(?:원문|원본|본문|전문|전체|전부|일부)(?:으로|로|을|를|의)?(?=\s|$)/u);
    if(content)candidate=content[1].trim().replace(/의$/u,'').trim();
    candidate=candidate.split(/\s+(?:복제|복사|제작|인쇄|출판|발행|배포|판매|영인)(?:하|해|한|할|해서|하여|하기)(?=\s|[가-힣]|$)/u)[0].trim();
  }
  const media=hasUsage?/\s*(?:이미지|사진|그림|문양|무늬)(?:으로|로|을|를|이|가|는|은|의)?(?=\s|$)/u:/\s+(?:이미지|사진|그림|문양|무늬)$/u;
  if(media.test(candidate))candidate=candidate.split(media)[0].trim().replace(/의$/u,'').trim();
  candidate=candidate.replace(/\s+(?:문화유산|국가유산|유물|소장품)(?:의)?$/u,'').trim();
  candidate=candidate.split(/\s+(?:티셔츠|엽서|굿즈|블로그|유튜브|수업\s*자료|발표\s*자료)(?:에|에는|용|을|를)?(?=\s|$)/u)[0].trim();
  candidate=candidate.split(/\s+(?:써도|쓰고|사용하|사용해|활용하|활용해|찾아|찾고|검색해|검색하)/u)[0].trim();
  candidate=candidate.replace(/\s+(?:문화유산|국가유산|유물|소장품)(?:의)?$/u,'').trim();
  // Ambiguous sentences need an editable search term, not a false zero-result search.
  if(!candidate || candidate.length>150 || /(?:싶어|싶다|싶습니다|판매하고|판매할|만들고|넣어서|해주세요|알려주|되나요)/u.test(candidate))return '';
  if(hasUsage&&/^(?:원문|원본|본문|전문|전체|전부|일부|영인본|복제본)$/u.test(candidate))return '';
  return candidate;
}

// This is an editable rule-based suggestion, not an LLM interpretation or a final decision.
export function suggestQuestion(question: string): {query:string} & Purpose {
  const {commercial,modification}=purposeSignals(question);
  return {query:suggestSearchTerm(question).slice(0,150),commercial,modification};
}

export function purposeSignals(question:string):Purpose&{commercialConflict:boolean;modificationConflict:boolean}{
  const q=question.normalize('NFKC').trim();
  let commercial:Choice='unknown',modification:Choice='unknown';
  const noSale=/(?:안\s*팔[가-힣]*|팔지\s*(?:않|말)[가-힣]*|팔(?:려고|려는)\s*(?:하지\s*않|게\s*아니)[가-힣]*|팔\s*(?:생각|계획|예정)(?:이|은|도)?\s*없[가-힣]*)/u;
  const explicitlyNoncommercial=/(?:비상업|비영리|수익\s*없|판매(?:는|를)?\s*(?:안|하지\s*않)|광고(?:는|를)?\s*(?:안|하지\s*않))/.test(q)||noSale.test(q);
  const saleText=q.replace(/(?:판매|광고)(?:는|를)?\s*(?:안\s*하|하지\s*않)[가-힣]*/g,'').replace(new RegExp(noSale.source,'gu'),'');
  const selling=saleLanguage.test(saleText);
  if (selling && !explicitlyNoncommercial) commercial='yes';
  else if(explicitlyNoncommercial && !selling) commercial='no';
  const unchanged=/(?:편집|변경|수정)(?:은|을)?\s*(?:안|하지\s*않)|그대로|원본\s*그대로/.test(q);
  const editText=q.replace(/(?:편집|변경|수정)(?:은|을)?\s*(?:안\s*하|하지\s*않)[가-힣]*/g,'');
  const edited=/(?:잘라|오려|합성|색(?:을|상)?\s*바꾸|색상(?:을)?\s*(?:바꾸|변경)|배경(?:을)?\s*(?:제거|지우)|재구성|편집하|편집해|수정하)/.test(editText);
  if (edited && !unchanged) modification='yes';
  else if (unchanged && !edited) modification='no';
  return {commercial,modification,commercialConflict:selling&&explicitlyNoncommercial,modificationConflict:edited&&unchanged};
}

export type AttributionDetails={institution?:string;author?:string;year?:string};
export function attribution(selection: Selection, details:AttributionDetails={}): string {
  const {record:r,image:i}=selection;
  const institution=(details.institution!==undefined?details.institution.trim():(r.institution==='제공기관 미확인'?'':r.institution)) || '[기관명 확인 필요]';
  // A collection's creator or production era is not the image's author or year.
  const author=details.author?.trim() || '[이미지 작성자·저작권자 확인 필요]';
  const year=details.year?.trim() || '[이미지 작성연도 확인 필요]';
  const licence=i.rights.confirmed&&!i.rights.conflict&&i.rights.type?`공공누리 제${i.rights.type}유형`:'[이용조건 확인 필요]';
  return [`본 콘텐츠는 ‘${institution}’에서 제공한 ‘${r.title}’의 ${i.ordinal}번째 이미지(작성연도: ${year}, 작성자·저작권자: ${author}, 이용조건: ${licence})를 이용하였습니다.`,
    `해당 자료의 원문과 이용조건은 다음 출처에서 확인하실 수 있습니다.`,
    `출처: ${institution} · ${r.source}`,r.number&&`소장품 번호: ${r.number}`].filter(Boolean).join('\n');
}
const escapeHTML=(value:string)=>value.replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]!));
export function attributionHTML(selection:Selection,details:AttributionDetails={}):string{
  const text=attribution(selection,details),source=selection.record.source;
  let safe=false;try{const u=new URL(source);safe=['https:','http:'].includes(u.protocol)&&!u.username&&!u.password;}catch{}
  const body=text.split('\n').map(line=>{
    const escaped=escapeHTML(line);
    return `<p>${safe&&line.startsWith('출처: ')?escaped.replace(escapeHTML(source),`<a href="${escapeHTML(source)}">${escapeHTML(source)}</a>`):escaped}</p>`;
  }).join('');
  return body;
}

export const purposeLabel=(value:Choice)=>value==='yes'?'있음':value==='no'?'없음':'언급 없음·미정';
