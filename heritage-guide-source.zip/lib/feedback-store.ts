import {env} from 'cloudflare:workers';
import type {Feedback} from './feedback-handler';
export async function saveFeedback(data:Feedback){
  if(!env.DB)throw Error('unavailable');
  const id=crypto.randomUUID();
  await env.DB.prepare('INSERT INTO feedback_reports (id, created_at, payload) VALUES (?, ?, ?)').bind(id,new Date().toISOString(),JSON.stringify(data)).run();
  return id;
}
// Only call after the settings-owner check. No public read endpoint exists.
export async function listFeedback(){
  if(!env.DB)throw Error('unavailable');
  const rows=await env.DB.prepare('SELECT id, created_at, payload FROM feedback_reports ORDER BY created_at DESC LIMIT 50').all<{id:string;created_at:string;payload:string}>();
  return rows.results.map(row=>({...row,data:JSON.parse(row.payload) as Feedback}));
}
