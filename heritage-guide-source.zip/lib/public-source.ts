import { collect, type SourceInput } from './emuseum/source';
import { openImageLink } from './emuseum/image-delivery';
import { imageURL, isDistinctImageDeliveryCredential } from './emuseum/security';
import { imageProtectionKey, serverKey } from './server';
import { resolveRights, supportedType } from './rights';
import type { Candidate, HeritageRecord, Rights } from './model';
import type { PublicRecord, PublicRights } from './public-guide';

export function clearPublicCache(){cache.clear();inflight.clear();}
const cache=new Map<string,{until:number;value:Awaited<ReturnType<typeof collect>>}>();
const inflight=new Map<string,Promise<Awaited<ReturnType<typeof collect>>>>();
const limits=new Map<string,{until:number;count:number}>();
export function publicRateLimit(request:Request):boolean {
  const now=Date.now(),ip=request.headers.get('cf-connecting-ip') || 'local';
  for (const [key,v] of limits) if(v.until<now) limits.delete(key);
  if(limits.size>3000)return false;
  const v=limits.get(ip)??{until:now+60000,count:0};v.count++;limits.set(ip,v);
  return v.count<=90;
}
export async function publicCapture(input:SourceInput) {
  const key=JSON.stringify(input),now=Date.now();
  for (const [k,v] of cache) if(v.until<now)cache.delete(k);
  const saved=cache.get(key);if(saved)return saved.value;
  const pending=inflight.get(key);if(pending)return pending;
  if(inflight.size>=12)throw Error('busy');
  const work=collect(input,await serverKey(),fetch,imageProtectionKey()).then(value=>{
    // No research capture, search question or personal record is persisted.
    if(value.capture.normalized.ok){if(cache.size>=32)cache.delete(cache.keys().next().value!);cache.set(key,{until:Date.now()+120000,value:{...value,raw:null}});}
    return value;
  }).finally(()=>inflight.delete(key));
  inflight.set(key,work);return work;
}
export function rightsSummary(r:Rights):PublicRights {
  const t=r.license_type_verified?.[0];
  return {type:supportedType(t)?t:null,confirmed:r.verification_status==='verified' && ['record_all_images','all_images','individual_image'].includes(r.applies_to),conflict:r.verification_status==='conflict'};
}
export function publicRecord(record:HeritageRecord,at:string):PublicRecord {
  return {id:record.id!,title:record.title || '이름이 제공되지 않은 자료',institution:record.institution || '제공기관 미확인',number:[record.collection_number,record.collection_subnumber].filter(Boolean).join('-'),author:record.author_raw || '',description:(record.description || '').replace(/<[^>]*>/g,'').slice(0,2000),source:`https://www.emuseum.go.kr/detail?relicId=${encodeURIComponent(record.id!)}`,image:null,rights:rightsSummary(record.rights),checkedAt:at};
}
const b64=(bytes:Uint8Array)=>btoa(String.fromCharCode(...bytes));
const unb64=(str:string)=>Uint8Array.from(atob(str),c=>c.charCodeAt(0));
async function ticketKey(){return crypto.subtle.importKey('raw',unb64(imageProtectionKey()),{name:'AES-GCM'},false,['encrypt','decrypt']);}
export async function publicImage(sealed:string|null,captureId:string,selector:string):Promise<string|null> {
  if(!sealed||!imageProtectionKey())return null;
  try {
    const u=await openImageLink(sealed,captureId,selector,imageProtectionKey());if(!u||!isDistinctImageDeliveryCredential(u,await serverKey()))return null;
    const iv=crypto.getRandomValues(new Uint8Array(12));
    const bytes=await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:new TextEncoder().encode('heritage-public-image-v1')},await ticketKey(),new TextEncoder().encode(JSON.stringify({url:u.href,expires:Date.now()+20*60000})));
    const ticket=b64(iv)+'.'+b64(new Uint8Array(bytes));
    return '/api/public/image?ticket='+encodeURIComponent(ticket);
  }catch{return null;}
}
export async function publicImageTarget(ticket:string) {
  if(ticket.length>10000)throw Error('invalid');
  const parts=ticket.split('.');if(parts.length!==2)throw Error('invalid');
  const bytes=await crypto.subtle.decrypt({name:'AES-GCM',iv:unb64(parts[0]),additionalData:new TextEncoder().encode('heritage-public-image-v1')},await ticketKey(),unb64(parts[1]));
  const data=JSON.parse(new TextDecoder().decode(bytes));
  if(!Number.isFinite(data.expires)||data.expires<Date.now()||data.expires>Date.now()+21*60000)throw Error('expired');
  const url=imageURL(data.url);if(!url||!isDistinctImageDeliveryCredential(url,await serverKey()))throw Error('invalid');
  return url;
}
export function imageRights(candidate:Candidate){return rightsSummary(resolveRights(candidate));}
