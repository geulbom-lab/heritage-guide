import { suggestQuestion, hasUsageIntent, type Purpose } from './public-guide.ts';

export type QuestionAnalysis = Purpose & {
  query: string;
  hasPurpose: boolean;
  method: 'ai' | 'rules';
  fallback: 'unconfigured' | 'unavailable' | 'limit' | null;
};

// Only obvious title-only input bypasses an available model. When the model
// is absent or unavailable, retain the existing basic sentence search.
export function isPlainSearch(question: string): boolean {
  const value = question.normalize('NFKC').trim();
  return !!value && value.length <= 150 && !hasUsageIntent(value)
    && !/[.!?。！？\n]|(?:싶|인데|거든|뭐냐|뭔지|어떻|있어|있나|인가|할까|해줘|주세요|이야|이에요|예요|합니다|해요)/u.test(value)
    && suggestQuestion(value).query === value;
}

export function ruleAnalysis(question: string, fallback: QuestionAnalysis['fallback'] = 'unconfigured'): QuestionAnalysis {
  const plain = isPlainSearch(question);
  const suggested = suggestQuestion(question);
  // A destination fragment such as "논문에" is not a source title. Reject
  // residual sentence wording, while keeping recognized source names intact.
  const usable = isPlainSearch(suggested.query)
    && !/(?:에|에서|에다가|에는|에도|용으로)$/u.test(suggested.query);
  return { ...suggested, query: plain ? question.normalize('NFKC').trim() : usable ? suggested.query : '',
    hasPurpose: hasUsageIntent(question), method: 'rules', fallback: plain ? null : fallback };
}
