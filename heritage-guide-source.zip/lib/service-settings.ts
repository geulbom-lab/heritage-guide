import { env } from 'cloudflare:workers';
import { openServiceKey, sealServiceKey } from './settings-security';
type Setting={encrypted_value:string;updated_at:string};
const encryptionSecret=()=>env.SETTINGS_ENCRYPTION_KEY || process.env.SETTINGS_ENCRYPTION_KEY || '';
export const ownerEmail=()=>env.SETTINGS_OWNER_EMAIL || process.env.SETTINGS_OWNER_EMAIL || '';
export const environmentServiceKey=()=>env.EMUSEUM_SERVICE_KEY || process.env.EMUSEUM_SERVICE_KEY || '';
export async function savedSetting():Promise<Setting|null> {
  if(!env.DB)return null;
  return env.DB.prepare('SELECT encrypted_value, updated_at FROM service_settings WHERE id = ?').bind('emuseum').first<Setting>();
}
export async function readServiceKey():Promise<string> {
  const row=await savedSetting();
  return row?openServiceKey(row.encrypted_value,encryptionSecret()):environmentServiceKey();
}
export async function connectionStatus() {
  const row=await savedSetting();
  return {configured:!!row || !!environmentServiceKey(),updatedAt:row?.updated_at??null,canSave:!!env.DB && !!encryptionSecret()};
}
export async function saveServiceKey(key:string,userId:string) {
  if(!env.DB)throw Error('settings_storage_unavailable');
  const encrypted=await sealServiceKey(key,encryptionSecret());
  const updatedAt=new Date().toISOString();
  await env.DB.prepare('INSERT INTO service_settings (id, encrypted_value, updated_at, updated_by) VALUES (?, ?, ?, ?) ON CONFLICT(id) DO UPDATE SET encrypted_value = excluded.encrypted_value, updated_at = excluded.updated_at, updated_by = excluded.updated_by').bind('emuseum',encrypted,updatedAt,userId).run();
  return updatedAt;
}
