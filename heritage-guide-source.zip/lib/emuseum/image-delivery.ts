// Server-only image transport. Opaque image tokens never enter Capture/CSV/JSON.
import type { HeritageImage, SourceKind } from '../model';
import { parseXML } from './xml.ts';
import { boundedBody, imageURL } from './security.ts';

type ImageLinks = Record<string,string>;
const encoder = new TextEncoder();
const base64 = (bytes: Uint8Array) => {
  let out = ''; for (const b of bytes) out += String.fromCharCode(b); return btoa(out);
};
const unbase64 = (value: string) => Uint8Array.from(atob(value),c => c.charCodeAt(0));
const aad = (id: string) => encoder.encode(`eval-v2/image-links/v1:${id}`);
async function encryptionKey(secret: string) {
  try {
    const bytes = unbase64(secret);
    if (bytes.length !== 32) throw Error();
    return await crypto.subtle.importKey('raw',bytes,{name:'AES-GCM'},false,['encrypt','decrypt']);
  } catch {throw Error('IMAGE_PROTECTION_UNAVAILABLE');}
}

export async function sealImageLinks(xml: string, kind: SourceKind, captureId: string, secret: string): Promise<string|null> {
  if (kind === 'code' || !secret) return null;
  // This unredacted parse is private and solely for transport. Research parsing
  // still uses redacted XML and an independent evidence hash.
  const parsed = parseXML(xml,kind,captureId), links: ImageLinks = Object.create(null);
  if (!parsed.ok) return null;
  parsed.records.forEach((r,i) => { const u=imageURL(r.thumbnail_uri); if (u) links[`record-${i+1}`]=u.href; });
  parsed.images.forEach(i => { const u=imageURL(i.uri_redacted); if (u) links[String(i.ordinal)]=u.href; });
  if (!Object.keys(links).length) return null;
  const iv=crypto.getRandomValues(new Uint8Array(12));
  const ciphertext=await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:aad(captureId)},await encryptionKey(secret),encoder.encode(JSON.stringify(links)));
  return JSON.stringify({v:1,iv:base64(iv),ciphertext:base64(new Uint8Array(ciphertext))});
}

export async function openImageLink(sealed: string, captureId: string, selector: string, secret: string): Promise<URL|null> {
  try {
    if (!/^(?:record-)?[1-9]\d{0,5}$/.test(selector) || sealed.length > 8_000_000) return null;
    const data=JSON.parse(sealed);
    if (data.v !== 1) throw Error();
    const bytes=await crypto.subtle.decrypt({name:'AES-GCM',iv:unbase64(data.iv),additionalData:aad(captureId)},await encryptionKey(secret),unbase64(data.ciphertext));
    const links=JSON.parse(new TextDecoder().decode(bytes)) as ImageLinks;
    return imageURL(links[selector] ?? null);
  } catch { throw Error('IMAGE_PROTECTION_UNAVAILABLE'); }
}

export function rasterType(bytes: Uint8Array): string|null {
  const match=(offset:number,signature:number[]) => signature.every((v,i)=>bytes[offset+i]===v);
  if (match(0,[255,216,255])) return 'image/jpeg';
  if (match(0,[137,80,78,71,13,10,26,10])) return 'image/png';
  const text=(start:number,end:number)=>new TextDecoder('ascii').decode(bytes.subarray(start,end));
  if (['GIF87a','GIF89a'].includes(text(0,6))) return 'image/gif';
  if (text(0,4)==='RIFF' && text(8,12)==='WEBP') return 'image/webp';
  if (text(4,8)==='ftyp' && ['avif','avis'].includes(text(8,12))) return 'image/avif';
  return null;
}
export type ImageFailureCode = 'image_authentication_error'|'image_security_block'|'image_http_error'|'image_redirect'|'image_not_raster'|'image_empty'|'image_too_large'|'image_timeout'|'image_connection_error'|'page_not_verified'|'page_image_missing'|'page_image_ambiguous';
export type ImageDiagnostic = {
  checked_at:string;
  upstream_http_status:number|null;
  declared_content_type:string;
  detected_format:string;
  received_bytes:number|null;
  validation:'not_checked'|'http_error'|'empty'|'security_block'|'unsupported_body'|'content_type_mismatch'|'accepted';
};
export type ImageResult = ({ok:true;bytes:Uint8Array;type:string;http_status:number} | {ok:false;error:ImageFailureCode;http_status:number|null}) & {diagnostic:ImageDiagnostic};
const knownContentTypes = new Set([
  'image/jpeg','image/jpg','image/pjpeg','image/png','image/x-png','image/gif','image/webp','image/avif',
  'image/bmp','image/x-ms-bmp','image/tiff','image/svg+xml','image/x-icon','image/vnd.microsoft.icon',
  'application/octet-stream','binary/octet-stream','text/html','application/xhtml+xml','text/xml',
  'application/xml','text/plain','application/json','application/pdf','application/gzip','application/x-gzip',
]);
// Report only fixed format labels. Never echo arbitrary headers, error-page text,
// image URLs, redirect destinations, tokens, or exception messages to logs/UI.
function diagnosticContentType(value:string):string {
  return !value?'missing':knownContentTypes.has(value)?value:'other';
}
function detectedFormat(bytes:Uint8Array,type:string|null):string {
  if (type) return type;
  if (bytes[0]===31 && bytes[1]===139) return 'gzip';
  const head=new TextDecoder().decode(bytes.subarray(0,2048)).replace(/^\uFEFF/,'').trimStart();
  if (/^%PDF-/.test(head)) return 'pdf';
  if (/^(?:<!doctype\s+html\b|<html\b|<head\b|<body\b)/i.test(head)) return 'html';
  if (/^(?:<\?xml[\s\S]*?\?>\s*)?<svg\b/i.test(head)) return 'svg';
  if (/^(?:<\?xml\b|<[A-Za-z][\w:.-]*(?:\s|>))/.test(head)) return 'xml_like';
  if (/^(?:\{|\[)/.test(head)) return 'json_like';
  return 'unrecognized';
}
// A response signature observed on the deployed server, not a license rule.
// Require both the explicit block-page title and the security-policy message.
export function isSecurityBlockHTML(html:string):boolean {
  return /<title\b[^>]*>\s*Block Page\s*<\/title>/i.test(html)&&
    /Violation of Web Security Policy|접속\s*차단[\s\S]{0,80}웹\s*보안\s*정책\s*위반/i.test(html.replace(/<[^>]*>/g,' '));
}
export function imageFailureMessage(result:Extract<ImageResult,{ok:false}>):string {
  const messages:Record<ImageFailureCode,string> = {
    image_authentication_error:'이미지 서버가 접근을 허용하지 않았습니다. 공공누리 이용 제한 판정이 아닙니다.',
    image_security_block:'e뮤지엄의 웹 보안 정책에 의해 이미지 요청이 차단되었습니다. 제공기관의 연계 요청 조건 확인이 필요합니다. 이 응답은 공공누리 이용 제한의 근거가 아닙니다.',
    image_http_error:'e뮤지엄 이미지 서버가 오류를 반환했습니다. 잠시 후 다시 시도해 주세요.',
    image_redirect:'이미지 서버가 다른 주소로 이동을 요청했습니다. 인증값 보호를 위해 자동 이동하지 않았습니다.',
    image_not_raster:'응답을 지원하는 이미지 형식으로 확인하지 못했습니다. 이미지 연결을 확인해야 합니다.',
    image_empty:'이미지 서버의 응답이 비어 있습니다.',
    image_too_large:'시험본의 이미지 크기 한도를 초과했습니다. 원문에서 확인해 주세요.',
    image_timeout:'이미지 응답 시간이 초과되었습니다. 다시 시도해 주세요.',
    image_connection_error:'이미지 서버에 연결하지 못했습니다. 다시 시도해 주세요.',
    page_not_verified:'e뮤지엄에서 해당 소장품의 원문을 확인하지 못했습니다. 오류·차단 문서를 이미지 근거로 사용하지 않았습니다.',
    page_image_missing:'해당 소장품의 원문에서 이미지 주소를 찾지 못했습니다.',
    page_image_ambiguous:'원문의 여러 이미지 중 선택한 API 이미지와 대응하는 항목을 확인하지 못했습니다. 임의의 이미지로 대체하지 않았습니다.',
  };
  const d=result.diagnostic;
  if (result.error==='image_not_raster') {
    if (d.validation==='content_type_mismatch') return '이미지 파일은 도착했지만 서버의 파일 형식 표시가 일치하지 않습니다. 연결 처리를 확인해야 합니다.';
    if (d.detected_format==='html') return '이미지 주소에서 HTML 문서를 받았습니다. 이미지 대신 웹 문서가 반환된 이유를 확인해야 합니다.';
    if (['xml_like','json_like'].includes(d.detected_format)) return '이미지 주소에서 데이터 문서 형식의 응답을 받았습니다. 응답 내용을 확인해야 합니다.';
    if (d.detected_format==='gzip') return '압축된 응답을 받았습니다. 이미지 응답의 압축 처리를 확인해야 합니다.';
    if (['svg','pdf'].includes(d.detected_format)) return '현재 미리보기가 지원하지 않는 파일 형식을 받았습니다. 원문에서 확인해 주세요.';
  }
  return messages[result.error];
}
async function inspectImageResponse(response:Response):Promise<ImageResult> {
  const declared=(response.headers.get('content-type')??'').split(';')[0].trim().toLowerCase();
  const diagnostic:ImageDiagnostic={checked_at:new Date().toISOString(),upstream_http_status:response.status,declared_content_type:diagnosticContentType(declared),detected_format:'not_inspected',received_bytes:null,validation:'not_checked'};
  const failed=(error:ImageFailureCode):ImageResult=>({ok:false,error,http_status:response.status,diagnostic});
  if(!response.ok){await response.body?.cancel();diagnostic.validation='http_error';return failed([401,403].includes(response.status)?'image_authentication_error':response.status>=300&&response.status<400?'image_redirect':'image_http_error');}
  const bytes=await boundedBody(response,15_000_000);diagnostic.received_bytes=bytes.length;
  if(!bytes.length){diagnostic.validation='empty';return failed('image_empty');}
  const type=rasterType(bytes);diagnostic.detected_format=detectedFormat(bytes,type);
  if(diagnostic.detected_format==='html'&&isSecurityBlockHTML(new TextDecoder().decode(bytes))){diagnostic.validation='security_block';return failed('image_security_block');}
  if(!type){diagnostic.validation='unsupported_body';return failed('image_not_raster');}
  if(![type,'image/jpg','application/octet-stream','binary/octet-stream',''].includes(declared)){diagnostic.validation='content_type_mismatch';return failed('image_not_raster');}
  diagnostic.validation='accepted';return {ok:true,bytes,type,http_status:response.status,diagnostic};
}
export async function downloadImage(url: URL, fetcher: typeof fetch = fetch): Promise<ImageResult> {
  let response:Response|null=null;
  const diagnostic:ImageDiagnostic={checked_at:new Date().toISOString(),upstream_http_status:null,declared_content_type:'not_received',detected_format:'not_inspected',received_bytes:null,validation:'not_checked'};
  const failed=(error:ImageFailureCode):ImageResult=>({ok:false,error,http_status:response?.status??null,diagnostic});
  try {
    if (!imageURL(url.href)) return failed('image_connection_error');
    response=await fetcher(url,{redirect:'manual',signal:AbortSignal.timeout(20000)});
    return await inspectImageResponse(response);
  } catch (error) {
    const e=error as Error;
    return failed(e.message==='RESPONSE_TOO_LARGE'?'image_too_large':['AbortError','TimeoutError'].includes(e.name)?'image_timeout':'image_connection_error');
  }
}

export type PageImageTarget = {
  recordId:string;
  // These observations come from the owner's saved API capture, never the request query.
  images:Pick<HeritageImage,'record_id'|'img_id_raw'|'ordinal'>[];
  imageTotalCount:number|null;
  selector:number|'representative';
};
export type PageImageEvidence = {
  source_url:string;
  source_url_origin:'generated';
  captured_at:string;
  record_id:string;
  page_img_id_raw:string|null;
  page_element_id:string;
  page_image_count:number;
  api_img_id_raw:string|null;
  api_image_count:number;
  api_image_total_count:number|null;
  match_basis:'exact_unique_image_id'|'single_image_in_both_sources'|'record_representative';
  // This is a collection of observed image markup, not a rights-page review.
  page_manifest_sha256:string;
  image_url_sha256:string;
  rights_reviewed:false;
};
export type PageImageManifest = {record_ids:string[];images:{element_id:string;page_img_id_raw:string|null;image_url_sha256:string|null}[]};
export type PageImageResult = ImageResult & {source:'emuseum_detail_page';page_diagnostic:ImageDiagnostic;page_evidence?:PageImageEvidence;page_manifest?:PageImageManifest};
const decodeAttribute=(value:string)=>value.replace(/&amp;/gi,'&').replace(/&quot;/gi,'"').replace(/&#39;|&apos;/gi,"'");
function attributes(tag:string):Record<string,string> {
  const out:Record<string,string>=Object.create(null);
  for(const match of tag.matchAll(/([\w:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g)) out[match[1].toLowerCase()]=decodeAttribute(match[2]??match[3]??'');
  return out;
}
function pageImageURL(raw:string):URL|null {
  try {
    const u=new URL(raw,'https://www.emuseum.go.kr');
    if(u.protocol!=='https:'||u.hostname!=='www.emuseum.go.kr'||u.port||u.username||u.password||u.search||u.hash||!u.pathname.startsWith('/IMG/')||u.pathname.length>4000)return null;
    if(!/^\/IMG\/[A-Za-z0-9_+%=/.-]+$/.test(u.pathname)||u.pathname.includes('..'))return null;
    return u;
  } catch{return null;}
}
function sessionCookies(headers:Headers,target:URL):string {
  const values=typeof (headers as Headers&{getSetCookie?:()=>string[]}).getSetCookie==='function'
    ?(headers as Headers&{getSetCookie:()=>string[]}).getSetCookie()
    :(headers.get('set-cookie')??'').split(/,(?=\s*[!#$%&'*+.^_`|~0-9A-Za-z-]+=)/);
  const cookies=new Map<string,string>();
  for(const value of values) {
    const [pair,...parts]=value.split(';').map(v=>v.trim());
    if(!/^[!#$%&'*+.^_`|~0-9A-Za-z-]+=[^\r\n;,]*$/.test(pair))continue;
    const a=Object.fromEntries(parts.map(v=>{const n=v.indexOf('=');return [n<0?v.toLowerCase():v.slice(0,n).toLowerCase(),n<0?'':v.slice(n+1)];}));
    const domain=(a.domain??target.hostname).replace(/^\./,'').toLowerCase();
    const path=a.path?.startsWith('/')?a.path:'/';
    // Only normal cookies issued by this public page, scoped to its image path.
    if(!['emuseum.go.kr','www.emuseum.go.kr'].includes(domain)||!(target.hostname===domain||target.hostname.endsWith('.'+domain)))continue;
    if(!(target.pathname===path||target.pathname.startsWith(path.endsWith('/')?path:path+'/')))continue;
    if(a['max-age']!==undefined&&Number(a['max-age'])<=0)continue;
    if(a['max-age']===undefined&&a.expires&&Date.parse(a.expires)<Date.now())continue;
    cookies.set(pair.slice(0,pair.indexOf('=')),pair);
  }
  return [...cookies.values()].join('; ');
}
export async function imageSHA256(bytes:Uint8Array):Promise<string> {
  const digest=await crypto.subtle.digest('SHA-256',bytes as BufferSource);
  return Array.from(new Uint8Array(digest),v=>v.toString(16).padStart(2,'0')).join('');
}
export async function downloadImageFromDetailPage(target:PageImageTarget,fetcher:typeof fetch=fetch):Promise<PageImageResult> {
  const empty:ImageDiagnostic={checked_at:new Date().toISOString(),upstream_http_status:null,declared_content_type:'not_received',detected_format:'not_inspected',received_bytes:null,validation:'not_checked'};
  const pageDiagnostic={...empty};
  const fail=(error:ImageFailureCode,diagnostic=empty,http_status:number|null=pageDiagnostic.upstream_http_status):PageImageResult=>({ok:false,error,http_status,diagnostic,source:'emuseum_detail_page',page_diagnostic:pageDiagnostic});
  const {recordId,selector}=target;
  if(!/^[A-Za-z0-9_-]{1,100}$/.test(recordId))return fail('page_not_verified');
  const apiImage=selector==='representative'?null:target.images.find(i=>i.ordinal===selector);
  if(selector!=='representative'&&(!apiImage||apiImage.record_id!==recordId))return fail('page_image_ambiguous');
  try {
    const page=new URL('https://www.emuseum.go.kr/detail');page.searchParams.set('relicId',recordId);
    const pageResponse=await fetcher(page,{headers:{Accept:'text/html','User-Agent':'Mozilla/5.0'},redirect:'manual',signal:AbortSignal.timeout(20000)});
    pageDiagnostic.upstream_http_status=pageResponse.status;
    const declared=(pageResponse.headers.get('content-type')??'').split(';')[0].trim().toLowerCase();
    pageDiagnostic.declared_content_type=diagnosticContentType(declared);
    if(!pageResponse.ok||declared!=='text/html'){await pageResponse.body?.cancel();pageDiagnostic.validation='http_error';return fail('page_not_verified');}
    const html=new TextDecoder().decode(await boundedBody(pageResponse,2_000_000));
    pageDiagnostic.received_bytes=encoder.encode(html).length;pageDiagnostic.detected_format='html';
    if(isSecurityBlockHTML(html)){pageDiagnostic.validation='security_block';return fail('image_security_block',pageDiagnostic);}
    // Ignore scripts, inert templates and comments so their markup is never evidence.
    const markup=html.replace(/<!--[\s\S]*?-->/g,'').replace(/<(script|style|template|noscript)\b[^>]*>[\s\S]*?<\/\1\s*>/gi,'');
    const recordIds:string[]=[],rows:{id:string;imgId:string|null;url:URL|null;active:boolean}[]=[];
    for(const match of markup.matchAll(/<(?:input|img)\b(?:"[^"]*"|'[^']*'|[^'">])*>/gi)) {
      const a=attributes(match[0]),classes=(a.class??'').split(/\s+/);
      if(/^<input\b/i.test(match[0])&&a.name==='relicId'&&a.type?.toLowerCase()==='hidden')recordIds.push(a.value??'');
      if(/^<img\b/i.test(match[0])&&classes.includes('mi')&&/^img_\d+$/.test(a.id??'')) {
        rows.push({id:a.id,imgId:/^[A-Za-z0-9_-]{1,100}$/.test(a['data-img-id']??'')?a['data-img-id']:null,url:pageImageURL(a.src??''),active:classes.includes('on')});
      }
    }
    if(!recordIds.length||recordIds.some(id=>id!==recordId)){pageDiagnostic.validation='unsupported_body';return fail('page_not_verified');}
    pageDiagnostic.validation='accepted';
    if(!rows.length)return fail('page_image_missing');
    let selected:typeof rows[number]|undefined, basis:PageImageEvidence['match_basis']|undefined;
    if(selector==='representative') {
      const active=rows.filter(r=>r.active);
      selected=rows.length===1?rows[0]:active.length===1?active[0]:undefined;
      basis='record_representative';
    } else if(apiImage) {
      // API imgId and HTML data-img-id are different namespaces in observed data.
      // Never pad IDs with zeroes or equate imgOrder with a DOM position.
      const exact=rows.filter(r=>r.imgId===apiImage.img_id_raw);
      const uniqueAPI=apiImage.img_id_raw&&apiImage.img_id_raw!==recordId&&target.images.filter(i=>i.img_id_raw===apiImage.img_id_raw).length===1;
      if(uniqueAPI&&exact.length===1){selected=exact[0];basis='exact_unique_image_id';}
      else if(target.imageTotalCount===1&&target.images.length===1&&rows.length===1){selected=rows[0];basis='single_image_in_both_sources';}
    }
    if(!selected||!basis)return fail('page_image_ambiguous');
    if(!selected.url)return fail('page_image_missing');
    const cookie=sessionCookies(pageResponse.headers,selected.url);
    const imageResponse=await fetcher(selected.url,{headers:{Accept:'image/avif,image/webp,image/*,*/*;q=0.8',Referer:page.href,...(cookie?{Cookie:cookie}:{})},redirect:'manual',signal:AbortSignal.timeout(20000)});
    const result=await inspectImageResponse(imageResponse);
    const imageURLHash=await imageSHA256(encoder.encode(selected.url.href));
    const manifest={record_ids:recordIds,images:await Promise.all(rows.map(async r=>({element_id:r.id,page_img_id_raw:r.imgId,image_url_sha256:r.url?await imageSHA256(encoder.encode(r.url.href)):null})))};
    const evidence:PageImageEvidence={source_url:page.href,source_url_origin:'generated',captured_at:pageDiagnostic.checked_at,record_id:recordId,
      page_img_id_raw:selected.imgId,page_element_id:selected.id,page_image_count:rows.length,api_img_id_raw:apiImage?.img_id_raw??null,
      api_image_count:target.images.length,api_image_total_count:target.imageTotalCount,match_basis:basis,
      page_manifest_sha256:await imageSHA256(encoder.encode(JSON.stringify(manifest))),image_url_sha256:imageURLHash,rights_reviewed:false};
    return {...result,source:'emuseum_detail_page',page_diagnostic:pageDiagnostic,page_evidence:evidence,page_manifest:manifest};
  } catch(error){
    const e=error as Error;
    return fail(e.message==='RESPONSE_TOO_LARGE'?'image_too_large':['AbortError','TimeoutError'].includes(e.name)?'image_timeout':'image_connection_error');
  }
}
