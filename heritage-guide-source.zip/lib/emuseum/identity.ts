import type { Parsed } from '../model';
import { sha256 } from './security.ts';

// Credentials have no role in image identity. Remove their parameters entirely,
// then hash only the canonical credential-free imgUri (not a thumbnail fallback).
export function canonicalImageURI(value: string | null): string | null {
  if (!value) return null;
  try {
    const u = new URL(value.replace(/&amp;/g,'&'));
    if (!['http:','https:'].includes(u.protocol) || u.username || u.password) return null;
    for (const key of [...u.searchParams.keys()]) if (/^(servicekey|apikey|access_token|token)$/i.test(key)) u.searchParams.delete(key);
    u.hash = ''; u.searchParams.sort();
    return /redacted/i.test(u.href) ? null : u.href;
  } catch { return null; }
}
export async function assignImageKeys(parsed: Parsed): Promise<Parsed> {
  const seen = new Map<string,number>();
  const images = [];
  for (const image of parsed.images) {
    const recordId = image.record_id || (parsed.records.length === 1 ? parsed.records[0].id : null);
    const uri = canonicalImageURI(image.uri_redacted), hash = uri ? await sha256(uri) : null;
    const base = recordId && image.img_order_raw?.trim() && hash ? `${encodeURIComponent(recordId)}:${encodeURIComponent(image.img_order_raw)}:${hash}` : null;
    const occurrence = base ? (seen.get(base) ?? 0)+1 : 0;
    if (base) seen.set(base,occurrence);
    images.push({ ...image, img_uri_sha256: hash, research_image_fingerprint: base,
      research_image_key: base ? `${base}:occurrence-${occurrence}` : null,
      identity_status: base ? 'composite' as const : 'incomplete' as const });
  }
  return { ...parsed, images: images.map(i => ({ ...i, identity_status: i.research_image_fingerprint && (seen.get(i.research_image_fingerprint) ?? 0)>1 ? 'duplicate_tuple' : i.identity_status })) };
}
