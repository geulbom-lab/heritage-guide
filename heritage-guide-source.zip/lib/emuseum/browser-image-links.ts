import type { HeritageImage } from '../model';
import { boundedBody, redactSecrets, sha256 } from './security.ts';
import { isSecurityBlockHTML } from './image-delivery.ts';

export type BrowserImageTarget = {
  recordId:string;
  images:Pick<HeritageImage,'record_id'|'img_id_raw'|'ordinal'|'observation_id'>[];
  imageTotalCount:number|null;
};
export type BrowserImageLink = {
  ordinal:number;
  page_element_id:string;
  page_img_id_raw:string|null;
  url:string|null;
  url_sha256:string|null;
  api_observation_id:string|null;
  api_ordinal:number|null;
  match_basis:'exact_unique_image_id'|'single_image_in_both_sources'|'record_only';
};
export type BrowserLinksResult = {
  ok:true;
  record_id:string;
  source_url:string;
  source_url_origin:'generated';
  captured_at:string;
  page_image_count:number;
  api_image_count:number;
  page_manifest_sha256:string;
  links:BrowserImageLink[];
  external_embedding_status:'unverified';
  image_bytes_collected:false;
  rights_reviewed:false;
} | {
  ok:false;
  error:'invalid_record'|'page_security_block'|'page_http_error'|'page_not_html'|'page_record_mismatch'|'page_images_missing'|'page_too_large'|'page_timeout'|'page_connection_error';
  message:string;
  captured_at:string;
};

const messages:Record<Extract<BrowserLinksResult,{ok:false}>['error'],string> = {
  invalid_record:'소장품 ID를 확인하지 못했습니다.',
  page_security_block:'원문 요청이 e뮤지엄 보안 정책에 의해 차단되었습니다. 다른 주소로 재시도하지 않았습니다.',
  page_http_error:'e뮤지엄 원문 조회가 완료되지 않았습니다. 이미지 표시 결과와는 별개입니다.',
  page_not_html:'원문 페이지 형식을 확인하지 못했습니다.',
  page_record_mismatch:'원문이 선택한 소장품의 페이지인지 확인하지 못했습니다.',
  page_images_missing:'해당 원문에서 시험에 사용할 이미지 항목을 찾지 못했습니다.',
  page_too_large:'원문 응답이 이번 연결 시험의 처리 범위를 초과했습니다.',
  page_timeout:'원문에서 이미지 주소를 확인하는 시간이 초과되었습니다.',
  page_connection_error:'원문에서 이미지 주소를 확인하지 못했습니다.',
};
const fail=(error:Extract<BrowserLinksResult,{ok:false}>['error'],captured_at:string):BrowserLinksResult=>({ok:false,error,message:messages[error],captured_at});
const decodeAttribute=(s:string)=>s.replace(/&amp;/gi,'&').replace(/&quot;/gi,'"').replace(/&#39;|&apos;/gi,"'");
function attrs(tag:string):Record<string,string> {
  const result:Record<string,string>=Object.create(null);
  for(const m of tag.matchAll(/([\w:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g)) {
    const key=m[1].toLowerCase();
    if(key in result)return Object.create(null);
    result[key]=decodeAttribute(m[2]??m[3]??'');
  }
  return result;
}

// This is a narrow URL-safety check, NOT verification that embedding is allowed
// or that an opaque /IMG/ address is permanent. Never expose /openapi/img tokens.
export function browserImageURL(raw:string,base='https://www.emuseum.go.kr',serviceKey=''):string|null {
  if(!raw||raw.length>4096||/[\s\\<>]/.test(raw)||redactSecrets(raw,serviceKey)!==raw)return null;
  try {
    const u=new URL(raw,base);
    if(u.protocol!=='https:'||!['emuseum.go.kr','www.emuseum.go.kr'].includes(u.hostname)||u.username||u.password||u.port||u.search||u.hash)return null;
    if(!/^\/IMG\/[A-Za-z0-9+/_=-]+$/.test(u.pathname))return null;
    return u.href;
  } catch{return null;}
}

export async function parseBrowserImageLinks(html:string,target:BrowserImageTarget,sourceURL:string,capturedAt:string,serviceKey=''):Promise<BrowserLinksResult> {
  if(!/^[A-Za-z0-9_-]{1,100}$/.test(target.recordId))return fail('invalid_record',capturedAt);
  if(isSecurityBlockHTML(html))return fail('page_security_block',capturedAt);
  const markup=html.replace(/<!--[\s\S]*?-->/g,'').replace(/<(script|style|template|noscript)\b[^>]*>[\s\S]*?<\/\1\s*>/gi,'');
  const recordIds:string[]=[],rows:{element:string;id:string|null;url:string|null}[]=[];
  for(const m of markup.matchAll(/<(?:input|img)\b(?:"[^"]*"|'[^']*'|[^'">])*>/gi)) {
    const a=attrs(m[0]);
    if(/^<input\b/i.test(m[0])&&a.type?.toLowerCase()==='hidden'&&a.name==='relicId')recordIds.push(a.value??'');
    if(/^<img\b/i.test(m[0])&&(a.class??'').split(/\s+/).includes('mi')&&/^img_\d+$/.test(a.id??'')) {
      rows.push({element:a.id,id:/^[A-Za-z0-9_-]{1,100}$/.test(a['data-img-id']??'')?a['data-img-id']:null,url:browserImageURL(a.src??'',sourceURL,serviceKey)});
    }
  }
  if(!recordIds.length||recordIds.some(id=>id!==target.recordId))return fail('page_record_mismatch',capturedAt);
  if(!rows.length)return fail('page_images_missing',capturedAt);
  if(rows.length>100)return fail('page_too_large',capturedAt);
  const links:BrowserImageLink[]=[];
  for(const [i,row] of rows.entries()) {
    let matched:BrowserImageTarget['images'][number]|undefined;
    let basis:BrowserImageLink['match_basis']='record_only';
    const candidates=target.images.filter(image=>image.record_id===target.recordId&&image.img_id_raw===row.id&&image.img_id_raw!==target.recordId);
    if(row.id&&candidates.length===1&&rows.filter(r=>r.id===row.id).length===1){matched=candidates[0];basis='exact_unique_image_id';}
    else if(target.imageTotalCount===1&&target.images.length===1&&rows.length===1&&target.images[0].record_id===target.recordId){matched=target.images[0];basis='single_image_in_both_sources';}
    links.push({ordinal:i+1,page_element_id:row.element,page_img_id_raw:row.id,url:row.url,url_sha256:row.url?await sha256(row.url):null,
      api_observation_id:matched?.observation_id??null,api_ordinal:matched?.ordinal??null,match_basis:basis});
  }
  // Hash only the address manifest; this is deliberately NOT an image-file hash.
  const manifest=links.map(({url,...link})=>link);
  return {ok:true,record_id:target.recordId,source_url:sourceURL,source_url_origin:'generated',captured_at:capturedAt,
    page_image_count:rows.length,api_image_count:target.images.length,page_manifest_sha256:await sha256(JSON.stringify(manifest)),links,
    external_embedding_status:'unverified',image_bytes_collected:false,rights_reviewed:false};
}

export async function discoverBrowserImageLinks(target:BrowserImageTarget,serviceKey='',fetcher:typeof fetch=fetch):Promise<BrowserLinksResult> {
  const at=new Date().toISOString();
  if(!/^[A-Za-z0-9_-]{1,100}$/.test(target.recordId))return fail('invalid_record',at);
  const page=new URL('https://www.emuseum.go.kr/detail');page.searchParams.set('relicId',target.recordId);
  try {
    // One ordinary HTML request, with an honest client identity. No image fetch,
    // cookie forwarding, retry loop, alternate host, or Referer/fingerprint trick.
    const response=await fetcher(page,{headers:{Accept:'text/html','User-Agent':'HeritageEvalResearch/0.1'},redirect:'manual',signal:AbortSignal.timeout(20000)});
    const type=(response.headers.get('content-type')??'').split(';')[0].trim().toLowerCase();
    if(type!=='text/html'){await response.body?.cancel();return fail(response.ok?'page_not_html':'page_http_error',at);}
    const html=new TextDecoder().decode(await boundedBody(response,2_000_000));
    if(isSecurityBlockHTML(html))return fail('page_security_block',at);
    if(!response.ok)return fail('page_http_error',at);
    return await parseBrowserImageLinks(html,target,page.href,at,serviceKey);
  } catch(error) {
    const name=(error as Error).name,message=(error as Error).message;
    return fail(message==='RESPONSE_TOO_LARGE'?'page_too_large':['AbortError','TimeoutError'].includes(name)?'page_timeout':'page_connection_error',at);
  }
}
