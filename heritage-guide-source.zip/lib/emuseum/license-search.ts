import type { Capture, HeritageRecord } from '../model';
import { interpretRecordRights } from '../rights.ts';

export type LicenseFilter = '1' | '2' | '3' | '4' | 'unconfirmed';
export function observedLicense(record: HeritageRecord): LicenseFilter {
  const rights = interpretRecordRights(record.rights);
  const type = rights.license_type_verified?.[0];
  return rights.verification_status === 'verified' && ['1','2','3','4'].includes(type ?? '') ? type as LicenseFilter : 'unconfirmed';
}
export const needsDetailRights = (record: HeritageRecord) => record.rights.glsv_presence === 'missing' || record.rights.glsv_presence === 'empty';
export function endOfList(capture: Capture) {
  const n = capture.normalized;
  // A failed call is never an empty successful result.
  return n.ok && (n.records.length === 0 || (n.total_count !== null && n.page_no * n.page_size >= n.total_count));
}
export type LicenseMatch = {record:HeritageRecord;listCapture:Capture;ordinal:number;detailCapture?:Capture};
