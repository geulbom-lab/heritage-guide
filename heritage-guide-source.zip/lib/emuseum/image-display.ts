import { z } from 'zod';
import type { BrowserImageDisplay, ImageDisplayReport, Parsed } from '../model';

export const imageDisplayReportSchema=z.object({
  status:z.enum(['loaded','failed','timed_out']),
  observed_at:z.string().datetime(),
  width:z.number().int().min(1).max(100000).nullable(),
  height:z.number().int().min(1).max(100000).nullable(),
}).strict().refine(r=>r.status==='loaded'?r.width!==null&&r.height!==null:r.width===null&&r.height===null);

export function imageSelectorExists(normalized:Parsed,selector:string):boolean {
  if(!normalized.ok||!/^(?:record-)?[1-9]\d{0,5}$/.test(selector))return false;
  const record=selector.match(/^record-(\d+)$/);
  return record?Boolean(normalized.records[Number(record[1])-1]):normalized.images.some(i=>i.ordinal===Number(selector));
}

// Identity comes from the authenticated owner's API capture. Display status is
// the browser's report, not server inspection of the file or a rights decision.
export function attachImageDisplay(report:ImageDisplayReport,captureId:string,imageId:string,ordinal:number,version:string):BrowserImageDisplay {
  return {schema:'eval-v2.image-display.v1',status:report.status,observed_at:report.observed_at,width:report.width,height:report.height,
    capture_id:captureId,image_observation_id:imageId,selector:String(ordinal),basis:'browser_reported',
    display_method:'api_provided_image_delivery_address_in_owner_browser',image_bytes_collected:false,image_file_sha256:null,version};
}
