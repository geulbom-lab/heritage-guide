import type { Parsed, RawField, SourceKind, SourceStatus } from '../model';
import { fieldValue, unknownRights } from '../domain.ts';
import { interpretRecordRights } from '../rights.ts';

type Node = { tag: string; qualified: string; attrs: Record<string, string>; children: Node[]; text: string };
const decode = (s: string) => {
  if (/&(?!(?:amp|lt|gt|quot|apos|#\d+|#x[\da-f]+);)/i.test(s)) throw Error('INVALID_XML');
  return s.replace(/&#(x[\da-f]+|\d+);/gi, (_, v) => String.fromCodePoint(/^x/i.test(v) ? parseInt(v.slice(1),16) : Number(v)))
    .replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&apos;/g,"'").replace(/&amp;/g,'&');
};
export function xmlTree(raw: string): Node {
  if (/<!DOCTYPE|<!ENTITY/i.test(raw)) throw Error('INVALID_XML');
  raw = raw.replace(/^\uFEFF/, '');
  const root: Node = {tag:'root',qualified:'root',attrs:{},children:[],text:''}, stack = [root];
  const tokens = raw.match(/<!\[CDATA\[[\s\S]*?\]\]>|<!--[\s\S]*?-->|<\?[\s\S]*?\?>|<(?:"[^"]*"|'[^']*'|[^'">])*>|[^<]+/g) || [];
  if (tokens.join('') !== raw) throw Error('INVALID_XML');
  for (const token of tokens) {
    const top = stack[stack.length - 1];
    if (token.startsWith('<?') || token.startsWith('<!--')) continue;
    if (token.startsWith('<![CDATA[')) { if (stack.length === 1) throw Error('INVALID_XML'); top.text += token.slice(9,-3); continue; }
    if (token.startsWith('</')) {
      const name = token.match(/^<\/([\w:.-]+)\s*>$/)?.[1];
      if (stack.length === 1 || top.qualified !== name) throw Error('INVALID_XML'); stack.pop(); continue;
    }
    if (token.startsWith('<')) {
      const match = token.match(/^<([\w:.-]+)([\s\S]*?)(\/?)>$/); if (!match) throw Error('INVALID_XML');
      const attrs: Record<string,string> = Object.create(null);
      const rest = match[2].replace(/\s+([\w:.-]+)\s*=\s*(?:"([^"<]*)"|'([^'<]*)')/g, (_, name, a, b) => {
        const k = name.split(':').pop(); if (Object.hasOwn(attrs,k)) throw Error('INVALID_XML'); attrs[k] = decode(a ?? b); return '';
      });
      if (rest.trim() || stack.length > 64) throw Error('INVALID_XML');
      const n: Node = {tag:match[1].split(':').pop()!,qualified:match[1],attrs,children:[],text:''};
      top.children.push(n); if (!match[3]) stack.push(n);
    } else top.text += decode(token);
  }
  if (stack.length !== 1 || root.children.length !== 1 || root.text.trim()) throw Error('INVALID_XML');
  return root.children[0];
}
const child = (n: Node | undefined, name: string) => n?.children.find(c => c.tag.toLowerCase() === name.toLowerCase());
const fields = (n?: Node): RawField[] => (n?.children ?? []).filter(c => !c.children.length).map(c => ({
  key: c.tag.toLowerCase() === 'item' && c.attrs.key !== undefined ? c.attrs.key : c.tag,
  value: c.attrs.value ?? c.text,
}));
const field = (n: Node | undefined, key: string) => fieldValue(fields(n), key);
const count = (value: string | null) => value !== null && /^\d+$/.test(value.trim()) && Number.isSafeInteger(Number(value)) ? Number(value) : null;
const listRows = (n?: Node): Node[] | null => {
  if (!n) return null;
  if (n.children.some(c => !['data','item'].includes(c.tag.toLowerCase()) || !c.children.length)) return n.children.length ? null : [];
  return n.children;
};
export function emptyParsed(status: SourceStatus, page = 1, size = 10): Parsed {
  return {ok:false,status,result_code:null,result_message:null,total_count:null,page_no:page,page_size:size,response_schema:'unverified',
    records:[],images:[],images_container:'missing',image_total_count:null,codes:[],warnings:[]};
}
function errorStatus(code: string, msg: string): SourceStatus {
  if (code === '10' || /INVALID_REQUEST_PARAMETER/i.test(msg)) return 'parameter_error';
  if (['20','30','31'].includes(code) || /SERVICE_KEY_|PERMISSION_DENIED|SERVICE_ACCESS_DENIED|DEADLINE_HAS_EXPIRED/i.test(msg)) return 'authentication_error';
  if (['22','23'].includes(code)) return 'rate_limit_error';
  if (code === '29') return 'access_error';
  return 'upstream_error';
}
export function parseXML(raw: string, kind: SourceKind, captureId: string, page = 1, size = 10): Parsed {
  const result = emptyParsed('schema_error', page, size);
  if (!raw.trim()) return {...result,status:'empty_response'};
  if (/<\s*(?:!doctype\s+html|html|body)\b/i.test(raw)) return {...result,status:/block\s*page|access\s*denied|request\s*blocked|접근.{0,10}차단/i.test(raw) ? 'blocked_html' : 'unexpected_html'};
  let root: Node; try { root = xmlTree(raw); } catch { return {...result,status:'invalid_xml'}; }
  const body = child(root,'body') ?? root, header = child(root,'header') ?? root, auth = child(root,'cmmMsgHeader');
  result.result_code = field(header,'resultCode') ?? field(body,'resultCode') ?? field(auth,'returnReasonCode');
  result.result_message = field(header,'resultMsg') ?? field(body,'resultMsg') ?? field(auth,'returnAuthMsg') ?? field(auth,'errMsg');
  if (result.result_code === null) return result;
  if (!['0000','00','0'].includes(result.result_code.trim())) return {...result,status:errorStatus(result.result_code.trim(),result.result_message ?? '')};
  const list = child(body,'list') ?? child(body,'items'), rows = listRows(list);
  result.total_count = count(field(body,'totalCount'));
  if (!rows) return result;
  const allFields = rows.map(fields);
  result.response_schema = rows.some(r => r.children.some(c => c.attrs.key !== undefined)) ? (rows.some(r => r.children.some(c => c.attrs.key === undefined)) ? 'mixed' : 'attribute-items') : 'element-fields';
  if (kind === 'code') {
    result.codes = allFields;
    if (allFields.some(fs => !fieldValue(fs,'code'))) { result.warnings.push('공식 코드 응답의 code 필드를 확인할 수 없습니다.'); return result; }
  } else {
    result.records = allFields.map((fs, i) => {
      const get = (name: string) => fieldValue(fs, name), id = get('id');
      const supplied = get('sourceUrl') ?? get('source_url');
      const safe = (s: string | null) => { try { const u = new URL(s!); return ['https:','http:'].includes(u.protocol) && !u.username && !u.password && !/servicekey|apikey|token|redacted/i.test(u.href) ? u.href : null; } catch { return null; } };
      const source = safe(supplied);
      return {observation_id:`${captureId}:record:${i+1}`,id,title:get('nameKr') || get('name') || '',institution:get('museumName2') || '',
        collection_number:get('relicNo'),collection_subnumber:get('relicSubNo'),author_raw:get('author'),description:get('description') ?? get('desc'),
        source_url:source ?? (id ? `https://www.emuseum.go.kr/detail?relicId=${encodeURIComponent(id)}` : null),
        source_url_origin:source ? 'api' as const : id ? 'generated' as const : 'missing' as const,source_url_status:'unverified' as const,
        thumbnail_uri:get('imgThumUriM') ?? get('imgThumUriS') ?? get('imgThumUriL') ?? get('imgThumUri') ?? get('imgThumbUri') ?? get('imgUri'),raw_fields:fs,
        rights:interpretRecordRights(unknownRights(fs,'record',`list/data[${i+1}]/glsv`))};
    });
    if (result.records.some(r => !r.id)) result.warnings.push('고유 ID가 누락된 기록은 상세조회할 수 없습니다.');
    const imageList = child(body,'imageList');
    result.images_container = imageList ? 'present' : 'missing';
    result.image_total_count = count(field(imageList,'totalCount'));
    if (imageList) {
      const imageRows = listRows(child(imageList,'list') ?? child(imageList,'items'));
      if (!imageRows) { result.warnings.push('이미지 목록 구조를 확인할 수 없습니다.'); return result; }
      result.images = imageRows.map((node,i) => {
        const fs = fields(node), get = (key: string) => fieldValue(fs,key);
        return {observation_id:`${captureId}:image:${i+1}`,capture_id:captureId,record_id:get('id'),img_id_raw:get('imgId'),img_order_raw:get('imgOrder'),ordinal:i+1,
          uri_redacted:get('imgUri'),thumbnail_uri_redacted:get('imgThumUriM') ?? get('imgThumUriS') ?? get('imgThumUriL') ?? get('imgThumUri') ?? get('imgThumbUri'),raw_fields:fs,rights:unknownRights(fs,'image',`imageList/list/data[${i+1}]/glsv`)};
      });
      if (new Set(result.images.map(i => i.img_id_raw)).size < result.images.length) result.warnings.push('imgId 중복이 관찰되었습니다. 응답 내 이미지 순번으로 모두 보존했습니다.');
      if (result.image_total_count !== null && result.image_total_count !== result.images.length) result.warnings.push('이미지 totalCount와 파싱 수가 다릅니다. 원시 응답을 확인하세요.');
    }
  }
  if (result.total_count !== null && result.total_count > 0 && rows.length === 0 && page === 1) return result;
  return {...result,ok:true,status:rows.length ? 'success' : 'empty_result'};
}
