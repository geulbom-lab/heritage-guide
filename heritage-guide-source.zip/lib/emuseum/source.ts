import type { Capture, SourceKind } from '../model';
import { VERSION } from '../domain.ts';
import { parseXML, emptyParsed } from './xml.ts';
import { boundedBody, redactObject, redactSecrets, sha256 } from './security.ts';
import { assignImageKeys } from './identity.ts';
import { sealImageLinks } from './image-delivery.ts';

export const NEW_BASE = 'https://apis.data.go.kr/1371027/openapi';
export type SourceInput = {kind:SourceKind;query?:string;id?:string;parentCode?:string;page:number;size:number;browse?:boolean};
export function requestParameters(input: SourceInput): Record<string,string|number> {
  if (!['list','detail','code'].includes(input.kind) || !Number.isSafeInteger(input.page) || input.page < 1 || input.page > 10000 || !Number.isSafeInteger(input.size) || input.size < 1 || input.size > 100) throw Error('INVALID_PARAMETERS');
  if (input.kind === 'list') {
    if ((!input.query?.trim() && !input.browse) || (input.query?.length ?? 0) > 150) throw Error('INVALID_PARAMETERS');
    return {...(input.query?.trim() ? {name:input.query.trim()} : {}),pageNo:input.page,numOfRows:input.size};
  }
  if (input.kind === 'detail') { if (!/^[A-Za-z0-9_-]{1,100}$/.test(input.id ?? '')) throw Error('INVALID_PARAMETERS'); return {id:input.id!}; }
  if (input.parentCode && !/^[A-Za-z0-9_-]{1,80}$/.test(input.parentCode)) throw Error('INVALID_PARAMETERS');
  return {pageNo:input.page,numOfRows:input.size,...(input.parentCode ? {parentCode:input.parentCode} : {})};
}
export async function collect(input: SourceInput, key: string, fetcher: typeof fetch = fetch, imageProtectionKey = ''): Promise<{capture:Capture;raw:string|null;sealedImageLinks:string|null}> {
  const parameters = requestParameters(input), id = crypto.randomUUID(), endpoint = `${NEW_BASE}/${input.kind}`;
  let normalized = emptyParsed('key_missing',input.page,input.size), raw: string|null = null, response: Response|null = null;
  let sealedImageLinks:string|null=null;
  if (key) {
    // This authenticated URL exists only in server memory and is never stored or logged.
    const upstream = new URL(endpoint); for (const [k,v] of Object.entries(parameters)) upstream.searchParams.set(k,String(v)); upstream.searchParams.set('serviceKey',key);
    try {
      response = await fetcher(upstream,{headers:{Accept:'application/xml'},redirect:'manual',signal:AbortSignal.timeout(25000)});
      const upstreamXML=new TextDecoder().decode(await boundedBody(response,4_000_000));
      raw = redactSecrets(upstreamXML,key);
      normalized = await assignImageKeys(parseXML(raw,input.kind,id,input.page,input.size));
      if (response.ok && normalized.ok && imageProtectionKey) sealedImageLinks=await sealImageLinks(upstreamXML,input.kind,id,imageProtectionKey);
      if (!response.ok && !['authentication_error','parameter_error','rate_limit_error','access_error','blocked_html','unexpected_html'].includes(normalized.status)) normalized = {...normalized,ok:false,status:'http_error'};
    } catch (e) {
      const err = e as Error;
      normalized = emptyParsed(err.message === 'IMAGE_PROTECTION_UNAVAILABLE' ? 'storage_unavailable' : err.message === 'RESPONSE_TOO_LARGE' ? 'response_too_large' : ['AbortError','TimeoutError'].includes(err.name) ? 'timeout' : 'transport_error',input.page,input.size);
    }
  }
  const capture: Capture = redactObject({capture_id:id,kind:input.kind,endpoint,request_parameters:parameters,captured_at:new Date().toISOString(),
    http_status:response?.status ?? null,content_type:response?.headers.get('content-type') ?? null,raw_sha256:raw === null ? null : await sha256(raw),
    storage_status:'not_saved',version:VERSION,normalized},key);
  return {capture,raw,sealedImageLinks};
}
