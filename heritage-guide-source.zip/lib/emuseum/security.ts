// Secrets are removed before research parsing, evidence storage, hashing or browser serialization.
export function redactSecrets(value: string, key = ''): string {
  let clean = String(value);
  const escape = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  if (key) {
    const xml = key.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;');
    const variants = new Set([key,encodeURIComponent(key),encodeURIComponent(encodeURIComponent(key)),new URLSearchParams({v:key}).toString().slice(2),xml]);
    for (const v of variants) if (v) clean = clean.replace(new RegExp(escape(v),'gi'),'[REDACTED]');
    const numeric = [...key].map(c => `(?:${escape(c)}|&#0*${c.codePointAt(0)};|&#x0*${c.codePointAt(0)!.toString(16)};)`).join('');
    clean = clean.replace(new RegExp(numeric,'gi'),'[REDACTED]');
  }
  return clean.replace(/([?&](?:amp;)?(?:serviceKey|apiKey|access_token)=)[^&\s"'<>]*/gi,'$1[REDACTED]')
    .replace(/(<(?:[\w.-]+:)?(?:serviceKey|apiKey)\b[^>]*>)[\s\S]*?(<\/(?:[\w.-]+:)?(?:serviceKey|apiKey)\s*>)/gi,'$1[REDACTED]$2')
    .replace(/<[^<>]+>/g, tag => {
      if (/\bkey\s*=\s*(["'])(?:serviceKey|apiKey)\1/i.test(tag)) tag = tag.replace(/(\bvalue\s*=\s*)(["'])[\s\S]*?\2/gi,'$1"[REDACTED]"');
      return tag.replace(/(\b(?:serviceKey|apiKey)\s*=\s*)(["'])[\s\S]*?\2/gi,'$1"[REDACTED]"');
    }).replace(/("(?:serviceKey|apiKey)"\s*:\s*")[^"]*/gi,'$1[REDACTED]');
}
export function redactObject<T>(object: T, key: string): T {
  if (typeof object === 'string') return redactSecrets(object,key) as T;
  if (Array.isArray(object)) return object.map(v => redactObject(v,key)) as T;
  if (object && typeof object === 'object') return Object.fromEntries(Object.entries(object).map(([k,v]) => [k,redactObject(v,key)])) as T;
  return object;
}
export async function sha256(raw: string): Promise<string> {
  const bytes = await crypto.subtle.digest('SHA-256',new TextEncoder().encode(raw));
  return Array.from(new Uint8Array(bytes), v => v.toString(16).padStart(2,'0')).join('');
}
export async function boundedBody(response: Response, limit: number): Promise<Uint8Array> {
  if (Number(response.headers.get('content-length')) > limit) throw Error('RESPONSE_TOO_LARGE');
  if (!response.body) return new Uint8Array();
  const reader = response.body.getReader(), chunks: Uint8Array[] = []; let total = 0;
  try { while (true) { const {value,done} = await reader.read(); if (done) break; total += value.byteLength; if (total > limit) { await reader.cancel(); throw Error('RESPONSE_TOO_LARGE'); } chunks.push(value); } }
  finally { reader.releaseLock(); }
  const bytes = new Uint8Array(total); let offset = 0; for (const c of chunks) { bytes.set(c,offset); offset += c.length; } return bytes;
}
// A stored API URL is not an arbitrary proxy target. No redirects or credentials to other hosts.
export function imageURL(raw: string | null): URL | null {
  if (!raw || raw.length > 12000) return null;
  try {
    const u = new URL(raw);
    if (!['http:','https:'].includes(u.protocol) || !['www.emuseum.go.kr','emuseum.go.kr'].includes(u.hostname) || u.port || u.username || u.password || u.pathname !== '/openapi/img') return null;
    if (u.hash || /redacted/i.test(u.href) || [...u.searchParams.keys()].some(k => !['imageId','serviceKey'].includes(k))) return null;
    if (['imageId','serviceKey'].some(k => u.searchParams.getAll(k).length !== 1 || !u.searchParams.get(k))) return null;
    // Keep the response-provided opaque token and query encoding unchanged.
    // Never substitute the data.go.kr service key or downgrade to cleartext HTTP.
    u.protocol = 'https:';
    return u;
  } catch { return null; }
}

function credentialVariants(value:string):Set<string> {
  const variants=new Set<string>(),pending=[String(value)];
  while(pending.length&&variants.size<8) {
    const current=pending.shift()!;
    if(!current||variants.has(current))continue;
    variants.add(current);
    try {const decoded=decodeURIComponent(current);if(decoded!==current)pending.push(decoded);} catch {}
    try {const form=new URLSearchParams(`v=${current}`).get('v');if(form&&form!==current)pending.push(form);} catch {}
  }
  return variants;
}

// The public image URL returned in /detail has its own opaque serviceKey
// parameter. It may reach the owner's browser only when it is demonstrably
// different from the private data.go.kr key used to call /list and /detail.
export function isDistinctImageDeliveryCredential(url:URL,privateApiKey:string):boolean {
  const delivery=url.searchParams.get('serviceKey');
  if(!delivery||!privateApiKey)return false;
  const a=credentialVariants(delivery),b=credentialVariants(privateApiKey);
  return ![...a].some(value=>b.has(value));
}
