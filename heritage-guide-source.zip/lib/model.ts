export type Choice = 'yes' | 'no' | 'unknown';
export type RawField = { key: string; value: string };
export type Rights = {
  glsv_raw: string | null;
  glsv_presence: 'missing' | 'empty' | 'present';
  license_type_verified: string[] | null;
  license_code_source: string | null;
  applies_to: 'record' | 'all_images' | 'record_all_images' | 'individual_image' | 'unknown';
  scope_evidence: string | null;
  verified_at: string | null;
  verification_status: 'verified' | 'partial' | 'unknown' | 'conflict';
  observed_location: 'record' | 'image';
  observed_path: string;
  verification_basis?: string | null;
  verified_by_role?: string | null;
  official_condition_source?: string | null;
  public_api_documentation_status?: 'partial';
  effective_source?: 'api' | 'emuseum_detail_page' | 'none';
  source_conflict?: boolean;
  conflict_resolution?: 'detail_page_priority' | null;
  license_observation_source?: string | null;
};
export type HeritageRecord = {
  observation_id: string; id: string | null; title: string; institution: string;
  collection_number: string | null; collection_subnumber?: string | null; author_raw: string | null; description: string | null;
  source_url: string | null; source_url_origin: 'api' | 'generated' | 'missing';
  source_url_status: 'unverified'; thumbnail_uri: string | null;
  raw_fields: RawField[]; rights: Rights;
};
export type PageReview = {
  record_id: string;
  source_url: string;
  status: 'reviewed' | 'no_mark' | 'blocked' | 'unavailable';
  license_type: '1' | '2' | '3' | '4' | 'outside_scope' | null;
  displayed_rights_text: string;
  record_match_confirmed: boolean;
  reviewer: string;
  observed_at: string;
  method: 'researcher_manual';
  recorded_at?: string;
  evidence_sha256?: string;
};
export type HeritageImage = {
  observation_id: string; capture_id: string; record_id: string | null;
  img_id_raw: string | null; img_order_raw: string | null; ordinal: number;
  uri_redacted: string | null; thumbnail_uri_redacted: string | null;
  raw_fields: RawField[]; rights: Rights;
  research_image_key?: string | null;
  research_image_fingerprint?: string | null;
  img_uri_sha256?: string | null;
  identity_status?: 'composite' | 'duplicate_tuple' | 'incomplete';
};
export type SourceKind = 'list' | 'detail' | 'code';
export type SourceStatus = 'success' | 'empty_result' | 'empty_response' | 'authentication_error' |
  'parameter_error' | 'rate_limit_error' | 'access_error' | 'upstream_error' | 'http_error' |
  'transport_error' | 'timeout' | 'invalid_xml' | 'unexpected_html' | 'blocked_html' |
  'schema_error' | 'key_missing' | 'response_too_large' | 'storage_unavailable';
export type Parsed = {
  ok: boolean; status: SourceStatus; result_code: string | null; result_message: string | null;
  total_count: number | null; page_no: number; page_size: number; response_schema: string;
  records: HeritageRecord[]; images: HeritageImage[]; images_container: 'missing' | 'present';
  image_total_count: number | null; codes: RawField[][]; warnings: string[];
};
export type Capture = {
  capture_id: string; kind: SourceKind; endpoint: string;
  request_parameters: Record<string, string | number>; captured_at: string;
  http_status: number | null; content_type: string | null; raw_sha256: string | null;
  storage_status: 'saved' | 'not_saved'; version: string; normalized: Parsed;
};
export type Candidate = {
  candidate_id: string; record: HeritageRecord; image: HeritageImage;
  capture: Omit<Capture, 'normalized'>;
  search_context: { query: string; page: number; capture_id: string | null };
  page_review?: PageReview | null;
  effective_rights?: Rights;
  image_delivery?: ImagePreviewReceipt | null;
  image_display?: BrowserImageDisplay | null;
};
export type ImageDisplayReport = {
  status:'loaded'|'failed'|'timed_out';
  observed_at:string;
  width:number|null;
  height:number|null;
};
export type BrowserImageDisplay = ImageDisplayReport & {
  schema:'eval-v2.image-display.v1';
  capture_id:string;
  image_observation_id:string;
  selector:string;
  basis:'browser_reported';
  display_method:'api_provided_image_delivery_address_in_owner_browser';
  image_bytes_collected:false;
  image_file_sha256:null;
  version:string;
};
export type ImagePreviewReceipt = {
  schema:'eval-v2.image-preview.v1';
  version:string;
  capture_id:string;
  selector:string;
  source:'api_image_uri'|'emuseum_detail_page';
  record_id:string|null;
  retrieved_at:string;
  image_sha256:string;
  content_type:string;
  byte_length:number;
  page_evidence:import('./emuseum/image-delivery').PageImageEvidence|null;
};
export type Usage = { commercial: Choice; modification: Choice; input_source: 'user_explicit'; confirmed_at: string | null };
export type Relation = 'unreviewed' | 'same_object' | 'same_work' | 'same_work_family' | 'similar' | 'different';
export type ReviewGroup = {
  id: string; title: string; member_ids: string[]; relation: Relation; rationale: string;
  evidence_urls: string[]; reviewer: string; reviewed_at: string | null;
};
export type Decision = {
  status: 'rights_unconfirmed' | 'rights_conflict' | 'actions_needed' | 'conditions_restricted' | 'conditions_satisfied';
  message: string; reason: string; version: string;
  source_conflict?: boolean;
  effective_source?: Rights['effective_source'];
  attribution_required?: boolean;
  official_condition_source?: string;
};
export type QueryHistory = { query: string; page: number; capture_id: string; captured_at: string; status: SourceStatus };
export type ResearchSession = {
  schema: string; id: string; title: string; question: string; usage: Usage;
  candidates: Candidate[]; groups: ReviewGroup[]; query_history: QueryHistory[];
  decisions: { candidate_id: string; result: Decision; attribution_draft: string }[];
  version: string; saved_at: string;
  rule_context?: Record<string, unknown>;
};
