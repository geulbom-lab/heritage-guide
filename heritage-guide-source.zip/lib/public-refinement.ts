import {publicCapture,publicRecord,publicImage} from './public-source';
import {relevantTitle,refineRecords} from './public-search';

// Complete retrieval only. Never label a bounded subset as all search results.
export async function refinedSearch(terms:string[],page:number,within:string,institution:string){
  const first=await Promise.all(terms.map(query=>publicCapture({kind:'list',query,page:1,size:100})));
  if(first.some(v=>!v.capture.normalized.ok||v.capture.normalized.total_count===null))throw Error('전체 검색 범위를 확인하지 못했어요. 잠시 후 다시 시도해 주세요.');
  const count=first.reduce((n,v)=>n+v.capture.normalized.total_count!,0);
  if(count>2000)throw Error('검색 결과가 많아 전체 결과를 좁히기 어려워요. 검색어 수정에서 더 구체적인 자료 이름을 입력해 주세요.');
  const jobs=terms.flatMap((query,i)=>Array.from({length:Math.max(0,Math.ceil(first[i].capture.normalized.total_count!/100)-1)},(_,j)=>({query,page:j+2})));
  const captures=[...first];
  for(let i=0;i<jobs.length;i+=4){
    const batch=await Promise.all(jobs.slice(i,i+4).map(j=>publicCapture({kind:'list',...j,size:100})));
    if(batch.some(v=>!v.capture.normalized.ok))throw Error('전체 결과 중 일부를 가져오지 못했어요. 조건을 적용하지 않았으니 다시 시도해 주세요.');
    captures.push(...batch);
  }
  for(let i=0;i<terms.length;i++){
    const group=captures.filter(v=>v.capture.request_parameters.name===terms[i]);
    if(group.reduce((n,v)=>n+v.capture.normalized.records.length,0)<first[i].capture.normalized.total_count!)throw Error('전체 결과를 확인하지 못했어요. 잠시 후 다시 시도해 주세요.');
  }
  const seen=new Set<string>();
  const entries=captures.flatMap(v=>v.capture.normalized.records.map((r,index)=>({record:publicRecord(r,v.capture.captured_at),capture:v,index}))).filter(v=>{
    if(!v.record.id||seen.has(v.record.id)||!relevantTitle(v.record.title,terms))return false;
    seen.add(v.record.id);return true;
  });
  const institutions=[...new Set(entries.map(v=>v.record.institution))].sort((a,b)=>a.localeCompare(b,'ko'));
  const matches=refineRecords(entries,within,institution);
  const total=matches.length,totalPages=Math.max(1,Math.ceil(total/12)),current=Math.min(page,totalPages);
  const records=await Promise.all(matches.slice((current-1)*12,current*12).map(async v=>({...v.record,image:await publicImage(v.capture.sealedImageLinks,v.capture.capture.capture_id,`record-${v.index+1}`)})));
  return {records,total,totalPages,page:current,hasNext:current<totalPages,checkedAt:first[0].capture.captured_at,searchTerms:terms,partial:false,institutions,refined:true,within,institution};
}
