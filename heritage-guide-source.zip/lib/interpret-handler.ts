import { readBoundedJSON, type QuestionAnalysis } from './question-analysis.ts';

type Analyzer = (question: string, signal: AbortSignal) => Promise<QuestionAnalysis>;
export function makeInterpretHandler(analyze: Analyzer, acquire: (request: Request) => (() => void) | null) {
  return async (request: Request) => {
    const reply = (body: object, status = 200) => Response.json(body, { status, headers: { 'Cache-Control': 'no-store' } });
    if (request.headers.get('origin') !== new URL(request.url).origin) return reply({ message: '이 사이트에서 검색해 주세요.' }, 403);
    if (!request.headers.get('content-type')?.startsWith('application/json')) return reply({ message: '입력 형식을 확인해 주세요.' }, 415);
    let question: string;
    try {
      const value = await readBoundedJSON(request.body, 4096);
      if (!value || typeof value !== 'object' || Array.isArray(value) || Object.keys(value).length !== 1 || !('question' in value) || typeof value.question !== 'string' || !value.question.trim() || value.question.length > 700) throw Error('Invalid question');
      question = value.question.trim();
    } catch { return reply({ message: '질문을 1~700자로 적어 주세요.' }, 400); }
    if (request.signal.aborted) return reply({ message: '검색을 취소했어요.' }, 499);
    const release = acquire(request);
    if (!release) return reply({ message: '문장 분석 요청이 많아요. 잠시 후 다시 시도해 주세요.' }, 429);
    try { return reply(await analyze(question, request.signal)); }
    catch { return reply({ message: '문장 분석을 완료하지 못했어요.' }, 503); }
    finally { release(); }
  };
}

// Per-isolate limits bound request bursts and concurrency. These are not a
// replacement for the API project's billing limits or a distributed rate limit.
export function createInterpretLimiter(now: () => number = Date.now) {
  const buckets = new Map<string, { count: number; until: number }>();
  let active = 0, total = 0, until = 0;
  return (request: Request): (() => void) | null => {
    const time = now();
    if (time >= until) { total = 0; until = time + 60000; }
    for (const [key, bucket] of buckets) if (time >= bucket.until) buckets.delete(key);
    const ip = request.headers.get('cf-connecting-ip') || 'unknown';
    const bucket = buckets.get(ip) ?? { count: 0, until: time + 60000 };
    if (active >= 4 || total >= 60 || bucket.count >= 10 || (!buckets.has(ip) && buckets.size >= 1000)) return null;
    bucket.count++; buckets.set(ip, bucket); total++; active++;
    let released = false;
    return () => { if (!released) { active--; released = true; } };
  };
}
