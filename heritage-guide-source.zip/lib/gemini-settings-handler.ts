import { isSettingsOwner } from './settings-security.ts';
import { readBoundedJSON, type QuestionAnalysis } from './question-analysis.ts';

export const connectionTestQuestion = '논문에 쓰고싶은데 그게 뭐냐면 경향신문을 논문에 쓰려고';
type Dependencies = {
  user: () => Promise<{ userId: string; email: string } | null>;
  ownerEmail: () => string;
  analyze: (question: string, key: string, signal: AbortSignal) => Promise<QuestionAnalysis>;
  save: (key: string, userId: string) => Promise<string>;
  remove: () => Promise<void>;
  acquire: (request: Request) => (() => void) | null;
};
const reply = (message: string, status = 200, extra: object = {}) => Response.json({ message, ...extra }, {
  status, headers: { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' },
});

export function makeGeminiSettings(deps: Dependencies) {
  return async (request: Request): Promise<Response> => {
    const user = await deps.user();
    if (!isSettingsOwner(user, deps.ownerEmail())) return reply('운영자 계정으로 로그인해 주세요.', 403);
    if (request.headers.get('origin') !== new URL(request.url).origin) return reply('이 설정 화면에서 다시 시도해 주세요.', 403);
    if (request.method === 'DELETE') {
      try { await deps.remove(); return reply('AI 연결을 해제했어요. 자료 이름 검색은 계속 사용할 수 있어요.', 200, { configured: false, updatedAt: null }); }
      catch { return reply('연결을 해제하지 못했어요. 다시 시도해 주세요.', 503); }
    }
    if (request.method !== 'POST') return reply('지원하지 않는 요청이에요.', 405);
    if (!request.headers.get('content-type')?.startsWith('application/json')) return reply('입력 형식을 확인해 주세요.', 415);
    let key: string;
    try {
      const value = await readBoundedJSON(request.body, 4096);
      if (!value || typeof value !== 'object' || Array.isArray(value) || Object.keys(value).length !== 2
        || Object.keys(value).some(k => !['apiKey', 'freeTierConfirmed'].includes(k))
        || !('apiKey' in value) || typeof value.apiKey !== 'string'
        || !('freeTierConfirmed' in value) || value.freeTierConfirmed !== true) throw Error('Invalid settings');
      key = value.apiKey.trim();
      if (!key || key.length > 2048 || /[^\x21-\x7E]|[<>]/.test(key)) throw Error('Invalid key');
    } catch { return reply('키를 입력하고 무료 프로젝트 확인란에 체크해 주세요.', 400); }
    if (request.signal.aborted) return reply('연결을 취소했어요.', 499);
    const release = deps.acquire(request);
    if (!release) return reply('연결 시도가 많아요. 잠시 후 다시 시도해 주세요.', 429);
    try {
      const result = await deps.analyze(connectionTestQuestion, key, request.signal);
      if (request.signal.aborted) return reply('연결을 취소했어요.', 499);
      if (result.fallback === 'limit') return reply('Google의 사용 한도에 도달했어요. AI Studio의 무료 한도를 확인한 뒤 다시 시도해 주세요. 기존 설정은 유지했어요.', 429);
      if (result.method !== 'ai' || result.query !== '경향신문' || result.commercial !== 'unknown' || result.modification !== 'unknown')
        return reply('시험 문장 분석에 성공하지 못했어요. 키의 프로젝트·API 권한·무료 모델 이용 가능 여부를 확인해 주세요. 기존 설정은 유지했어요.', 422);
      const updatedAt = await deps.save(key, user!.userId);
      return reply('시험 문장에서 ‘경향신문’을 확인하고 연결했어요. 사이트를 새로고침해 문장으로 검색해 보세요.', 200, { configured: true, updatedAt });
    } catch { return reply('연결을 저장하지 못했어요. 잠시 후 다시 시도해 주세요.', 503); }
    finally { release(); }
  };
}
