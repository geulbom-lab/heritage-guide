import { env } from 'cloudflare:workers';
import { openServiceKey, sealServiceKey } from './settings-security';

type Setting = { encrypted_value: string; updated_at: string };
const encryptionSecret = () => env.SETTINGS_ENCRYPTION_KEY || process.env.SETTINGS_ENCRYPTION_KEY || '';
const savedSetting = async () => env.DB
  ? env.DB.prepare('SELECT encrypted_value, updated_at FROM service_settings WHERE id = ?').bind('gemini').first<Setting>() : null;

export async function readGeminiKey(): Promise<string> {
  const row = await savedSetting();
  return row ? openServiceKey(row.encrypted_value, encryptionSecret(), 'gemini') : '';
}
export async function geminiConnectionStatus() {
  const row = await savedSetting();
  let configured = false;
  if (row) { try { configured = !!await openServiceKey(row.encrypted_value, encryptionSecret(), 'gemini'); } catch {} }
  return { configured, updatedAt: row?.updated_at ?? null, canSave: !!env.DB && !!encryptionSecret() };
}
export async function saveGeminiKey(key: string, userId: string) {
  if (!env.DB) throw Error('settings_storage_unavailable');
  const encrypted = await sealServiceKey(key, encryptionSecret(), 'gemini');
  const updatedAt = new Date().toISOString();
  await env.DB.prepare('INSERT INTO service_settings (id, encrypted_value, updated_at, updated_by) VALUES (?, ?, ?, ?) ON CONFLICT(id) DO UPDATE SET encrypted_value = excluded.encrypted_value, updated_at = excluded.updated_at, updated_by = excluded.updated_by')
    .bind('gemini', encrypted, updatedAt, userId).run();
  return updatedAt;
}
export async function removeGeminiKey() {
  if (!env.DB) throw Error('settings_storage_unavailable');
  await env.DB.prepare('DELETE FROM service_settings WHERE id = ?').bind('gemini').run();
}
