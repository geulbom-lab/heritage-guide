export type ExploreItem = { query: string; title: string; institution: string; image: string | null; type: '1' | '4'; checkedAt:string; source: string; credit: string };
// Object-specific source notices; dates retained per example.
// Preview photography illustrates search topics; it is not a search result or
// a permission decision for a visitor's selected image.
export const exploreItems: ExploreItem[] = [
  {query:'호랑이',title:'호랑이와 까치',institution:'국립중앙박물관',image:'/artworks/placeholder.svg',type:'1',checkedAt:'2026-10-05',source:'https://www.museum.go.kr/MUSEUM/contents/M0502000000.do?relicId=8450&schM=view',credit:'공공누리 제1유형'},
  {query:'청자',title:'청자 상감 구름 학무늬 매병',institution:'국립중앙박물관',image:'/artworks/placeholder.svg',type:'1',checkedAt:'2026-10-05',source:'https://www.museum.go.kr/MUSEUM/contents/M0502000000.do?relicId=1126&schM=view&searchId=search',credit:'공공누리 제1유형'},
  {query:'청자 접시',title:'청자 인화 국화무늬 접시',institution:'서울공예박물관',image:null,type:'4',checkedAt:'2026-10-07',source:'https://craftmuseum.seoul.go.kr/search/collection_materials_view/16411',credit:'공공누리 제4유형'},
];
