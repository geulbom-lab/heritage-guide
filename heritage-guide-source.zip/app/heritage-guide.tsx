'use client';
import { useEffect, useRef, useState } from 'react';
import { flushSync } from 'react-dom';
import { BookOpen, Check, ExternalLink, HelpCircle, ImageIcon, Images, LoaderCircle, Search, SlidersHorizontal, ArrowLeft, Plus, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {NativeSelect,NativeSelectOption} from '@/components/ui/native-select';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { guidance, suggestQuestion, purposeLabel, type PublicRights, type Verdict, type PublicRecord, type PublicDetail, type PublicImage, type Selection, type Purpose } from '@/lib/public-guide';
import { CONDITIONS, OFFICIAL_CONDITION_SOURCE } from '@/lib/rights';
import type { Choice } from '@/lib/model';
import { isPlainSearch, ruleAnalysis as localAnalysis, type QuestionAnalysis } from '@/lib/question-input';
import { exploreItems, type ExploreItem } from '@/lib/explore-items';
import { searchTopics } from '@/lib/search-topics';
import FeedbackButton from './feedback-button';
import AttributionPanel from './attribution-panel';
import './public-guide.css';
import './heritage-redesign.css';

const examples=[
  {name:'수업 자료에 그대로',question:'훈민정음 이미지를 비영리 수업 자료에 그대로 넣고 싶어요.'},
  {name:'편집해서 판매할 굿즈에',question:'청자 무늬를 편집해 판매할 엽서를 만들고 싶어요.'},
  {name:'변형해서 디자인에',question:'호랑이 그림의 배경을 지우고 색상을 바꾸어 디자인에 쓰고 싶어요.'},
];
type SearchResult={records:PublicRecord[];total:number|null;totalPages:number|null;page:number;hasNext:boolean;checkedAt:string;searchTerms?:string[];partial?:boolean;refined?:boolean;institutions?:string[];within?:string;institution?:string};
const initialPurpose:Purpose={commercial:'unknown',modification:'unknown'};
function Picture(props:{src:string|null;title:string;compact?:boolean}) {
  return <PictureAttempt key={props.src??props.title} {...props}/>;
}
function PictureAttempt({src,title,compact=false}:{src:string|null;title:string;compact?:boolean}) {
  const [failed,setFailed]=useState(false),[loaded,setLoaded]=useState(false);
  return <div className={`hg-picture${compact?' compact':''}`}>
    {src&&!failed&&<img src={src} alt={title} loading="lazy" onLoad={()=>setLoaded(true)} onError={()=>setFailed(true)}/>}
    {(!src||failed)?<div className="hg-picture-empty"><ImageIcon size={compact?25:35}/><span>이미지는 원문에서 확인</span></div>:!loaded?<span className="hg-picture-loading"><LoaderCircle className="spin" size={22}/><span>이미지 불러오는 중</span></span>:null}
  </div>;
}
function PurposeChoice({name,title,help,value,onChange}:{name:string;title:string;help:string;value:Choice;onChange:(v:Choice)=>void}) {
  return <fieldset className="hg-choice"><legend id={`hg-${name}`}>{title}</legend><p>{help}</p><RadioGroup className="hg-radio" value={value} onValueChange={v=>onChange(v as Choice)} aria-labelledby={`hg-${name}`}>
    {([['yes','네'],['no','아니요'],['unknown','아직 모르겠어요']] as const).map(([v,label])=><Label className={value===v?'chosen':''} htmlFor={`hg-${name}-${v}`} key={v}><RadioGroupItem value={v} id={`hg-${name}-${v}`}/>{label}</Label>)}
  </RadioGroup></fieldset>;
}
function ScopeNote(){return <p className="hg-scope-note">공공누리 1~4유형의 이용조건 안내예요. 0유형·AI유형은 안내 범위 밖이며, 최종 이용조건과 별도 권리는 원문에서 확인해 주세요.</p>;}
async function request<T>(url:string,signal:AbortSignal,init?:RequestInit):Promise<T>{
  const controller=new AbortController();let timedOut=false;
  const abort=()=>controller.abort();
  signal.addEventListener('abort',abort,{once:true});
  if(signal.aborted)controller.abort();
  const timer=setTimeout(()=>{timedOut=true;controller.abort();},30000);
  try {
    const r=await fetch(url,{...init,signal:controller.signal,cache:'no-store'});
    if(!(r.headers.get('content-type')??'').includes('application/json'))throw Error('연결 응답을 확인하지 못했어요. 잠시 후 다시 시도해 주세요.');
    const data:unknown=await r.json();if(!r.ok)throw Error(data&&typeof data==='object'&&'message' in data&&typeof data.message==='string'?data.message:'요청을 완료하지 못했어요.');return data as T;
  }catch(error){if(timedOut)throw Error('응답이 늦어지고 있어요. 잠시 후 다시 시도해 주세요. 입력한 검색 조건은 유지돼요.');throw error;}
  finally{clearTimeout(timer);signal.removeEventListener('abort',abort);}
}


export default function HeritageGuide({searchReady,languageModelReady}:{searchReady:boolean;languageModelReady:boolean}){
  const [question,setQuestion]=useState(''),[query,setQuery]=useState(''),[purpose,setPurpose]=useState<Purpose>(initialPurpose);
  const [prepared,setPrepared]=useState(false),[result,setResult]=useState<SearchResult|null>(null),[activeQuery,setActiveQuery]=useState('');
  const [busy,setBusy]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState('');
  const [interpreting,setInterpreting]=useState(false),[interpretationNote,setInterpretationNote]=useState('');
  const [opened,setOpened]=useState<PublicRecord|null>(null),[detail,setDetail]=useState<PublicDetail|null>(null),[detailBusy,setDetailBusy]=useState(false),[detailError,setDetailError]=useState('');
  const [selection,setSelection]=useState<Selection[]>([]),[chosen,setChosen]=useState<Selection|null>(null),[help,setHelp]=useState(false);
  const [withinDraft,setWithinDraft]=useState(''),[institutionDraft,setInstitutionDraft]=useState('');
  const [editingPurpose,setEditingPurpose]=useState(false);
  const [comparing,setComparing]=useState(false);
  const [sample,setSample]=useState<ExploreItem|null>(null);
  const [purposeProvided,setPurposeProvided]=useState(false),[usageText,setUsageText]=useState('');
  const [editingQuery,setEditingQuery]=useState(false);
  const [draftQuery,setDraftQuery]=useState(''),[draftPurpose,setDraftPurpose]=useState<Purpose>(initialPurpose);
  function cancelInterpretation(){interpretAbort.current?.abort();setInterpreting(false);}
  function openPurpose(){cancelInterpretation();setDraftPurpose(purpose);setEditingPurpose(true);}
  function openQuery(){cancelInterpretation();setDraftQuery(activeQuery||query);setEditingQuery(true);}
  const effectivePurpose=purpose;
  const evaluate=(rights:PublicRights):Verdict=>purposeProvided?guidance(rights,effectivePurpose):{status:'unknown',title:'사용 목적 입력 전',description:'이미지를 고른 뒤 어디에 어떻게 쓸지 적으면 이용조건을 대조해요.'};
  const lastSearch=useRef<{page:number;term:string;filters:{within:string;institution:string}|null}|null>(null);
  const searchAbort=useRef<AbortController|null>(null),detailAbort=useRef<AbortController|null>(null);
  const interpretAbort=useRef<AbortController|null>(null);
  const confirmRef=useRef<HTMLDivElement>(null),resultsRef=useRef<HTMLElement>(null),attributionRef=useRef<HTMLElement>(null);
  const scroll=(ref:{current:HTMLElement|null})=>setTimeout(()=>ref.current?.scrollIntoView({behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'start'}),60);
  useEffect(()=>()=>{searchAbort.current?.abort();detailAbort.current?.abort();interpretAbort.current?.abort();},[]);
  useEffect(()=>{if(!notice)return;const t=setTimeout(()=>setNotice(''),4500);return()=>clearTimeout(t);},[notice]);
  async function interpret(value:string,signal:AbortSignal):Promise<QuestionAnalysis>{
    if(isPlainSearch(value)||!languageModelReady)return localAnalysis(value);
    try{return await request<QuestionAnalysis>('/api/public/interpret',signal,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({question:value})});}
    catch{return localAnalysis(value,'unavailable');}
  }
  function analysisNote(suggested:QuestionAnalysis){
    if(suggested.fallback==='limit')return suggested.query?'AI 문장 분석의 사용 한도에 도달해 기본 문장 검색으로 찾았어요. ‘찾을 자료’가 맞는지 확인해 주세요.':'AI 문장 분석의 사용 한도에 도달했어요. 찾을 자료 이름을 직접 입력해 주세요.';
    if(suggested.fallback==='unavailable')return suggested.query?'AI 연결이 원활하지 않아 기본 문장 검색으로 찾았어요. ‘찾을 자료’가 맞는지 확인해 주세요.':'문장에서 자료 이름을 구분하지 못했어요. 찾을 자료 이름을 직접 입력해 주세요.';
    return suggested.fallback==='unconfigured'&&!suggested.query?'문장에서 자료 이름을 구분하지 못했어요. 찾을 자료 이름을 한 번 확인해 주세요.':'';
  }
  async function startSearch(value=question,explicitQuery?:string){
    if(!value.trim())return;
    cancelInterpretation();searchAbort.current?.abort();detailAbort.current?.abort();
    const controller=new AbortController();interpretAbort.current=controller;
    setQuestion(value);setBusy(false);setError('');setInterpretationNote('');setEditingQuery(false);setEditingPurpose(false);
    setResult(null);setOpened(null);setChosen(null);setDetail(null);setDetailBusy(false);
    setInterpreting(languageModelReady&&explicitQuery===undefined&&!isPlainSearch(value));
    const suggested=explicitQuery===undefined?await interpret(value,controller.signal):localAnalysis(value);
    if(controller.signal.aborted)return;
    const term=(explicitQuery??suggested.query).trim();
    prepare(value,term,!!term,suggested);
    if(!term){setDraftQuery('');setEditingQuery(true);}
  }
  function prepare(value=question,explicitQuery?:string,searchImmediately=true,analysis?:QuestionAnalysis){
    if(!value.trim()){setError('찾는 이미지와 사용 목적을 한 문장으로 적어 주세요.');return;}
    cancelInterpretation();searchAbort.current?.abort();detailAbort.current?.abort();
    const suggested=analysis??localAnalysis(value);setQuestion(value);setQuery(explicitQuery??suggested.query);setPurpose({commercial:suggested.commercial,modification:suggested.modification});
    setInterpretationNote(analysisNote(suggested));setPurposeProvided(suggested.hasPurpose);setUsageText('');
    setPrepared(true);setResult(null);setBusy(false);setSelection([]);setChosen(null);setError('');setOpened(null);setDetail(null);
    setActiveQuery('');
    const term=explicitQuery??suggested.query;
    if(searchImmediately&&term.trim())void search(1,term,null);
  }
  async function applyUsage(){
    cancelInterpretation();const controller=new AbortController();interpretAbort.current=controller;
    const value=`${query} 이미지를 ${usageText}`;setInterpreting(languageModelReady);
    const parsed=await interpret(value,controller.signal);
    if(controller.signal.aborted)return;
    const nextPurpose={commercial:parsed.commercial,modification:parsed.modification};
    setPurpose(nextPurpose);setPurposeProvided(parsed.hasPurpose);setQuestion(value);
    if(!parsed.hasPurpose){setDraftPurpose(nextPurpose);setEditingPurpose(true);}
    setInterpretationNote(analysisNote(parsed));setInterpreting(false);
  }
  const prepareAction=useRef(prepare);
  useEffect(()=>{prepareAction.current=prepare;});
  useEffect(()=>{
    type Context={registerTool:(tool:{name:string;title:string;description:string;inputSchema:object;annotations:object;execute:(input:unknown)=>unknown},options:{signal:AbortSignal})=>void|Promise<void>};
    const context=(document as Document & {modelContext?:Context}).modelContext;
    if(!context?.registerTool)return;
    const lifecycle=new AbortController();
    try {void Promise.resolve(context.registerTool({
      name:'prepare_heritage_image_question',title:'문화유산 이미지 이용 목적 정리',
      description:'Fill the search field and suggest search terms and usage choices. The user starts the search. Does not search, navigate, or confirm permission.',
      inputSchema:{type:'object',properties:{question:{type:'string',minLength:1,maxLength:700}},required:['question'],additionalProperties:false},
      annotations:{readOnlyHint:false,untrustedContentHint:false},
      execute(input){
        if(!input||typeof input!=='object'||Object.keys(input).some(k=>k!=='question')||!('question' in input)||typeof input.question!=='string'||!input.question.trim()||input.question.length>700)throw Error('Provide a question from 1 to 700 characters.');
        const question=input.question.trim();
        flushSync(()=>prepareAction.current(question,undefined,false));
        return {stage:'ready_to_search',suggested:suggestQuestion(question)};
      }
    },{signal:lifecycle.signal})).catch(()=>{});}catch{}
    return()=>lifecycle.abort();
  },[]);
  async function search(page=1,term=query,filters?:{within:string;institution:string}|null){
    const refinement=filters!==undefined?filters:(result?.refined&&term===activeQuery?{within:result.within??'',institution:result.institution??''}:null);
    if(!term.trim()){setError('검색어를 입력해 주세요. 예: 훈민정음, 청자, 한글 편지');return;}
    lastSearch.current={page,term:term.trim(),filters:refinement};
    searchAbort.current?.abort();const controller=new AbortController();searchAbort.current=controller;
    if(!searchReady){setError('이미지 검색 연결을 준비 중이에요. 연결이 완료되면 이 화면에서 이미지를 찾을 수 있어요.');scroll(confirmRef);return;}
    detailAbort.current?.abort();setOpened(null);setChosen(null);setDetail(null);setDetailBusy(false);
    setBusy(true);setError('');setActiveQuery(term.trim());if(!refinement)setResult(null);scroll(resultsRef);
    try {const data=await request<SearchResult>(`/api/public/search?q=${encodeURIComponent(term.trim())}&page=${page}${refinement?'&refine=1&within='+encodeURIComponent(refinement.within)+'&institution='+encodeURIComponent(refinement.institution):''}`,controller.signal);if(!controller.signal.aborted){setResult(data);setWithinDraft(data.within??'');setInstitutionDraft(data.institution??'');scroll(resultsRef);}}
    catch(e){if(!controller.signal.aborted){setError((e as Error).message);scroll(confirmRef);}}
    finally{if(!controller.signal.aborted)setBusy(false);}
  }
  async function openRecord(record:PublicRecord,imageId?:string){
    detailAbort.current?.abort();const controller=new AbortController();detailAbort.current=controller;
    setOpened(record);setChosen(null);setDetail(null);setDetailError('');setDetailBusy(true);
    if(window.matchMedia('(max-width: 900px)').matches)scroll(attributionRef);
    try {const data=await request<PublicDetail>('/api/public/detail?id='+encodeURIComponent(record.id),controller.signal);if(!controller.signal.aborted){setDetail(data);const image=data.images.find(i=>i.id===imageId)??data.images[0];setChosen(image?{record:data.record,image}:null);}}
    catch(e){if(!controller.signal.aborted)setDetailError((e as Error).message);}
    finally{if(!controller.signal.aborted)setDetailBusy(false);}
  }
  function add(record:PublicRecord,image:PublicImage){
    if(selection.some(s=>s.image.id===image.id)){setNotice('이미 비교 목록에 담은 이미지예요.');return;}
    if(selection.length>=4){setNotice('한 번에 4장까지 비교할 수 있어요. 먼저 담은 이미지를 빼고 추가해 주세요.');return;}
    setSelection(s=>[...s,{record,image}]);setNotice('비교 목록에 담았어요. 다른 이미지도 함께 골라 보세요.');
  }
  function remove(id:string){setSelection(s=>s.filter(i=>i.image.id!==id));}
  function choose(item:Selection){setComparing(false);if(detail?.record.id===item.record.id){setOpened(item.record);setChosen(item);scroll(attributionRef);}else void openRecord(item.record,item.image.id);}
  function closeInspector(){detailAbort.current?.abort();setOpened(null);setChosen(null);setDetail(null);setDetailBusy(false);setTimeout(()=>resultsRef.current?.focus(),0);}

  function reset(){cancelInterpretation();setInterpretationNote('');lastSearch.current=null;searchAbort.current?.abort();detailAbort.current?.abort();setComparing(false);setQuestion('');setQuery('');setPrepared(false);setResult(null);setSelection([]);setChosen(null);setPurpose(initialPurpose);setPurposeProvided(false);setUsageText('');setEditingPurpose(false);setEditingQuery(false);setOpened(null);setDetail(null);setError('');setBusy(false);window.scrollTo({top:0,behavior:'smooth'});}
  const chosenVerdict=chosen?evaluate(chosen.image.rights):null;
  const updatePurpose=(key:keyof Purpose,value:Choice)=>setDraftPurpose(p=>({...p,[key]:value}));
  return <div className="hg-app">
    <a className="hg-skip" href="#ask">질문 입력으로 바로가기</a>
    <header className="hg-header"><a href="/" className="hg-brand"><span className="hg-symbol"><BookOpen size={22}/></span><span>이 문화유산, 써도 되나요?</span></a><div className="hg-header-tools"><span className="hg-beta">시험 서비스</span><button type="button" aria-label="이용 안내" onClick={()=>setHelp(true)}><HelpCircle size={18}/><span>이용 안내</span></button></div></header>
    <main className={`hg-main ${prepared?'is-searching':'is-home'}`}>
      <div className={`hg-discover ${prepared?'has-question':''}`}>
        <div className="hg-intro"><h1>어떤 이미지를<br/>어디에 쓰고 싶으세요?</h1></div>
        <section className="hg-question" aria-label="문화유산 이미지 찾기">
          <form onSubmit={e=>{e.preventDefault();startSearch();}}>
            <Label htmlFor="ask" className="sr-only">찾는 이미지와 사용 목적</Label>
            <Textarea id="ask" value={question} onChange={e=>{cancelInterpretation();setQuestion(e.target.value);}} maxLength={700} enterKeyHint="search" onKeyDown={e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.nativeEvent.isComposing){e.preventDefault();e.currentTarget.form?.requestSubmit();}}} placeholder="예: 호랑이 그림으로 판매할 티셔츠를 만들고 싶어요"/>
            <div className="hg-question-bottom"><span>자료 이름만 쓰거나, 어디에 어떻게 쓸지 문장으로 적어 주세요.</span><Button type="submit" className="hg-primary" disabled={!question.trim()||busy||interpreting}><Search size={18}/>{interpreting?'문장 읽는 중':'이미지 찾기'}</Button></div>
          </form>
          <p className="hg-language-note">{languageModelReady?'문장 검색 내용은 Google에 전달되며 무료 서비스의 제품 개선에 사용될 수 있어요. 개인정보·비공개 자료는 적지 마세요.':'자료 이름과 간단한 문장으로 검색할 수 있어요. 이름을 구분하기 어려울 때만 다시 확인해요.'}</p>
        </section>
        <div className={`hg-example-chips ${prepared?'hg-hide':''}`} aria-label="예시 문장으로 검색"><span>예시 문장으로 검색</span>{examples.map(e=><button type="button" key={e.name} onClick={()=>startSearch(e.question)}>{e.name}</button>)}</div>
        {!searchReady&&!prepared&&<p className="hg-connection-note">이미지 검색 연결을 준비 중이에요. </p>}
      </div>
      {!prepared&&<section className="hg-topics" aria-labelledby="topics-title"><h2 id="topics-title">이런 이미지는 어때요?</h2><div className="hg-topic-grid">{searchTopics.map(topic=><article className="hg-topic-card" key={topic.query}><button type="button" onClick={()=>startSearch(topic.label,topic.query)} aria-label={`${topic.label} 이미지 검색`}><div className="hg-topic-image"><img src={topic.image} alt={topic.title} width={480} height={360}/></div><h3>{topic.label}</h3></button><a className="hg-topic-credit" href={topic.source} target="_blank" rel="noreferrer" aria-label={`${topic.title} 사진 출처: ${topic.institution}, ${topic.credit}`}>{topic.institution} · {topic.credit} <ExternalLink size={12}/></a></article>)}</div></section>}
      {interpreting&&<div className="hg-loading" role="status"><LoaderCircle className="spin" size={28}/><p>문장에서 찾을 자료와 사용 목적을 읽고 있어요.</p></div>}
      {interpretationNote&&<p className="hg-language-note" role="status">{interpretationNote}</p>}
      {prepared&&!interpreting&&<div className="hg-query-summary"><span>찾을 자료: <strong>{query||'자료 이름 확인 필요'}</strong></span><button type="button" className="hg-text-button" onClick={openQuery}><Search size={15}/>검색어 수정</button></div>}
      {prepared&&!interpreting&&<div className="hg-intent-bar"><span>{purposeProvided?`${purpose.commercial==='yes'?'판매·홍보에 사용':purpose.commercial==='no'?'비영리로 사용':'판매·홍보 여부 미확인'} · ${purpose.modification==='yes'?'이미지 편집':purpose.modification==='no'?'이미지 그대로':'편집 여부 미확인'}`:'이미지를 고른 뒤 사용 목적을 알려 주세요.'}</span><button type="button" onClick={openPurpose}><SlidersHorizontal size={15}/>{purposeProvided?'목적 수정':'목적 입력'}</button></div>}

      {error&&<div className="hg-error" role="alert" ref={confirmRef}><div><strong>아직 검색하지 못했어요</strong><p>{error}</p></div>{searchReady?<Button variant="outline" disabled={busy} onClick={()=>{const retry=lastSearch.current;if(retry)void search(retry.page,retry.term,retry.filters);}}>다시 검색</Button>:null}</div>}
      {busy&&<div className="hg-loading" role="status"><LoaderCircle className="spin" size={28}/><p>실제 소장품과 이용조건을 불러오고 있어요.</p></div>}
      {result&&<div className={`hg-workspace ${opened?'has-selection':''}`}>
      {result&&<section className="hg-results" aria-busy={busy} ref={resultsRef} tabIndex={-1} aria-labelledby="results-title"><div className="hg-results-head"><div><p className="hg-eyebrow">이미지 찾기</p><h2 id="results-title">‘{activeQuery}’ 검색 결과</h2><p>{result.total!==null?`전체 ${result.total.toLocaleString()}건 · `:''}현재 {result.records.length}건 · 자료 이름 기준 · e뮤지엄 제공</p></div><div className="hg-results-tools"><button type="button" className="hg-text-button" onClick={openQuery}><Search size={15}/>검색어 수정</button><span className="hg-page-label">{result.page} 페이지</span></div></div>
        <div className="hg-refinement">
          {result.refined?<form onSubmit={e=>{e.preventDefault();void search(1,activeQuery,{within:withinDraft,institution:institutionDraft});}}>
            <div><Label htmlFor="within-results">결과 내 검색</Label><Input id="within-results" disabled={busy} value={withinDraft} onChange={e=>setWithinDraft(e.target.value)} maxLength={100} placeholder="자료 이름에서 더 찾기"/></div>
            <div><Label htmlFor="within-institution">소장기관</Label><NativeSelect id="within-institution" disabled={busy} value={institutionDraft} onChange={e=>setInstitutionDraft(e.target.value)}><NativeSelectOption value="">전체 기관</NativeSelectOption>{result.institutions?.map(name=><NativeSelectOption key={name} value={name}>{name}</NativeSelectOption>)}</NativeSelect></div>
            <div className="hg-refinement-actions">
              <Button type="submit" className="hg-secondary" disabled={busy}>적용</Button>
              <Button type="button" variant="outline" className="hg-secondary" disabled={busy} onClick={()=>{setWithinDraft('');setInstitutionDraft('');if(result.within||result.institution)void search(1,activeQuery,{within:'',institution:''});else setError('');}}>초기화</Button>
            </div>
          </form>:<Button className="hg-secondary" disabled={busy} onClick={()=>void search(1,activeQuery,{within:'',institution:''})}><SlidersHorizontal size={16}/>결과 좁히기 · 검색어·소장기관</Button>}
          {result.refined&&(result.within||result.institution)&&<div className="hg-filter-tags">{result.within&&<button disabled={busy} onClick={()=>void search(1,activeQuery,{within:'',institution:result.institution??''})}>{result.within} <X size={14}/><span className="sr-only">검색 조건 해제</span></button>}{result.institution&&<button disabled={busy} onClick={()=>void search(1,activeQuery,{within:result.within??'',institution:''})}>{result.institution} <X size={14}/><span className="sr-only">기관 조건 해제</span></button>}</div>}
        </div>
        {result.searchTerms&&result.searchTerms.length>1&&<p className="hg-results-hint">함께 검색한 이름: {result.searchTerms.join(' · ')}</p>}{result.partial&&<p className="hg-results-hint">일부 연결어의 검색 응답을 받지 못했어요. 현재 받은 자료만 표시해요.</p>}
        {result.records.length===0?<div className="hg-empty"><Search size={32}/><h3>{result.hasNext?'이 페이지에는 이름이 맞는 자료가 없어요':result.refined&&(result.within||result.institution)?'선택한 조건에 맞는 자료가 없어요':'검색된 자료가 없어요'}</h3><p>{result.hasNext?'다음 페이지를 확인하거나 검색어를 바꿔 보세요.':result.refined&&(result.within||result.institution)?'결과 내 검색어나 소장기관 조건을 해제해 보세요.':'‘청자’, ‘훈민정음’처럼 짧은 이름으로 바꿔 보세요.'}</p>{result.refined&&(result.within||result.institution)?<Button variant="outline" disabled={busy} onClick={()=>void search(1,activeQuery,{within:'',institution:''})}>조건 해제하고 전체 보기</Button>:<Button variant="outline" onClick={openQuery}>검색어 바꾸기</Button>}</div>:<div className="hg-record-grid">{result.records.map(r=><article className={`hg-record ${opened?.id===r.id?'is-selected':''}`} key={r.id}><button type="button" className="hg-record-open" disabled={busy} onClick={()=>void openRecord(r)} aria-label={`${r.title}, 이미지와 이용조건 보기`}><Picture src={r.image} title={r.title}/><div className="hg-record-body"><p>{r.institution}</p><h3>{r.title}</h3></div></button><div className="hg-record-actions"><Button type="button" className="hg-secondary hg-record-pick" disabled={busy} onClick={()=>void openRecord(r)} aria-label={`${r.title}, 이미지 선택`} aria-pressed={opened?.id===r.id}>{opened?.id===r.id?<Check size={17}/>:<Plus size={17}/>} {opened?.id===r.id?'선택됨':'선택하기'}</Button></div></article>)}</div>}
        {(result.records.length>0||result.hasNext||result.page>1)&&<nav className="hg-paging" aria-label="검색 결과 페이지"><Button variant="outline" disabled={result.page<=1||busy} onClick={()=>void search(result.page-1,activeQuery)}>이전</Button><span className="hg-page-count" aria-live="polite">{result.page} / {result.totalPages??'—'} 페이지{result.totalPages==null&&<small>전체 페이지 확인 불가</small>}</span><Button variant="outline" disabled={!result.hasNext||busy} onClick={()=>void search(result.page+1,activeQuery)}>다음</Button></nav>}
      </section>}


      <aside className={`hg-inspector ${opened?'is-open':''}`} ref={attributionRef} aria-label="선택한 이미지와 이용조건">
        {!opened?<div className="hg-inspector-empty"><ImageIcon size={34}/><h2>마음에 드는 이미지를 골라 보세요</h2><p>사용 조건과 출처를 여기에서 확인할 수 있어요.</p></div>:<>
          <div className="hg-inspector-top"><button type="button" className="hg-text-button" onClick={closeInspector}><ArrowLeft size={17}/>목록으로</button><span>{opened.institution}</span></div>
          <h2>{opened.title}</h2>
          {detailBusy&&<div className="hg-loading" role="status"><LoaderCircle className="spin" size={24}/><p>이미지와 조건을 확인하고 있어요.</p></div>}
          {detailError&&<div className="hg-error" role="alert"><p>{detailError}</p><Button variant="outline" onClick={()=>void openRecord(opened)}>다시 시도</Button></div>}
          {detail&&!detail.images.length&&<p className="hg-empty">선택할 이미지 정보를 받지 못했어요. 원문에서 확인해 주세요.</p>}
          {chosen&&chosenVerdict&&<>
            <div className="hg-selected-photo"><Picture src={chosen.image.image} title={`${chosen.record.title}, 이미지 ${chosen.image.ordinal}`}/></div>
            {detail&&detail.images.length>1&&<div className="hg-thumbnails" aria-label="이 자료의 이미지 선택">{detail.images.map(i=><button type="button" key={i.id} aria-label={`이미지 ${i.ordinal} 선택`} aria-pressed={chosen.image.id===i.id} className={chosen.image.id===i.id?'active':''} onClick={()=>setChosen({record:detail.record,image:i})}><Picture src={i.image} title={`이미지 ${i.ordinal}`} compact/><span>{i.ordinal}</span></button>)}</div>}
            <div className="hg-image-tools"><span>이미지 {chosen.image.ordinal}{detail?` / ${detail.images.length}`:''}</span><Button className="hg-secondary" disabled={selection.some(i=>i.image.id===chosen.image.id)||selection.length>=4} onClick={()=>add(chosen.record,chosen.image)}>{selection.some(i=>i.image.id===chosen.image.id)?<Check size={16}/>:<Plus size={16}/>} {selection.some(i=>i.image.id===chosen.image.id)?'비교에 담음':selection.length>=4?'비교 4장 담음':'비교에 담기'}</Button></div>
            {!purposeProvided&&<form className="hg-purpose-followup" onSubmit={e=>{e.preventDefault();void applyUsage();}}><Label htmlFor="usage-followup">어디에 어떻게 쓰고 싶으세요?</Label><Textarea id="usage-followup" required maxLength={500} value={usageText} onChange={e=>{cancelInterpretation();setUsageText(e.target.value);}} placeholder="예: 그대로 티셔츠에 넣어 판매하고 싶어요"/><Button className="hg-primary" disabled={!usageText.trim()||interpreting}>사용 조건 확인</Button></form>}
            <section className="hg-decision" aria-label="이용조건 안내" aria-live="polite"><div className={`hg-verdict ${chosenVerdict.status}`}>{chosenVerdict.status==='match'?<Check size={19}/>:<HelpCircle size={19}/>}<strong>{chosenVerdict.title}</strong></div><p>{chosenVerdict.description}</p><dl className="hg-conditions">{(['commercial','modification'] as const).map(axis=><div key={axis}><dt>{axis==='commercial'?'판매·홍보':'변경·편집'}</dt><dd>{chosen.image.rights.type&&chosen.image.rights.confirmed&&!chosen.image.rights.conflict?(CONDITIONS[chosen.image.rights.type][axis]?'가능':'제한'):'원문 확인'}</dd></div>)}<div><dt>출처표시</dt><dd>{chosen.image.rights.type&&chosen.image.rights.confirmed&&!chosen.image.rights.conflict?'필수':'원문 확인'}</dd></div></dl></section>
            <div className="hg-source-row"><a href={chosen.record.source} target="_blank" rel="noreferrer">원문 보기 <ExternalLink size={15}/></a><FeedbackButton key={chosen.image.id} label="판정이 틀렸어요" context={{recordId:chosen.record.id,title:chosen.record.title,imageOrdinal:String(chosen.image.ordinal),licence:chosen.image.rights.type??'미확인',commercial:purpose.commercial,modification:purpose.modification,verdict:chosenVerdict.title}}/></div>
            <AttributionPanel key={`${chosen.record.id}:${chosen.image.id}`} selection={chosen}/>
            <details className="hg-evidence"><summary>안내 근거와 사용 전 확인사항</summary><p>{chosen.image.rights.type&&chosen.image.rights.confirmed&&!chosen.image.rights.conflict?`확인된 표시: 공공누리 제${chosen.image.rights.type}유형`:'확인된 이용조건이 충분하지 않아요.'} · 조회일 {chosen.record.checkedAt.slice(0,10)}</p><ScopeNote/><p>e뮤지엄 제공 정보에 따른 안내이며, 원문의 개별 표시는 자동 검토하지 않았어요. 해당 이미지의 유형·추가 조건과 별도 권리를 확인해 주세요.</p><p>온라인에서는 가능한 경우 출처 링크를 제공하고, 기관이 나를 후원하거나 특별한 관계에 있는 것처럼 표시하지 않아요.</p><a href={OFFICIAL_CONDITION_SOURCE} target="_blank" rel="noreferrer">공공누리 공식 조건 <ExternalLink size={14}/></a></details>
            {chosenVerdict.status!=='match'&&purposeProvided&&<details className="hg-evidence"><summary>제공기관에 문의할 문장</summary><p>“{chosen.record.title}”의 {chosen.image.ordinal}번째 이미지를 “{question}”라는 목적으로 이용하려고 합니다. 이미지의 이용조건과 별도 허락 필요 여부, 필수 출처표시 사항을 알려 주세요.</p></details>}
          </>}
          {detail?.record.description&&<details className="hg-evidence"><summary>자료 설명</summary><p>{detail.record.description}</p></details>}
          {!chosen&&<a className="hg-outline-link" href={opened.source} target="_blank" rel="noreferrer">원문 보기 <ExternalLink size={15}/></a>}
        </>}
      </aside>
      </div>}
      {prepared&&<div className="hg-reset"><button type="button" onClick={reset}>새로운 질문으로 시작하기</button></div>}

    </main>
    <footer className="hg-footer"><div><strong>이 문화유산, 써도 되나요?</strong><p>검색·조건 대조: e뮤지엄 API · 이용 안내 사례: 각 기관 원문</p><p>운영: Geulbom Lab · 문화유산학 연구자</p><p>문화유산 이미지의 활용을 돕는 독립적인 연구 기반 시험 서비스입니다.</p></div><nav aria-label="도움말 링크"><FeedbackButton/><a href={OFFICIAL_CONDITION_SOURCE} target="_blank" rel="noreferrer">공공누리 이용조건 <ExternalLink size={14}/></a><button type="button" onClick={()=>setHelp(true)}>서비스 안내</button></nav></footer>
    {selection.length>0&&<div className="hg-tray"><span><Images size={20}/><strong>담은 이미지 {selection.length}</strong></span><Button className="hg-primary" onClick={()=>setComparing(true)}>비교하기</Button></div>}
    {notice&&<div className="hg-toast" role="status">{notice}</div>}
    <Dialog open={comparing} onOpenChange={setComparing}><DialogContent className="hg-help-dialog hg-compare-dialog"><DialogHeader><DialogTitle>이미지 조건 비교</DialogTitle><DialogDescription>같은 사용 목적을 기준으로 비교해요. 최대 4장까지 담을 수 있어요.</DialogDescription></DialogHeader>      <section className="hg-comparison"  aria-labelledby="compare-title"><div className="hg-results-head"><div><p className="hg-eyebrow">조건 비교</p><h2 id="compare-title">담은 이미지 {selection.length}장, 조건을 비교해요</h2><p>판매·홍보 관련 이용 {purposeLabel(purpose.commercial)} · 변경·편집 {purposeLabel(purpose.modification)}</p></div><button className="hg-text-button" type="button" onClick={openPurpose}>사용 목적 수정</button></div><div className="hg-compare-grid">{selection.map(item=>{const v=evaluate(item.image.rights),type=item.image.rights.type;return <article className="hg-compare-card" key={item.image.id}><div className="hg-compare-picture"><Picture src={item.image.image} title={`${item.record.title} ${item.image.ordinal}번째 이미지`} compact/><button className="hg-remove" type="button" onClick={()=>remove(item.image.id)} aria-label={`${item.record.title} 비교에서 빼기`}><X size={17}/></button></div><div className="hg-compare-body"><p className="hg-small">{item.record.institution} · 이미지 {item.image.ordinal}</p><h3>{item.record.title}</h3><p className={`hg-verdict ${v.status}`}>{v.status==='match'?<Check size={17}/>:<HelpCircle size={17}/>} {v.title}</p><p className="hg-description">{v.description}</p><dl className="hg-conditions"><div><dt>확인된 유형</dt><dd>{type&&item.image.rights.confirmed&&!item.image.rights.conflict?`공공누리 ${type}유형`:'확인 필요'}</dd></div><div><dt>상업적 이용</dt><dd>{type&&item.image.rights.confirmed&&!item.image.rights.conflict?(CONDITIONS[type].commercial?'가능':'제한'):'확인 필요'}</dd></div><div><dt>변경·편집</dt><dd>{type&&item.image.rights.confirmed&&!item.image.rights.conflict?(CONDITIONS[type].modification?'가능':'제한'):'확인 필요'}</dd></div><div><dt>출처표시</dt><dd>{type&&item.image.rights.confirmed&&!item.image.rights.conflict?'필수':'원문 확인'}</dd></div></dl><details className="hg-evidence"><summary>안내 근거 보기</summary><p>e뮤지엄에서 제공한 소장품·이미지 정보와 공공누리 제1–4유형 조건을 대조했어요. 조회일: {item.record.checkedAt.slice(0,10)}. 원문의 개별 표시는 자동 검토하지 않았어요.</p><a href={item.record.source} target="_blank" rel="noreferrer">해당 자료 원문 <ExternalLink size={14}/></a><a href={OFFICIAL_CONDITION_SOURCE} target="_blank" rel="noreferrer">공공누리 공식 조건 <ExternalLink size={14}/></a></details><Button className={v.status==='match'?'hg-primary':'hg-secondary'} onClick={()=>choose(item)}>{v.status==='match'?'이 이미지로 출처 챙기기':'원문 확인·문의 준비'}</Button></div></article>;})}</div></section>{selection.length===0&&<p className="hg-empty">담은 이미지가 없어요. 검색 결과에서 이미지를 골라 비교에 담아 주세요.</p>}</DialogContent></Dialog>
    <Dialog open={!!sample} onOpenChange={open=>{if(!open)setSample(null);}}><DialogContent className="hg-help-dialog"><DialogHeader><DialogTitle>{sample?.title}</DialogTitle><DialogDescription>기관 원문에서 확인한 조건 사례 · 실제 검색 결과와 구분됩니다.</DialogDescription></DialogHeader>{sample&&<div className="hg-help-body"><p>{sample.institution} · {sample.credit}</p><p className={`hg-verdict ${sample.type==='4'?'restricted':'match'}`}>{sample.type==='4'?'판매하거나 편집하려면 별도 허락이 필요해요':'출처표시 조건으로 판매·편집할 수 있어요'}</p><p>같은 이용 계획이라도 이미지에 표시된 조건에 따라 안내가 달라집니다.</p><ScopeNote/><p className="hg-small">원문 확인일: {sample.checkedAt}. 개별 이미지의 추가 조건도 원문에서 확인해 주세요.</p><a className="hg-outline-link" href={sample.source} target="_blank" rel="noreferrer">기관 원문과 조건 보기 <ExternalLink size={16}/></a><Button className="hg-primary" onClick={()=>{setSample(null);startSearch(sample.query,sample.query);}}>이 주제로 e뮤지엄 검색</Button></div>}</DialogContent></Dialog>
    <Dialog open={editingQuery} onOpenChange={setEditingQuery}><DialogContent className="hg-help-dialog hg-purpose-dialog"><DialogHeader><DialogTitle>찾을 이미지 이름을 확인해 주세요</DialogTitle><DialogDescription>{query?'검색할 이름만 바꿔도 처음 적은 사용 목적은 유지돼요.':'문장에서 자료 이름을 하나로 정하지 못했어요. 사용할 이미지의 자료 이름을 적어 주세요. 처음 적은 사용 목적은 유지돼요.'}</DialogDescription></DialogHeader><form className="hg-help-body" onSubmit={e=>{e.preventDefault();const term=draftQuery.trim();if(!term)return;setQuery(term);setEditingQuery(false);setSelection([]);setChosen(null);void search(1,term,null);}}><Label htmlFor="search-term">검색어</Label><Input id="search-term" value={draftQuery} onChange={e=>setDraftQuery(e.target.value)} maxLength={150} placeholder="예: 호작도" autoFocus/><Button type="submit" className="hg-primary hg-save-purpose" disabled={!draftQuery.trim()}>이 이름으로 검색</Button></form></DialogContent></Dialog>
    <Dialog open={editingPurpose} onOpenChange={setEditingPurpose}><DialogContent className="hg-help-dialog hg-purpose-dialog"><DialogHeader><DialogTitle>어떻게 쓰실 건가요?</DialogTitle><DialogDescription>모르는 항목은 ‘아직 모르겠어요’로 두어도 돼요.</DialogDescription></DialogHeader><form className="hg-help-body" onSubmit={e=>{e.preventDefault();setPurpose(draftPurpose);setPurposeProvided(true);setEditingPurpose(false);}}><div className="hg-purposes"><PurposeChoice name="commercial" title="판매나 홍보에 쓰나요?" help="판매할 상품, 유료 콘텐츠, 사업 홍보 등이 해당해요." value={draftPurpose.commercial} onChange={v=>updatePurpose('commercial',v)}/><PurposeChoice name="modification" title="이미지를 편집하나요?" help="잘라내기, 합성, 색 바꾸기, 배경 지우기 등이 해당해요." value={draftPurpose.modification} onChange={v=>updatePurpose('modification',v)}/></div><Button type="submit" className="hg-primary hg-save-purpose">이 조건으로 확인</Button></form></DialogContent></Dialog>
    <Dialog open={help} onOpenChange={setHelp}><DialogContent className="hg-help-dialog"><DialogHeader><DialogTitle>이용 안내</DialogTitle><DialogDescription>이미지 선택부터 출처표시까지, 이 사이트에서 확인하세요.</DialogDescription></DialogHeader><div className="hg-help-body"><ol><li><strong>찾고 싶은 이미지를 말해 주세요.</strong><p>호랑이처럼 이름만 쓰거나, “호랑이 그림으로 판매할 엽서를 만들고 싶어요”처럼 사용 목적을 함께 적어 주세요. 문장에서 자료 이름과 사용 목적을 나누어 검색해요. 긴 문장은 잘못 나뉠 수 있으니, 검색 후 ‘찾을 자료’가 맞는지 확인하고 필요하면 ‘검색어 수정’을 눌러 주세요. 자료 이름을 따옴표로 감싸면 더 정확하게 구분할 수 있어요.</p></li><li><strong>이미지를 고르고 조건을 확인해요.</strong><p>질문에서 읽은 판매·홍보와 편집 계획을 이미지별 조건에 자동으로 대조해요. 언급하지 않은 부분은 조건부로 안내하고, 결과에서 해석을 수정할 수 있어요. 필요하면 최대 4장을 비교할 수 있어요. 이미지가 제공되지 않으면 원문에서 확인해 주세요.</p></li><li><strong>원문을 확인하고 출처를 남겨요.</strong><p>문장형 출처 초안에서 확인 필요 항목을 보완하고, 온라인에서는 가능한 경우 출처 링크를 함께 제공해요. 기관의 후원이나 특별한 관계가 있는 것처럼 표시하지 않아요. 안내는 제공된 공공누리 정보에 근거해요. 초상권·상표권 등 다른 권리나 원문의 추가 조건은 별도로 확인해 주세요.</p></li></ol><details className="hg-help-samples"><summary>이미지마다 다른 이용조건, 사례 보기</summary><ul>{exploreItems.map(item=><li key={item.title}><button type="button" onClick={()=>{setHelp(false);setSample(item);}}><strong>{item.title}</strong><span>{item.institution} · 공공누리 {item.type}유형</span><span>{item.type==='1'?'출처표시 · 판매·편집 가능':'출처표시 · 판매·편집 제한'}</span></button></li>)}</ul></details><p>현재는 공공누리 제1–4유형을 안내해요. 제0유형·AI유형이나 확인되지 않은 조건은 원문 확인으로 안내합니다. 오류 신고는 제출한 의견과 표시된 자료·이용조건을 운영자가 확인하도록 저장해요. 그 외 검색 질문과 비교 목록은 연구 기록에 저장하지 않으며, 새로고침하면 초기화됩니다. 검색어는 자료 조회를 위해 e뮤지엄에 전달됩니다. {languageModelReady?'문장 이해를 위해 입력한 질문은 Google Gemini API에 전달됩니다. Google의 무료 서비스에서는 입력과 응답이 제품 개선에 사용될 수 있으니 개인정보·비공개 자료는 적지 마세요. AI는 자료명과 이용 목적만 추출하고 이용 허락 여부를 판정하지 않습니다. 한도 초과나 연결 실패 시 기본 문장 검색을 사용하고, 자료 이름을 구분하기 어려울 때만 직접 확인합니다.':'AI 문장 이해 기능은 아직 연결 전이며 기본 문장 검색을 사용합니다. 자료 이름과 이용 목적을 구분할 수 있는 문장은 바로 검색하고, 자료 이름이 없거나 구분하기 어려울 때만 직접 확인합니다.'}</p><a href={OFFICIAL_CONDITION_SOURCE} target="_blank" rel="noreferrer">공공누리 공식 이용조건 보기 <ExternalLink size={15}/></a></div></DialogContent></Dialog>
  </div>;
}
