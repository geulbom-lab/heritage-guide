export type ChatGPTUser = {userId:string;displayName:string;email:string;fullName:string|null};
// Public source edition: admin settings stay disabled until a trusted auth adapter is supplied.
export async function getChatGPTUser():Promise<ChatGPTUser|null>{return null;}
export async function requireChatGPTUser(_returnTo:string):Promise<ChatGPTUser>{throw new Error("Configure a trusted authentication adapter first.");}
export function chatGPTSignInPath(_returnTo:string){return "/settings";}
export function chatGPTSignOutPath(_returnTo="/"){return "/";}
