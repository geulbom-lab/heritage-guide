'use client';
import {useState} from 'react';
import {Copy,ExternalLink} from 'lucide-react';
import {Button} from '@/components/ui/button';
import {Input} from '@/components/ui/input';
import {Label} from '@/components/ui/label';
import {Textarea} from '@/components/ui/textarea';
import {attribution,attributionHTML,type AttributionDetails,type Selection} from '@/lib/public-guide';

export default function AttributionPanel({selection}:{selection:Selection}){
  const [details,setDetails]=useState<AttributionDetails>({});
  const [notice,setNotice]=useState('');
  const [creditOpen,setCreditOpen]=useState(true);
  const knownInstitution=selection.record.institution==='제공기관 미확인'?'':selection.record.institution;
  const needsInstitution=!knownInstitution.trim();
  function update(key:keyof AttributionDetails,value:string){setDetails(d=>({...d,[key]:value}));setNotice('');}
  async function copy(){
    const text=attribution(selection,details);
    if(typeof ClipboardItem!=='undefined'&&navigator.clipboard?.write){
      try{
        await navigator.clipboard.write([new ClipboardItem({'text/plain':new Blob([text],{type:'text/plain'}),'text/html':new Blob([attributionHTML(selection,details)],{type:'text/html'})})]);
        setNotice('출처 초안과 링크를 복사했어요. 붙여넣은 곳에서 링크가 유지되는지 확인해 주세요.');return;
      }catch{/* Plain-text fallback for browsers or editors without HTML clipboard support. */}
    }
    try{await navigator.clipboard.writeText(text);setNotice('텍스트로 복사했어요. 온라인 게시물에는 출처 문장의 원문 주소를 하이퍼링크로 연결해 주세요.');}
    catch{setNotice('자동 복사를 사용할 수 없어요. 위의 출처 초안을 선택해 복사해 주세요.');}
  }
  const missing=[!((details.institution??knownInstitution).trim())?'기관명':'',!details.year?.trim()?'작성연도':'',!details.author?.trim()?'작성자·저작권자':''].filter(Boolean);
  return <section className="hg-attribution-editor" aria-label="출처표시">
    <h3>출처표시</h3>
    <Label htmlFor="attribution-text" className="sr-only">복사할 출처 문장</Label>
    <Textarea id="attribution-text" readOnly value={attribution(selection,details)}/>
    <div className="hg-attribution-actions"><Button className="hg-primary" onClick={()=>void copy()}><Copy size={18}/>{missing.length?'출처 초안 복사':'출처 복사'}</Button></div>
    {notice&&<p className="hg-copy-notice" role="status">{notice}</p>}
    <details className="hg-credit-edit" open={creditOpen} onToggle={e=>setCreditOpen(e.currentTarget.open)}>
      <summary>{missing.length?`${missing.join(' · ')} 확인 필요`:'출처 정보 수정'}</summary>
      <p className="hg-small">원문에서 확인한 내용을 입력해 주세요. 문장에 바로 반영돼요.</p>
      <div className="hg-attribution-fields">
        {(needsInstitution||missing.length===0)&&<div><Label htmlFor="credit-institution">기관명</Label><Input id="credit-institution" maxLength={150} value={details.institution??knownInstitution} onChange={e=>update('institution',e.target.value)}/></div>}
        <div><Label htmlFor="credit-year">이미지 작성연도</Label><Input id="credit-year" maxLength={40} placeholder="원문에서 확인한 작성연도" value={details.year??''} onChange={e=>update('year',e.target.value)}/></div>
        <div><Label htmlFor="credit-author">이미지 작성자·저작권자</Label><Input id="credit-author" maxLength={150} placeholder="원문에 표시된 이름" value={details.author??''} onChange={e=>update('author',e.target.value)}/></div>
      </div>
      <p className="hg-small">유물 제작연도·작가와 이미지의 작성연도·작성자는 다를 수 있어요. 원문에 없으면 제공기관에 확인해 주세요.</p>
      <a className="hg-outline-link" href={selection.record.source} target="_blank" rel="noreferrer">원문에서 정보 확인 <ExternalLink size={15}/></a>
    </details>
    <p className="hg-small">‘확인 필요’ 항목을 보완하고, 온라인에서는 가능한 경우 출처 링크를 함께 넣어 주세요. 출처 복사가 이용 허락을 뜻하지는 않아요.</p>
  </section>;
}
