import { publicImageTarget, publicRateLimit } from '@/lib/public-source';
export async function GET(request:Request) {
  try {
    if(!publicRateLimit(request))return new Response(null,{status:429});
    const target=await publicImageTarget(new URL(request.url).searchParams.get('ticket')??'');
    // Reuse the existing, user-observed browser image delivery method. No
    // server image fetch, retry, request impersonation or image-file storage.
    return new Response(null,{status:307,headers:{'Location':target.href,'Cache-Control':'private, no-store','Referrer-Policy':'strict-origin-when-cross-origin','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'"}});
  }catch{return new Response(null,{status:404,headers:{'Cache-Control':'no-store'}});}
}
