import {makeFeedbackHandler} from '@/lib/feedback-handler';
import {saveFeedback} from '@/lib/feedback-store';
const limits=new Map<string,{until:number;count:number}>();
export const POST=makeFeedbackHandler(saveFeedback,request=>{
  const now=Date.now();for(const [key,item] of limits)if(item.until<now)limits.delete(key);
  if(limits.size>3000)return false;
  const ip=request.headers.get('cf-connecting-ip')||'local';
  const item=limits.get(ip)??{until:now+60000,count:0};item.count++;limits.set(ip,item);return item.count<=5;
});
