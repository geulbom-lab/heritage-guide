import {refinedSearch} from '@/lib/public-refinement';
import { keyConfigured } from '@/lib/server';
import { publicCapture, publicRateLimit, publicRecord, publicImage } from '@/lib/public-source';
import { suggestSearchTerm } from '@/lib/public-guide';
import { searchTerms, relevantTitle, uniqueRecords, searchPagination } from '@/lib/public-search';

export async function GET(request:Request) {
  const headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
  const error=(message:string,status=503)=>Response.json({message},{status,headers});
  try {
    const p=new URL(request.url).searchParams,q=(p.get('q')??'').trim(),page=Number(p.get('page')??1);
    if(!q||q.length>150||!Number.isInteger(page)||page<1||page>100)return error('찾고 싶은 자료 이름을 150자 이내로 입력해 주세요.',400);
    if(!publicRateLimit(request))return error('요청이 많아요. 잠시 후 다시 검색해 주세요.',429);
    if(!await keyConfigured())return error('자료 검색 연결을 준비 중이에요. 잠시 후 다시 이용해 주세요.');
    const term=suggestSearchTerm(q);
    if(!term)return error('찾을 이미지 이름을 입력해 주세요.',400);
    const terms=searchTerms(term);
    if(p.get('refine')==='1'){
      const within=(p.get('within')??'').trim(),institution=(p.get('institution')??'').trim();
      if(within.length>100||institution.length>150)return error('좁힐 검색어와 소장기관 이름을 짧게 입력해 주세요.',400);
      try{return Response.json(await refinedSearch(terms,page,within,institution),{headers});}
      catch(e){return error(e instanceof Error?e.message:'전체 결과를 확인하지 못했어요.');}
    }
    const responses=await Promise.allSettled(terms.map(query=>publicCapture({kind:'list',query,page,size:12})));
    const available=responses.flatMap(response=>response.status==='fulfilled'&&response.value.capture.normalized.ok?[response.value]:[]);
    if(!available.length)return error('e뮤지엄에서 자료를 가져오지 못했어요. 잠시 후 이 화면에서 다시 검색해 주세요.');
    const groups=await Promise.all(available.map(async({capture:c,sealedImageLinks})=>{
      const records=await Promise.all(c.normalized.records.map(async(r,index)=>r.id&&relevantTitle(r.title,terms)?{...publicRecord(r,c.captured_at),image:await publicImage(sealedImageLinks,c.capture_id,`record-${index+1}`)}:null));
      return records.filter((r):r is NonNullable<typeof r>=>r!==null);
    }));
    const pagination=searchPagination(available.map(({capture:c})=>({total:c.normalized.total_count,count:c.normalized.records.length})),page,available.length===terms.length);
    // Do not present upstream totals as the size of a deduplicated, filtered union.
    return Response.json({records:uniqueRecords(groups.flat(),terms),total:null,page,
      ...pagination,
      checkedAt:available[0].capture.captured_at,searchTerms:terms,partial:available.length<terms.length},{headers});
  }catch{return error('자료 연결이 잠시 원활하지 않아요. 입력한 내용은 유지되니 다시 시도해 주세요.');}
}
