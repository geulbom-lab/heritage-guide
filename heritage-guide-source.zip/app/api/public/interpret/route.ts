import { analyzeQuestion } from '@/lib/question-analysis';
import { makeInterpretHandler, createInterpretLimiter } from '@/lib/interpret-handler';
import { languageModelKey } from '@/lib/server';

export const dynamic = 'force-dynamic';
export const POST = makeInterpretHandler(
  async (question, signal) => analyzeQuestion(question, { apiKey: await languageModelKey(), signal }),
  createInterpretLimiter(),
);
