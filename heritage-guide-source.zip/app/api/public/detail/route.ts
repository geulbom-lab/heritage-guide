import { keyConfigured } from '@/lib/server';
import { publicCapture, publicRateLimit, publicRecord, publicImage, imageRights } from '@/lib/public-source';

export async function GET(request:Request) {
  const headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
  const error=(message:string,status=503)=>Response.json({message},{status,headers});
  try {
    const id=new URL(request.url).searchParams.get('id')??'';
    if(!/^[A-Za-z0-9_-]{1,100}$/.test(id))return error('자료 주소를 확인해 주세요.',400);
    if(!publicRateLimit(request))return error('요청이 많아요. 잠시 후 다시 시도해 주세요.',429);
    if(!await keyConfigured())return error('자료 검색 연결을 준비 중이에요.');
    const {capture:c,sealedImageLinks}=await publicCapture({kind:'detail',id,page:1,size:12});
    const r=c.normalized.records.find(r=>r.id===id);
    if(!c.normalized.ok||!r)return error('이미지별 정보를 가져오지 못했어요. e뮤지엄 원문에서 확인해 주세요.');
    const record=publicRecord(r,c.captured_at);
    const images=await Promise.all(c.normalized.images.filter(i=>i.record_id===id||(i.record_id===null&&c.normalized.records.length===1)).slice(0,60).map(async i=>({id:`${id}:${i.ordinal}`,ordinal:i.ordinal,image:await publicImage(sealedImageLinks,c.capture_id,String(i.ordinal)),rights:imageRights({candidate_id:i.observation_id,record:r,image:i,capture:c,search_context:{query:'',page:1,capture_id:null}})})));
    return Response.json({record,images},{headers});
  }catch{return error('상세 정보를 가져오지 못했어요. 다시 시도하거나 원문을 확인해 주세요.');}
}
