import { getChatGPTUser } from '@/app/chatgpt-auth';
import { ownerEmail, saveServiceKey } from '@/lib/service-settings';
import { makeSaveSettings } from '@/lib/settings-handler';
import { collect } from '@/lib/emuseum/source';
import { clearPublicCache } from '@/lib/public-source';
export const POST=makeSaveSettings({
  user:getChatGPTUser,ownerEmail,save:saveServiceKey,clearCache:clearPublicCache,
  validate:async key=>(await collect({kind:'list',query:'호랑이',page:1,size:1},key)).capture.normalized.ok,
});
