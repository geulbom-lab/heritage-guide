import { getChatGPTUser } from '@/app/chatgpt-auth';
import { ownerEmail } from '@/lib/service-settings';
import { saveGeminiKey, removeGeminiKey } from '@/lib/gemini-settings';
import { makeGeminiSettings } from '@/lib/gemini-settings-handler';
import { analyzeQuestion } from '@/lib/question-analysis';
import { createInterpretLimiter } from '@/lib/interpret-handler';

export const dynamic = 'force-dynamic';
const handler = makeGeminiSettings({
  user: getChatGPTUser, ownerEmail, save: saveGeminiKey, remove: removeGeminiKey,
  analyze: (question, apiKey, signal) => analyzeQuestion(question, { apiKey, signal }),
  acquire: createInterpretLimiter(),
});
export const POST = handler;
export const DELETE = handler;
