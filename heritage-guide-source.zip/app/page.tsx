import HeritageGuide from './heritage-guide';
import { keyConfigured, languageModelConfigured } from '@/lib/server';
export const dynamic = 'force-dynamic';
export default async function Home() {
  const [searchReady, languageModelReady] = await Promise.all([keyConfigured(), languageModelConfigured()]);
  return <HeritageGuide searchReady={searchReady} languageModelReady={languageModelReady} />;
}
