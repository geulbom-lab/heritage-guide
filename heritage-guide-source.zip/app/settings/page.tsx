import { getChatGPTUser, chatGPTSignInPath, chatGPTSignOutPath } from '../chatgpt-auth';
import { isSettingsOwner } from '@/lib/settings-security';
import { connectionStatus, ownerEmail } from '@/lib/service-settings';
import { listFeedback } from '@/lib/feedback-store';
import { geminiConnectionStatus } from '@/lib/gemini-settings';
import GeminiSettingsForm from './gemini-settings-form';
import SettingsForm from './settings-form';
import './settings.css';
export const dynamic='force-dynamic';
export default async function SettingsPage(){
  const user=await getChatGPTUser();
  const allowed=isSettingsOwner(user,ownerEmail());
  let geminiStatus=null;
  if(allowed){try{geminiStatus=await geminiConnectionStatus();}catch{}}
  let status=null;
  if(allowed){try{status=await connectionStatus();}catch{}}
  let reports:Awaited<ReturnType<typeof listFeedback>>=[];let reportsError=false;
  if(allowed){try{reports=await listFeedback();}catch{reportsError=true;}}
  return <main className="settings-page"><a className="settings-back" href="/">← 일반용 사이트로</a><p className="settings-kicker">운영자 설정</p><h1>검색과 문장 이해 연결</h1><p className="settings-lead">인증키를 한 번 연결하면 누구나 이 사이트에서 문화유산 이미지를 찾을 수 있어요.</p>
    {!user?<section className="settings-card"><h2>운영자 로그인이 필요해요</h2><p>이 사이트를 만든 ChatGPT 계정으로 로그인해 주세요. 일반 이용자는 로그인 없이 검색할 수 있어요.</p><a className="settings-primary" href={chatGPTSignInPath('/settings')} target="_top">ChatGPT로 운영자 로그인</a></section>:!allowed?<section className="settings-card"><h2>운영자 전용 설정이에요</h2><p>현재 로그인한 계정에는 설정을 변경할 권한이 없어요.</p><a className="settings-primary" href={chatGPTSignOutPath('/settings')} target="_top">로그아웃하고 계정 변경</a></section>:<><p className="settings-account">{user.email} · 운영자</p><SettingsForm initialStatus={status}/><GeminiSettingsForm initialStatus={geminiStatus}/><section className="settings-card"><h2>접수된 오류 신고</h2><p>최근 50건 · 이용자가 보낸 내용이며 검증된 판정 근거는 아닙니다.</p>{reportsError?<p>신고 목록을 불러오지 못했어요.</p>:reports.length===0?<p>아직 접수된 신고가 없어요.</p>:reports.map(report=><details key={report.id}><summary>{report.created_at.slice(0,10)} · {report.data.title||'일반 오류 신고'}</summary><p style={{whiteSpace:'pre-wrap',overflowWrap:'anywhere'}}>{report.data.message}</p><p>이미지 {report.data.imageOrdinal||'-'} · 유형 {report.data.licence||'-'} · 판매 {report.data.commercial||'-'} · 편집 {report.data.modification||'-'}</p><p>당시 안내: {report.data.verdict||'-'}</p>{report.data.recordId&&<a href={`https://www.emuseum.go.kr/detail?relicId=${encodeURIComponent(report.data.recordId)}`} target="_blank" rel="noreferrer">대상 자료 원문</a>}</details>)}</section><a className="settings-back" href={chatGPTSignOutPath('/')} target="_top">운영자 로그아웃</a></>}
  </main>;
}
