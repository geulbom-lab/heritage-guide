'use client';
import { useState } from 'react';
type Status={configured:boolean;updatedAt:string|null;canSave:boolean};
export default function SettingsForm({initialStatus}:{initialStatus:Status|null}){
  const [status,setStatus]=useState(initialStatus),[key,setKey]=useState(''),[busy,setBusy]=useState(false),[visible,setVisible]=useState(false),[message,setMessage]=useState(''),[failed,setFailed]=useState(false);
  async function save(event:React.FormEvent<HTMLFormElement>){
    event.preventDefault();if(busy||!key.trim())return;
    setBusy(true);setMessage('');setFailed(false);
    try{
      const response=await fetch('/api/settings/emuseum',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({serviceKey:key}),cache:'no-store'});
      const raw:unknown=await response.json();
      if(!raw||typeof raw!=='object'||!('message' in raw)||typeof raw.message!=='string')throw Error('invalid_response');
      const data={message:raw.message,updatedAt:'updatedAt' in raw && typeof raw.updatedAt==='string'?raw.updatedAt:null};
      setMessage(data.message||'설정 응답을 확인하지 못했어요.');setFailed(!response.ok);
      if(response.ok){setKey('');setVisible(false);setStatus({configured:true,updatedAt:data.updatedAt,canSave:true});}
    }catch{setMessage('연결이 잠시 끊겼어요. 입력한 키는 유지했으니 다시 시도해 주세요.');setFailed(true);}
    finally{setBusy(false);}
  }
  return <section className="settings-card"><div className="settings-status"><span className={status?.configured?'connected':''}/><strong>{status?.configured?'검색 연결됨':'인증키 연결 필요'}</strong></div>
    {status?.updatedAt&&<p className="settings-muted">마지막 연결 확인: {new Date(status.updatedAt).toLocaleString('ko-KR',{timeZone:'Asia/Seoul'})}</p>}
    {!status?.canSave?<p role="alert">설정 저장소를 불러오지 못했어요. 잠시 후 새로고침해 주세요.</p>:<form onSubmit={save}><label htmlFor="emuseum-key">e뮤지엄 API 인증키</label><p id="key-help" className="settings-muted">발급받은 인증키를 붙여 넣어 주세요. 인코딩·디코딩 키 모두 입력할 수 있어요.{status.configured?' 새 키의 연결 확인에 성공한 경우에만 교체해요.':''}</p><div className="settings-input"><input id="emuseum-key" type={visible?'text':'password'} autoComplete="off" spellCheck={false} maxLength={2048} value={key} onChange={e=>setKey(e.target.value)} placeholder={status.configured?'교체할 인증키 입력':'인증키 붙여 넣기'} aria-describedby="key-help" disabled={busy}/><button type="button" onClick={()=>setVisible(v=>!v)} aria-pressed={visible}>{visible?'숨기기':'보기'}</button></div><button className="settings-primary" type="submit" disabled={busy||!key.trim()}>{busy?'e뮤지엄 연결 확인 중…':'연결 확인하고 저장'}</button><p className="settings-muted">연결 확인은 최대 30초 정도 걸릴 수 있어요. 저장된 키는 암호화해 보관하며 화면에 다시 표시하지 않아요.</p></form>}
    {message&&<p className={failed?'settings-error':'settings-success'} role={failed?'alert':'status'}>{message}</p>}
    {status?.configured&&<a className="settings-search" href="/">일반용 사이트에서 검색해 보기 →</a>}
    <details><summary>연결이 안 될 때</summary><p>e뮤지엄 API의 활용 승인이 완료되었는지 확인해 주세요. 키 앞뒤의 공백은 자동으로 제거해요. 호출 한도나 제공기관의 일시적인 응답 지연이 있으면 잠시 후 다시 시도해 주세요.</p></details>
  </section>;
}
