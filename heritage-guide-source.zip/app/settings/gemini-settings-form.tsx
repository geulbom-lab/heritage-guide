'use client';
import { useState } from 'react';

type Status = { configured: boolean; updatedAt: string | null; canSave: boolean };
export default function GeminiSettingsForm({ initialStatus }: { initialStatus: Status | null }) {
  const [status, setStatus] = useState(initialStatus);
  const [key, setKey] = useState('');
  const [confirmed, setConfirmed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [failed, setFailed] = useState(false);

  async function update(method: 'POST' | 'DELETE') {
    setBusy(true); setMessage(''); setFailed(false);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 20000);
    try {
      const response = await fetch('/api/settings/gemini', {
        method, signal: controller.signal,
        headers: { 'Content-Type': 'application/json' },
        ...(method === 'POST' ? { body: JSON.stringify({ apiKey: key, freeTierConfirmed: confirmed }) } : {}),
      });
      const data = await response.json() as { message?: string; configured: boolean; updatedAt: string | null };
      if (!response.ok) throw Error(data.message || '연결을 확인하지 못했어요.');
      setStatus({ configured: data.configured, updatedAt: data.updatedAt, canSave: true });
      setKey(''); setConfirmed(false); setMessage(data.message || '설정을 저장했어요.');
    } catch (error) {
      setFailed(true);
      setMessage(error instanceof Error && error.name !== 'AbortError' && error.name !== 'SyntaxError'
        ? error.message : '응답을 확인하지 못했어요. 새로고침해 연결 상태를 확인해 주세요.');
    } finally { clearTimeout(timer); setBusy(false); }
  }

  return <section className="settings-card" id="gemini">
    <h2>AI 문장 이해 · Gemini</h2>
    <div className="settings-status"><span className={status?.configured ? 'connected' : ''}/><strong>{status?.configured ? '연결됨' : '연결 전'}</strong></div>
    {status?.updatedAt && <p className="settings-muted">마지막 연결 검사: {new Date(status.updatedAt).toLocaleDateString('ko-KR', { timeZone: 'Asia/Seoul' })}</p>}
    <p>문장에서 찾을 자료와 사용 목적을 읽어요. 자료 이름만 입력하면 AI를 거치지 않고 검색해요.</p>
    <ol className="settings-steps">
      <li><a href="https://aistudio.google.com/api-keys" target="_blank" rel="noreferrer">Google AI Studio의 API Keys 열기 ↗</a><br/>Google 계정으로 로그인하고 API 키를 만드세요.</li>
      <li>키가 속한 프로젝트가 <strong>Free Tier</strong>인지 확인하세요. 무료로 이용하려면 결제를 연결하거나 유료 등급으로 올리지 마세요.</li>
      <li>키를 아래에 붙여넣고 연결 검사를 누르세요. 키는 채팅에 보낼 필요가 없어요.</li>
    </ol>
    <p className="settings-muted">Gemini 2.5 Flash-Lite의 무료 제공 범위를 이용해요. 계정·지역에 따라 이용 가능 여부와 한도가 달라요. 사이트는 Google의 결제 상태를 자동으로 확인할 수 없으므로 프로젝트 설정을 직접 확인해 주세요.</p>
    <p className="settings-muted">문장 검색 내용은 Google에 전달되며, 무료 서비스에서는 제품 개선에 사용될 수 있어요. 개인정보나 비공개 자료는 입력하지 마세요. 이용자에게도 검색창에서 안내해요. <a href="https://ai.google.dev/gemini-api/docs/pricing" target="_blank" rel="noreferrer">무료 제공 조건 확인 ↗</a></p>
    <form onSubmit={event => { event.preventDefault(); void update('POST'); }}>
      <label htmlFor="gemini-key">Gemini API 키{status?.configured ? ' 교체' : ''}</label>
      <div className="settings-input"><input id="gemini-key" type="password" autoComplete="off" spellCheck={false} value={key} maxLength={2048} onChange={event => setKey(event.target.value)} placeholder="발급한 키 붙여넣기" required disabled={busy || !status?.canSave}/></div>
      <label className="settings-confirm"><input type="checkbox" checked={confirmed} onChange={event => setConfirmed(event.target.checked)} disabled={busy || !status?.canSave}/><span>이 키의 프로젝트가 결제 연결 없는 무료 등급임을 확인했고, 위의 Google 데이터 이용 안내를 읽었어요.</span></label>
      <p className="settings-muted">연결 검사에서는 “논문에 쓰고싶은데 그게 뭐냐면 경향신문을 논문에 쓰려고”를 Google에 보내요. ‘경향신문’이 추출되면 키를 암호화해 저장해요. 한 문장 검사가 모든 표현의 정확성을 보장하지는 않아요.</p>
      <button className="settings-primary" type="submit" disabled={busy || !status?.canSave || !key.trim() || !confirmed}>{busy ? '처리 중…' : '시험 문장 확인하고 연결'}</button>
    </form>
    {!status?.canSave && <p className="settings-error">서버의 설정 저장 기능을 확인할 수 없어요. 잠시 후 새로고침해 주세요.</p>}
    {message && <p className={failed ? 'settings-error' : 'settings-success'} role="status">{message}</p>}
    {status?.configured && <><a className="settings-search" href="/">문장으로 검색해 보기 →</a><button type="button" className="settings-disconnect" disabled={busy} onClick={() => void update('DELETE')}>AI 연결 해제</button></>}
  </section>;
}
