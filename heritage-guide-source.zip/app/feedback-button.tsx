'use client';
import {useState} from 'react';
import {Dialog,DialogContent,DialogHeader,DialogTitle,DialogDescription} from '@/components/ui/dialog';
import {Textarea} from '@/components/ui/textarea';
import {Label} from '@/components/ui/label';
import {Button} from '@/components/ui/button';
import type {Feedback} from '@/lib/feedback-handler';
export default function FeedbackButton({context={},label='오류 신고'}:{context?:Partial<Feedback>;label?:string}){
  const [open,setOpen]=useState(false),[message,setMessage]=useState(''),[status,setStatus]=useState(''),[busy,setBusy]=useState(false),[sent,setSent]=useState(false);
  async function submit(){
    setBusy(true);setStatus('');
    try{const response=await fetch('/api/public/feedback',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...context,message})});const data=await response.json() as {message?:string};if(!response.ok)throw Error(data.message||'신고를 저장하지 못했어요.');setSent(true);setStatus(data.message||'신고를 접수했어요.');}
    catch(e){setStatus(e instanceof Error?e.message:'신고를 저장하지 못했어요.');}finally{setBusy(false);}
  }
  return <><button type="button" className="hg-text-button" onClick={()=>{if(sent){setMessage('');setStatus('');setSent(false);}setOpen(true);}}>{label}</button><Dialog open={open} onOpenChange={setOpen}><DialogContent className="hg-help-dialog"><DialogHeader><DialogTitle>어떤 안내가 잘못됐나요?</DialogTitle><DialogDescription>운영자 Geulbom Lab에게 전달할 오류 내용을 적어 주세요.</DialogDescription></DialogHeader><form onSubmit={e=>{e.preventDefault();void submit();}} className="hg-report-form"><p>작성한 의견{context.recordId?'과 자료명·이미지 번호·현재 사용조건·안내 결과를':'을'} 오류 확인 용도로 저장하며 운영자만 볼 수 있어요. 검색 질문 전체는 보내지 않아요. 이름·연락처 등 개인정보는 적지 마세요.</p>{context.title&&<p><strong>대상 자료:</strong> {context.title}</p>}<Label htmlFor={context.recordId?'report-result':'report-general'}>오류 내용</Label><Textarea id={context.recordId?'report-result':'report-general'} required minLength={5} maxLength={1000} value={message} onChange={e=>setMessage(e.target.value)} disabled={sent} placeholder="어떤 결과가 나왔고 무엇이 다른지 알려 주세요."/><Button className="hg-primary" disabled={busy||sent||message.trim().length<5}>{busy?'접수 중…':sent?'접수 완료':'오류 신고 보내기'}</Button><p role="status">{status}</p></form></DialogContent></Dialog></>;
}
