import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "이 문화유산, 써도 되나요?",
  description: "문화유산 이미지를 찾고, 사용 목적에 맞는 이용조건을 비교하고, 출처표시까지 챙겨 보세요.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ko">
      <body className="antialiased">{children}</body>
    </html>
  );
}
