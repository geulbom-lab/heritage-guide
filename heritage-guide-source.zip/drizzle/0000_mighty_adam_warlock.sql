CREATE TABLE `service_settings` (
	`id` text PRIMARY KEY NOT NULL,
	`encrypted_value` text NOT NULL,
	`updated_at` text NOT NULL,
	`updated_by` text NOT NULL
);
