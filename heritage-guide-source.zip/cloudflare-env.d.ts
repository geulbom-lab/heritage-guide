declare namespace Cloudflare {
  interface Env {
    DB?: D1Database;
    SETTINGS_ENCRYPTION_KEY?: string;
    SETTINGS_OWNER_EMAIL?: string;
    EMUSEUM_SERVICE_KEY?: string;
    EMUSEUM_IMAGE_ENCRYPTION_KEY?: string;
  }
}
