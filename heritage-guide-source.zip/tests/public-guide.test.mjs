// Synthetic regression checks for public guidance. These are not research results.
import test from 'node:test';
import assert from 'node:assert/strict';
import { guidance, suggestQuestion, hasUsageIntent, attribution, attributionHTML } from '../lib/public-guide.ts';
import { searchTerms, uniqueRecords } from '../lib/public-search.ts';
test('research context is separated from a title without assuming noncommercial use',()=>{
  for(const [question,query] of [
    ['근데 내가 논문쓰는데 고려청자 사진이 필요해. 논문에 쓸 사진이야','고려청자'],
    ['그런데 내가 논문을 쓰고 있는데 고려 청자 사진을 쓰려고 해. 논문에 쓸 사진이 필요해','고려 청자'],
    ['보고서를 작성하는데 백자 청화 구름 용무늬 항아리 사진이 필요해','백자 청화 구름 용무늬 항아리'],
    ['과제 준비하는데 천마총 금관 사진이 필요해','천마총 금관'],
    ['근데 내가 논문쓰는데 사진이 필요해',''],
    ['논문을 쓰는데 고려청자 사진과 백자 사진을 쓰려고 해',''],
  ])assert.deepEqual(suggestQuestion(question),{query,commercial:'unknown',modification:'unknown'},question);
});
test('natural-language searches separate the object name from the intended use',()=>{
  for(const [question,query] of [
    ['청자 문화유산을 수업자료로 쓰고 싶어','청자'],
    ['고양이 그림을 수업 자료에 넣고 싶어','고양이'],
    ['호작도를 티셔츠에 넣어 판매하고 싶어.','호작도'],
    ['해시계를 굿즈에 넣어 판매하고 싶어요.','해시계'],
    ['호랑이와 까치를 티셔츠에 넣고 싶어요.','호랑이와 까치'],
    ['티셔츠에 호작도를 넣어 판매하고 싶어요.','호작도'],
    ['호작도로 엽서를 만들고 싶어요.','호작도'],
    ['일월오봉도 이미지를 편집해 판매할 엽서를 만들고 싶어요.','일월오봉도'],
    ['호작도 티셔츠 만들기','호작도'],
    ['호작도 써도 되나요?','호작도'],
    ['“호랑이와 까치”를 상품에 쓰고 싶어요.','호랑이와 까치'],
  ])assert.equal(suggestQuestion(question).query,query,question);
  const actual=suggestQuestion('호작도를 티셔츠에 넣어 판매하고 싶어.');
  assert.equal(actual.commercial,'yes');assert.equal(actual.modification,'unknown');
});
test('bare titles are never stripped or broadened to a known substring',()=>{
  for(const title of ['호작도','해시계','기와','호랑이','사계산수도','호랑이와 까치','백자 청화 구름 용무늬 항아리'])
    assert.equal(suggestQuestion(title).query,title);
  assert.equal(suggestQuestion('판매할 티셔츠를 만들고 싶어요.').query,'');
});
test('reproduction and publication plans keep the manuscript title separate',()=>{
  const question='말모이 원고 원문 전체를 복제한 영인본을 제작해서 판매하고 싶어.';
  assert.deepEqual(suggestQuestion(question),{query:'말모이 원고',commercial:'yes',modification:'unknown'});
  for(const [sentence,query] of [
    ['말모이 원고를 복제해서 판매하고 싶어요.','말모이 원고'],
    ['말모이 원고의 원문 전체를 복제해서 판매하고 싶어요.','말모이 원고'],
    ['말모이 원고 전체를 그대로 인쇄해서 판매하고 싶어요.','말모이 원고'],
    ['말모이 원고 복제해서 판매하고 싶어요.','말모이 원고'],
    ['훈민정음 해례본 원문 일부를 수업 자료로 쓰고 싶어요.','훈민정음 해례본'],
    ['조선말 큰사전 원문 전체를 복제한 영인본을 제작하고 싶어요.','조선말 큰사전'],
    ['“말모이 원고” 원문 전체를 복제한 영인본을 판매하고 싶어요.','말모이 원고'],
    ['원문 전체를 복제한 영인본을 제작해서 판매하고 싶어요.',''],
    ['영인본을 제작하고 싶어요.',''],
  ])assert.equal(suggestQuestion(sentence).query,query,sentence);
  // Repeated client/server extraction must preserve the complete title.
  assert.equal(suggestQuestion(suggestQuestion(question).query).query,'말모이 원고');
  for(const title of ['말모이 원고','말모이 영인본','훈민정음 해례본','조선말 큰사전','말모이 원고 원문 전체'])
    assert.equal(suggestQuestion(title).query,title);
  assert.equal(suggestQuestion('말모이 원고 전체를 그대로 인쇄해서 판매하고 싶어요.').modification,'no');
  assert.equal(suggestQuestion('말모이 원고 원문 전체를 편집해 판매하고 싶어요.').modification,'yes');
  assert.equal(suggestQuestion('말모이 원고 원문 전체를 복제하고 판매하지 않겠습니다.').commercial,'no');
});
test('destination-first sentences search the named source, with or without a comma',()=>{
  for(const question of [
    '컵을 만들껀데, 말모이 원고 사진을 쓰려고해.',
    '컵을 만들껀데 말모이 원고 사진을 쓰려고해.',
    '컵을 만들 건데 말모이 원고 사진을 쓰려고 해.',
    '컵을 만들고 말모이 원고 사진을 쓰려고 해.',
    '컵에 말모이 원고 사진을 넣고 싶어.',
    '컵 안쪽에 말모이 원고 사진을 넣고 싶어.',
    '제가 컵을 만들 건데 말모이 원고 사진을 쓰려고 해.',
    '컵을 만들 건데 말모이 원고를 쓰려고 해.',
    '말모이 원고 사진으로 컵을 만들고 싶어.',
    '말모이 원고 사진 이미지를 쓰고 싶어.',
    '“컵”을 만들 건데 말모이 원고 사진을 쓰려고 해.',
    '컵을 만들껀데, “말모이 원고” 사진을 쓰려고해.',
  ]){
    const actual=suggestQuestion(question);
    assert.deepEqual(actual,{query:'말모이 원고',commercial:'unknown',modification:'unknown'},question);
    assert.equal(suggestQuestion(actual.query).query,actual.query);
  }
  for(const [question,query] of [
    ['텀블러에 호작도를 넣고 싶어요.','호작도'],
    ['가방을 만들 건데 청자 무늬를 쓰려고 해요.','청자'],
    ['노트에 훈민정음 해례본 이미지를 넣고 싶어.','훈민정음 해례본'],
    ['엽서를 제작하려고 조선말 큰사전 원문 일부를 사용하고 싶어.','조선말 큰사전'],
  ])assert.equal(suggestQuestion(question).query,query,question);
  assert.equal(suggestQuestion('판매할 컵에 말모이 원고 사진을 넣고 싶어.').commercial,'yes');
  assert.equal(suggestQuestion('컵을 만들껀데, 말모이 원고 사진을 쓰려고해. 판매는 안 할 거야.').commercial,'no');
  // Synthetic result filtering checks the actual query used by the API path.
  const query=suggestQuestion('컵을 만들껀데, 말모이 원고 사진을 쓰려고해.').query;
  assert.deepEqual(uniqueRecords([{id:'1',title:'컵'},{id:'2',title:'말모이 원고'}],searchTerms(query)),[{id:'2',title:'말모이 원고'}]);
});
test('cups remain valid source objects; missing or multiple sources prompt for a title',()=>{
  for(const [question,query] of [
    ['컵','컵'],['청자 컵','청자 컵'],
    ['컵 사진을 엽서에 쓰려고 해.','컵'],
    ['청자 컵 사진을 티셔츠에 넣고 싶어요.','청자 컵'],
    ['컵을 만들려고 해.',''],
    ['컵을 만들건데 사진을 쓰려고 해.',''],
    ['말모이 원고 사진과 훈민정음 해례본 사진을 넣고 싶어요.',''],
    ['“말모이 원고”와 “훈민정음 해례본”을 쓰려고 해.',''],
  ])assert.equal(suggestQuestion(question).query,query,question);
});
test('informal source names without particles do not require a title prompt',()=>{
  for(const [question,query] of [
    ['텀블러에 호작도 넣어서 팔자','호작도'],
    ['텀블러에 호작도 넣고 팔래','호작도'],
    ['호작도 텀블러에 넣어서 팔자','호작도'],
    ['호작도를 텀블러에 넣어서 팔자','호작도'],
    ['호랑이와 까치 텀블러에 넣어서 팔자','호랑이와 까치'],
    ['텀블러에 말모이 원고 넣어서 팔자','말모이 원고'],
    ['엽서에 훈민정음 해례본 넣고 팔려고','훈민정음 해례본'],
    ['호작도 팔자','호작도'],
  ]){
    assert.deepEqual(suggestQuestion(question),{query,commercial:'yes',modification:'unknown'},question);
    assert.equal(hasUsageIntent(question),true,question);
    assert.equal(suggestQuestion(query).query,query);
  }
  assert.deepEqual(suggestQuestion('호작도 넣자'),{query:'호작도',commercial:'unknown',modification:'unknown'});
  assert.equal(hasUsageIntent('호작도'),false);
  const purpose=suggestQuestion('텀블러에 호작도 넣어서 팔자');
  for(const type of ['2','4'])assert.equal(guidance({type,confirmed:true,conflict:false},purpose).status,'restricted');
});
test('colloquial sale suggestions retain negative and conflicting intentions',()=>{
  for(const ending of ['안 팔 거야','팔지 않을 거야','팔지 말자','팔 생각 없어','팔려고 하지 않아'])
    assert.equal(suggestQuestion(`텀블러에 호작도 넣고 ${ending}`).commercial,'no',ending);
  assert.equal(suggestQuestion('호작도 넣고 일부는 안 팔고 일부는 판매할 거야').commercial,'unknown');
  assert.equal(suggestQuestion('텀블러에 호작도 그대로 넣어서 팔자').modification,'no');
});
test('all four supported types respect explicit commercial and modification choices',()=>{
  for(const type of ['1','2','3','4'])for(const commercial of ['yes','no'])for(const modification of ['yes','no']){
    const restricted=(commercial==='yes'&&['2','4'].includes(type))||(modification==='yes'&&['3','4'].includes(type));
    assert.equal(guidance({type,confirmed:true,conflict:false},{commercial,modification}).status,restricted?'restricted':'match');
  }
});
test('unverified, conflicting and unknown rights never produce a match',()=>{
  for(const rights of [{type:'1',confirmed:false,conflict:false},{type:null,confirmed:true,conflict:false},{type:'1',confirmed:true,conflict:true}])
    assert.equal(guidance(rights,{commercial:'no',modification:'no'}).status,'unknown');
  assert.equal(guidance({type:'1',confirmed:true,conflict:false},{commercial:'unknown',modification:'no'}).status,'match');
});
test('question suggestions distinguish negative statements and never assume a platform means noncommercial',()=>{
  assert.deepEqual(suggestQuestion('청자 무늬를 편집해 판매할 엽서를 만들고 싶어요.'),{query:'청자',commercial:'yes',modification:'yes'});
  assert.deepEqual(suggestQuestion('훈민정음 이미지를 비영리 수업 자료에 그대로 넣고 싶어요.'),{query:'훈민정음',commercial:'no',modification:'no'});
  assert.equal(suggestQuestion('민화 이미지를 유튜브에 올리고 싶어요.').commercial,'unknown');
  assert.equal(suggestQuestion('청자 이미지를 판매하지 않고 수정하지 않겠습니다.').commercial,'no');
  assert.equal(suggestQuestion('청자 이미지를 판매하지 않고 수정하지 않겠습니다.').modification,'no');
});
test('attribution does not invent a licence or author',()=>{
  const draft=attribution({record:{title:'시험용 자료',institution:'시험 기관',author:'',number:'',source:'https://example.test/record'},image:{ordinal:2,rights:{type:null,confirmed:false,conflict:false}}});
  assert.ok(draft.includes('2번째 이미지'));
  assert.ok(!draft.includes('공공누리'));assert.ok(draft.includes('[이미지 작성자·저작권자 확인 필요]'));
});

// Unknown intentions only matter when a licence actually restricts that use.
test('automatic purpose drives all four types without a confirmation gate',()=>{
  const p=suggestQuestion('호작도를 티셔츠에 넣어서 판매하고 싶어');
  assert.equal(p.commercial,'yes');assert.equal(p.modification,'unknown');
  for(const [type,status] of [['1','match'],['2','restricted'],['3','conditional'],['4','restricted']])
    assert.equal(guidance({type,confirmed:true,conflict:false},p).status,status);
  const edit=suggestQuestion('고양이 그림의 배경을 지우고 색상을 바꾸어 판매하고 싶어');
  assert.equal(edit.query,'고양이');assert.equal(edit.modification,'yes');
  assert.equal(guidance({type:'3',confirmed:true,conflict:false},edit).status,'restricted');
  assert.equal(suggestQuestion('청자 무늬를 그대로 사용하고 싶어요').modification,'no');
  const school=suggestQuestion('청자 문화유산을 수업자료로 쓰고 싶어');
  assert.equal(school.commercial,'unknown');
  assert.equal(guidance({type:'4',confirmed:true,conflict:false},school).status,'conditional');
});

test('attribution uses verified details, preserves missing markers and creates escaped hyperlinks',()=>{
 const selection={record:{title:'<그림>',institution:'시험 기관',author:'유물 작가',number:'123',source:'https://example.test/record?a=1&b=2'},image:{ordinal:1,rights:{type:'1',confirmed:true,conflict:false}}};
 const draft=attribution(selection);
 assert.ok(draft.includes('공공누리 제1유형'));
 assert.ok(draft.includes('[이미지 작성연도 확인 필요]'));
 assert.ok(!draft.includes('유물 작가'));
 assert.ok(!draft.includes('무료'));
 const details={year:'2024',author:'사진 작성자',institution:'원문 기관'};
 const filled=attribution(selection,details);
 assert.ok(filled.includes('작성연도: 2024'));
 assert.ok(filled.includes('작성자·저작권자: 사진 작성자'));
 assert.ok(filled.includes('원문 기관'));
 assert.ok(!filled.includes('확인 필요'));
 const html=attributionHTML(selection,{author:'<img src=x onerror=alert(1)>'});
 assert.ok(html.includes('<a href="https://example.test/record?a=1&amp;b=2">'));
 assert.ok(!html.includes('<img'));assert.ok(html.includes('&lt;그림&gt;'));
 selection.image.rights.conflict=true;
 assert.ok(!attribution(selection).includes('공공누리 제1유형'));
 selection.record.source='javascript:alert(1)';
 assert.ok(!attributionHTML(selection).includes('<a '));
});
