import test from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { makeGeminiSettings, connectionTestQuestion } from '../lib/gemini-settings-handler.ts';
import { sealServiceKey, openServiceKey } from '../lib/settings-security.ts';

const owner={userId:'owner',email:'owner@example.test'};
const result={query:'경향신문',commercial:'unknown',modification:'unknown',hasPurpose:true,method:'ai',fallback:null};
const request=(body={apiKey:'test-only-secret',freeTierConfirmed:true},method='POST',origin='https://example.test')=>new Request('https://example.test/api/settings/gemini',{
  method,headers:{Origin:origin,'Content-Type':'application/json'},...(method==='POST'?{body:JSON.stringify(body)}:{}),
});
const base={user:async()=>owner,ownerEmail:()=>owner.email,analyze:async()=>result,save:async()=>new Date().toISOString(),remove:async()=>{},acquire:()=>()=>{}};

test('both saving and disconnecting Gemini require authenticated owner and same origin',async()=>{
  let writes=0,calls=0;
  const deps={...base,analyze:async()=>{calls++;return result;},save:async()=>{writes++;return '';},remove:async()=>{writes++;}};
  for(const method of ['POST','DELETE']){
    for(const user of [null,{userId:'other',email:'other@example.test'}]){
      assert.equal((await makeGeminiSettings({...deps,user:async()=>user})(request(undefined,method))).status,403);
    }
    assert.equal((await makeGeminiSettings(deps)(request(undefined,method,'https://elsewhere.test'))).status,403);
  }
  assert.equal(writes,0);assert.equal(calls,0);
});
test('invalid keys, missing free-tier confirmation, oversized input and limits never call Google',async()=>{
  let calls=0;
  const handler=makeGeminiSettings({...base,analyze:async()=>{calls++;return result;}});
  for(const body of [{apiKey:'test-only-secret'},{apiKey:'test-only-secret',freeTierConfirmed:false},{apiKey:'with whitespace',freeTierConfirmed:true},{apiKey:'x'.repeat(5000),freeTierConfirmed:true},{apiKey:'test-only-secret',freeTierConfirmed:true,extra:'x'}]){
    assert.equal((await handler(request(body))).status,400);
  }
  const limited=makeGeminiSettings({...base,acquire:()=>null,analyze:async()=>{calls++;return result;}});
  assert.equal((await limited(request())).status,429);assert.equal(calls,0);
});
test('failed analysis never replaces a working key or exposes upstream details',async()=>{
  let saves=0;
  for(const analysis of [{...result,method:'rules',fallback:'unavailable'},{...result,query:'논문에'},{...result,commercial:'no'},{...result,fallback:'limit',method:'rules'}]){
    const response=await makeGeminiSettings({...base,analyze:async()=>analysis,save:async()=>{saves++;return '';}})(request());
    assert.equal(response.status,analysis.fallback==='limit'?429:422);
    assert.ok(!(await response.text()).includes('test-only-secret'));
  }
  const response=await makeGeminiSettings({...base,analyze:async()=>{throw Error('test-only-secret');}})(request());
  assert.equal(response.status,503);assert.ok(!(await response.text()).includes('test-only-secret'));
  assert.equal(saves,0);
});
test('successful fixed-sentence check saves under authenticated ID with no key in response',async()=>{
  let saved,released=0;
  const handler=makeGeminiSettings({...base,analyze:async(question,key)=>{
    assert.equal(question,connectionTestQuestion);assert.equal(key,'test-only-secret');return result;
  },save:async(key,userId)=>{saved={key,userId};return '2026-10-16T00:00:00.000Z';},acquire:()=>()=>{released++;}});
  const response=await handler(request());assert.equal(response.status,200);
  assert.equal(response.headers.get('cache-control'),'no-store');
  assert.deepEqual(saved,{key:'test-only-secret',userId:owner.userId});assert.equal(released,1);
  const text=await response.text();assert.ok(!text.includes('test-only-secret'));assert.match(text,/경향신문/);
});
test('disconnect does not call Google and encrypted providers cannot be interchanged',async()=>{
  let removed=false;
  const response=await makeGeminiSettings({...base,remove:async()=>{removed=true;},analyze:async()=>{throw Error('must not call');}})(request(undefined,'DELETE'));
  assert.equal(removed,true);assert.equal((await response.json()).configured,false);
  const secret=randomBytes(32).toString('base64');
  const sealed=await sealServiceKey('test-only-secret',secret,'gemini');
  assert.equal(await openServiceKey(sealed,secret,'gemini'),'test-only-secret');
  await assert.rejects(openServiceKey(sealed,secret));
  await assert.rejects(openServiceKey(await sealServiceKey('emuseum-key',secret),secret,'gemini'));
});
