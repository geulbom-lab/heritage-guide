import test from 'node:test';
import assert from 'node:assert/strict';
import {searchTerms,uniqueRecords} from '../lib/public-search.ts';
test('topic links are bounded and do not broaden exact titles',()=>{
 assert.deepEqual(searchTerms('호랑이'),['호랑이','호작도']);
 assert.deepEqual(searchTerms('고양이'),['고양이','묘작도']);
 assert.deepEqual(searchTerms('청자'),['청자']);
 assert.deepEqual(searchTerms('호작도'),['호작도']);
});
test('unrelated titles and duplicate records are excluded from merged pages',()=>{
 const rows=[{id:'1',title:'청자 상감 매병'},{id:'2',title:'백자 항아리'},{id:'1',title:'청자 상감 매병'}];
 assert.deepEqual(uniqueRecords(rows,['청자']),[rows[0]]);
 const cats=[{id:'a',title:'묘작도'},{id:'b',title:'고양이와 참새'},{id:'c',title:'호작도'}];
 assert.deepEqual(uniqueRecords(cats,searchTerms('고양이')),cats.slice(0,2));
});
