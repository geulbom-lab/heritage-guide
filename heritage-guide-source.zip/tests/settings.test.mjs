import test from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { isSettingsOwner, normalizeServiceKey, sealServiceKey, openServiceKey } from '../lib/settings-security.ts';
import { makeSaveSettings } from '../lib/settings-handler.ts';
const owner={userId:'owner-site-id',email:'owner@example.test'};
const makeRequest=(body={serviceKey:'test-key'},origin='https://guide.example.test')=>new Request('https://guide.example.test/api/settings/emuseum',{method:'POST',headers:{origin,'Content-Type':'application/json'},body:JSON.stringify(body)});
test('only the authenticated owner can save; requests from other origins are rejected',async()=>{
  let called=false;
  const deps={user:async()=>null,ownerEmail:()=>owner.email,validate:async()=>{called=true;return true;},save:async()=>{called=true;return '';},clearCache:()=>{}};
  assert.equal((await makeSaveSettings(deps)(makeRequest())).status,403);
  assert.equal((await makeSaveSettings({...deps,user:async()=>({userId:'other',email:'other@example.test'})})(makeRequest())).status,403);
  assert.equal((await makeSaveSettings({...deps,user:async()=>owner})(makeRequest(undefined,'https://elsewhere.example.test'))).status,403);
  assert.equal(called,false);
  assert.equal(isSettingsOwner(owner,''),false);
});
test('invalid or unverified keys do not overwrite the existing connection',async()=>{
  let saves=0;
  const handler=makeSaveSettings({user:async()=>owner,ownerEmail:()=>owner.email,validate:async()=>false,save:async()=>{saves++;return '';},clearCache:()=>{}});
  assert.equal((await handler(makeRequest({serviceKey:'  '}))).status,400);
  assert.equal((await handler(makeRequest({serviceKey:'new-key'}))).status,422);
  assert.equal((await handler(makeRequest({serviceKey:'x'.repeat(5000)}))).status,413);
  assert.equal(saves,0);
});
test('a verified key is saved under the authenticated ID, with no key in the response',async()=>{
  const saved=[];let cleared=false;
  const handler=makeSaveSettings({user:async()=>owner,ownerEmail:()=>owner.email,validate:async key=>key==='abc+/=',save:async(key,userId)=>{saved.push({key,userId});return '2026-10-05T00:00:00.000Z';},clearCache:()=>{cleared=true;}});
  const response=await handler(makeRequest({serviceKey:' abc%2B%2F%3D '}));
  assert.equal(response.status,200);const text=await response.text();assert.equal(text.includes('abc'),false);
  assert.deepEqual(saved,[{key:'abc+/=',userId:owner.userId}]);assert.equal(cleared,true);
});
test('secrets round-trip encrypted, use random IVs, and reject tampering or wrong keys',async()=>{
  const secret=randomBytes(32).toString('base64');const key='private-api-key';
  const sealed=await sealServiceKey(key,secret);assert.equal(sealed.includes(key),false);
  assert.equal(await openServiceKey(sealed,secret),key);
  assert.notEqual(sealed,await sealServiceKey(key,secret));
  await assert.rejects(openServiceKey(sealed,randomBytes(32).toString('base64')));
  const parts=sealed.split('.');const bytes=Buffer.from(parts[1],'base64');bytes[0]^=1;
  await assert.rejects(openServiceKey(parts[0]+'.'+bytes.toString('base64'),secret));
  assert.equal(normalizeServiceKey(' abc+/= '),'abc+/=');
});
