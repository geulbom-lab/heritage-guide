import test from 'node:test';
import assert from 'node:assert/strict';
import {makeFeedbackHandler,parseFeedback} from '../lib/feedback-handler.ts';
const request=(body,origin='https://example.test')=>new Request('https://example.test/api/public/feedback',{method:'POST',headers:{origin,'Content-Type':'application/json'},body:JSON.stringify(body)});
test('reports save only explicitly submitted fields, and success follows persistence',async()=>{
 let saved;const handler=makeFeedbackHandler(async data=>{saved=data;return 'test-id';},()=>true);
 const response=await handler(request({message:'이 이미지의 원문 조건이 달라요.',recordId:'123',licence:'1'}));
 assert.equal(response.status,201);assert.equal(saved.recordId,'123');
 assert.ok(!('question' in saved));assert.ok(!('email' in saved));
 assert.equal((await response.json()).id,'test-id');
});
test('rejects cross-origin, oversized and unexpected data without saving',async()=>{
 let writes=0;const handler=makeFeedbackHandler(async()=>{writes++;return 'x';},()=>true);
 assert.equal((await handler(request({message:'오류 내용입니다'},'https://other.test'))).status,403);
 assert.equal((await handler(request({message:'x'.repeat(9000)}))).status,413);
 assert.equal((await handler(request({message:'오류 내용입니다',question:'private question'}))).status,400);
 assert.equal(writes,0);
 assert.throws(()=>parseFeedback({message:'오류 내용입니다',recordId:'javascript:alert(1)'}));
});
test('save failures and rate limits never claim a successful report',async()=>{
 const failed=makeFeedbackHandler(async()=>{throw Error('db');},()=>true);
 assert.equal((await failed(request({message:'저장 실패 테스트'}))).status,503);
 const limited=makeFeedbackHandler(async()=>{throw Error('must not run');},()=>false);
 assert.equal((await limited(request({message:'한도 검사 테스트'}))).status,429);
});
