import test from 'node:test';
import assert from 'node:assert/strict';
import { analyzeQuestion, validateAnalysis, readBoundedJSON } from '../lib/question-analysis.ts';
import { isPlainSearch, ruleAnalysis } from '../lib/question-input.ts';
import { makeInterpretHandler, createInterpretLimiter } from '../lib/interpret-handler.ts';

const question='근데 내가 논문쓰는데 고려청자 사진이 필요해. 논문에 쓸 사진이야';
const extraction=(extra={})=>({query:'고려청자',hasPurpose:true,needsClarification:false,commercial:'unknown',commercialEvidence:'',modification:'unknown',modificationEvidence:'',...extra});
const response=(value=extraction(),extra={})=>Response.json({candidates:[{finishReason:'STOP',content:{parts:[{text:JSON.stringify(value)}]}}],...extra});

test('no credential preserves existing basic sentence search without a model request',async()=>{
  const parsed=await analyzeQuestion(question,{fetcher:async()=>{throw Error('must not fetch');}});
  assert.deepEqual(parsed,{query:'고려청자',commercial:'unknown',modification:'unknown',hasPurpose:true,method:'rules',fallback:'unconfigured'});
});
test('server adapter only uses Gemini with structured extraction and bounded output',async()=>{
  let calls=0;
  const result=await analyzeQuestion(question,{apiKey:'test-only',fetcher:async(url,init)=>{
    calls++;assert.equal(url,'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent');
    assert.equal(init.headers['x-goog-api-key'],'test-only');
    const body=JSON.parse(init.body);assert.equal(body.contents[0].parts[0].text,question);
    assert.equal(body.generationConfig.responseFormat.text.mimeType,'application/json');
    assert.equal(body.generationConfig.responseFormat.text.schema.additionalProperties,false);assert.ok(body.generationConfig.maxOutputTokens<=600);
    return response();
  }});
  assert.equal(calls,1);assert.equal(result.query,'고려청자');assert.equal(result.method,'ai');
  assert.equal(result.commercial,'unknown');assert.equal(result.modification,'unknown');
});
test('unlisted multiword source names are preserved, including a cup as the source',()=>{
  for(const name of ['천마총 금관','백자 청화 구름 용무늬 항아리','청자 컵','호랑이와 까치']){
    assert.equal(validateAnalysis(extraction({query:name}),`내 발표에 필요한 건 ${name} 사진이야`).query,name);
  }
  assert.equal(validateAnalysis(extraction({query:'고려 청자'}),question).query,'고려 청자');
  assert.equal(validateAnalysis(extraction({needsClarification:true}),question).query,'');
  assert.throws(()=>validateAnalysis(extraction({query:'훈민정음'}),question));
  assert.throws(()=>validateAnalysis(extraction({licence:'1'}),question));
});
test('academic use cannot be silently interpreted as noncommercial or unchanged',()=>{
  const parsed=validateAnalysis(extraction({commercial:'no',commercialEvidence:'논문에 쓸 사진이야',modification:'no',modificationEvidence:'사진이 필요해'}),question);
  assert.equal(parsed.commercial,'unknown');assert.equal(parsed.modification,'unknown');
  const explicit='고려청자 사진을 비영리로 그대로 쓸 거야';
  const purpose=validateAnalysis(extraction({commercial:'no',commercialEvidence:'비영리로',modification:'no',modificationEvidence:'그대로'}),explicit);
  assert.equal(purpose.commercial,'no');assert.equal(purpose.modification,'no');
  const negative='고려청자 사진은 팔지 않을 거야';
  assert.equal(validateAnalysis(extraction({commercial:'yes',commercialEvidence:'팔지 않을 거야'}),negative).commercial,'unknown');
  assert.equal(validateAnalysis(extraction({commercial:'yes',commercialEvidence:'팔자'}),question).commercial,'unknown');
  assert.equal(validateAnalysis(extraction({commercial:'no',commercialEvidence:'안 팔고'}),'고려청자 사진으로 만든 일부는 안 팔고 일부는 판매할 거야').commercial,'unknown');
  assert.equal(validateAnalysis(extraction({modification:'no',modificationEvidence:'그대로'}),'고려청자 사진을 그대로 쓰거나 배경을 지우고 쓰려고 해').modification,'unknown');
});
test('provider errors, refusals, unfinished output and invalid extraction fall back visibly',async()=>{
  for(const fetcher of [
    async()=>Response.json({error:'secret provider detail'},{status:401}),
    async()=>{throw Error('network');},
    async()=>response(extraction(),{candidates:[{finishReason:'MAX_TOKENS'}]}),
    async()=>response(extraction({query:'입력에 없는 이름'})),
    async()=>response(extraction(),{promptFeedback:{blockReason:'SAFETY'}}),
    async()=>Response.json(null),
  ]){
    const result=await analyzeQuestion(question,{apiKey:'test-only',fetcher});
    assert.equal(result.fallback,'unavailable');assert.equal(result.method,'rules');assert.equal(result.query,'고려청자');
    assert.ok(!JSON.stringify(result).includes('secret'));
  }
});
test('timeout and request cancellation stop model work',async()=>{
  let aborted=false;
  const result=await analyzeQuestion(question,{apiKey:'test-only',timeoutMs:5,fetcher:async(_url,init)=>new Promise((_resolve,reject)=>{
    init.signal.addEventListener('abort',()=>{aborted=true;reject(Error('aborted'));},{once:true});
  })});
  assert.equal(aborted,true);assert.equal(result.fallback,'unavailable');
  const controller=new AbortController();controller.abort();let called=false;
  await analyzeQuestion(question,{apiKey:'test-only',signal:controller.signal,fetcher:async()=>{called=true;return response();}});
  assert.equal(called,false);
});
test('oversized responses are rejected before parsing',async()=>{
  await assert.rejects(readBoundedJSON(new Response('x'.repeat(4097)).body,4096));
});
const request=(body={question},headers={})=>new Request('https://example.test/api/public/interpret',{method:'POST',headers:{Origin:'https://example.test','Content-Type':'application/json',...headers},body:JSON.stringify(body)});
test('interpret endpoint validates origin, body and rate before invoking a model',async()=>{
  let calls=0,released=0;
  const handler=makeInterpretHandler(async(value)=>{calls++;assert.equal(value,question);return validateAnalysis(extraction(),value);},()=>()=>{released++;});
  assert.equal((await handler(request({}, {Origin:'https://elsewhere.test'}))).status,403);
  assert.equal((await handler(request({}, {'Content-Type':'text/plain'}))).status,415);
  for(const body of [{question:' '},{question:'a'.repeat(701)},{question,extra:'injection'},{question:7},{question:'가'.repeat(2000)}])assert.equal((await handler(request(body))).status,400);
  assert.equal(calls,0);
  const valid=await handler(request());assert.equal(valid.status,200);assert.equal(valid.headers.get('Cache-Control'),'no-store');
  assert.equal((await valid.json()).query,'고려청자');assert.equal(calls,1);assert.equal(released,1);
  const blocked=makeInterpretHandler(async()=>{throw Error('must not call');},()=>null);
  assert.equal((await blocked(request())).status,429);
  let failureReleased=false;
  const failure=makeInterpretHandler(async()=>{throw Error('secret');},()=>()=>{failureReleased=true;});
  assert.equal((await failure(request())).status,503);assert.equal(failureReleased,true);
});
test('interpret limiter bounds concurrent and per-client requests, and expires buckets',()=>{
  let now=0;const acquire=createInterpretLimiter(()=>now),req=request();
  const release=Array.from({length:4},()=>acquire(req));assert.ok(release.every(Boolean));assert.equal(acquire(req),null);
  release.forEach(fn=>{fn();fn();});
  for(let i=0;i<6;i++){const done=acquire(req);assert.ok(done);done();}
  assert.equal(acquire(req),null);now=60001;assert.ok(acquire(req));
});


test('plain titles bypass Gemini while basic sentence search remains available', async()=>{
  for(const title of ['말모이', '컵', '천마총 금관', '백자 청화 구름 용무늬 항아리', '호랑이와 까치']){
    assert.equal(isPlainSearch(title),true,title);
    const result=await analyzeQuestion(title,{apiKey:'test-only',fetcher:async()=>{throw Error('title must not fetch');}});
    assert.equal(result.query,title);assert.equal(result.fallback,null);
  }
  for(const [sentence,expected] of [[question,'고려청자'],['논문에 쓰고싶은데 그게 뭐냐면 경향신문을 논문에 쓰려고',''],['경향신문을 논문에 쓰고 싶어.','경향신문'],['컵을 만들껀데 말모이 원고 사진을 쓰려고해','말모이 원고'],['말모이 원고 원문 전체를 복제한 영인본을 제작해서 판매하고 싶어.','말모이 원고']]){
    assert.equal(isPlainSearch(sentence),false,sentence);
    assert.equal((await analyzeQuestion(sentence)).query,expected,sentence);
  }
});
test('quota failure asks for the title without retries or another paid provider',async()=>{
  let calls=0;
  const result=await analyzeQuestion('논문에 쓰고싶은데 그게 뭐냐면 경향신문을 논문에 쓰려고',{apiKey:'test-only',fetcher:async()=>{calls++;return Response.json({error:'quota'},{status:429});}});
  assert.equal(calls,1);assert.equal(result.query,'');assert.equal(result.fallback,'limit');
});


test('reported 호작도 regression and previous working sentences recover without API keys',async()=>{
  const cases=[
    ['호작도 사진을 티셔츠에 넣어 판매하고싶어','호작도','yes','unknown'],
    ['호작도 사진을 티셔츠에 넣어 판매하고 싶어.','호작도','yes','unknown'],
    ['말모이 원고 원문 전체를 복제한 영인본을 제작해서 판매하고 싶어.','말모이 원고','yes','unknown'],
    ['컵을 만들껀데 말모이 원고 사진을 쓰려고해','말모이 원고','unknown','unknown'],
    ['텀블러에 호작도 넣어서 팔자','호작도','yes','unknown'],
    ['훈민정음 이미지를 비영리 수업 자료에 그대로 넣고 싶어요.','훈민정음','no','no'],
    ['청자 무늬를 편집해 판매할 엽서를 만들고 싶어요.','청자','yes','yes'],
    ['호랑이 그림의 배경을 지우고 색상을 바꾸어 디자인에 쓰고 싶어요.','호랑이','unknown','yes'],
    ['천마총 금관 사진을 수업 자료에 쓰고 싶어요','천마총 금관','unknown','unknown'],
    ['호랑이와 까치 그림을 엽서에 넣어서 팔고 싶어요','호랑이와 까치','yes','unknown'],
    ['청자 컵 사진을 수업 자료에 쓰려고 해','청자 컵','unknown','unknown'],
  ];
  for(const [sentence,query,commercial,modification] of cases){
    // Exercise the exact shared fallback used by the browser and server.
    const local=ruleAnalysis(sentence);
    const server=await analyzeQuestion(sentence,{fetcher:async()=>{assert.fail('No API call without a key');}});
    assert.deepEqual(server,local);
    assert.equal(local.query,query,sentence);assert.equal(local.commercial,commercial,sentence);
    assert.equal(local.modification,modification,sentence);assert.equal(local.hasPurpose,true,sentence);
  }
});
test('missing sources, multiple source markers and destination fragments still request clarification',()=>{
  for(const sentence of ['컵을 만들고 싶어','티셔츠에 그림을 넣어 팔고 싶어','호작도 사진과 말모이 사진을 쓰고 싶어','논문에 쓰고싶은데 그게 뭐냐면 경향신문을 논문에 쓰려고']){
    assert.equal(ruleAnalysis(sentence).query,'',sentence);
  }
  assert.equal(ruleAnalysis('논문에').query,'논문에','An explicitly entered title is not rewritten');
});
test('model outage and quota keep a recognizable sentence working; model clarification stays empty',async()=>{
  const sentence='호작도 사진을 티셔츠에 넣어 판매하고싶어';
  for(const status of [429,503]){
    const result=await analyzeQuestion(sentence,{apiKey:'test-only',fetcher:async()=>Response.json({error:'unavailable'},{status})});
    assert.equal(result.query,'호작도');assert.equal(result.commercial,'yes');
    assert.equal(result.fallback,status===429?'limit':'unavailable');
  }
  const clarified=await analyzeQuestion(sentence,{apiKey:'test-only',fetcher:async()=>response(extraction({query:'호작도',needsClarification:true}))});
  assert.equal(clarified.query,'');assert.equal(clarified.method,'ai');
});
